package fr.sophosmobile.alerts

import android.content.Context
import androidx.work.Constraints
import androidx.work.CoroutineWorker
import androidx.work.ExistingPeriodicWorkPolicy
import androidx.work.NetworkType
import androidx.work.PeriodicWorkRequestBuilder
import androidx.work.WorkManager
import androidx.work.WorkerParameters
import fr.sophosmobile.data.Firewall
import fr.sophosmobile.data.FirewallStore
import fr.sophosmobile.data.History
import fr.sophosmobile.data.Sample
import fr.sophosmobile.net.Monitor
import fr.sophosmobile.net.SfosSnmp
import fr.sophosmobile.net.SophosApi
import fr.sophosmobile.net.SophosClient
import fr.sophosmobile.net.SophosException
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.util.concurrent.TimeUnit

/**
 * Surveillance en arrière-plan toutes les 15 min (minimum Android) :
 * alertes sur changement d'état et enregistrement de l'historique des rapports.
 */
class AlertWorker(ctx: Context, params: WorkerParameters) : CoroutineWorker(ctx, params) {
    private val state = ctx.getSharedPreferences("alert_state", Context.MODE_PRIVATE)

    override suspend fun doWork(): Result = withContext(Dispatchers.IO) {
        val list = FirewallStore(applicationContext).load().filter { it.alertsEnabled }
        for (fw in list) runCatching { check(fw) }
        Result.success()
    }

    private fun flag(key: String) = state.getBoolean(key, false)
    private fun setFlag(key: String, v: Boolean) = state.edit().putBoolean(key, v).apply()

    private fun alert(fw: Firewall, history: History, key: String, title: String, text: String) {
        history.logAlert(title, text)
        Notifier.notify(applicationContext, (fw.id + key).hashCode(), title, text)
    }

    private fun check(fw: Firewall) {
        val ctx = applicationContext
        if (!LocalNetwork.isOnSameSubnet(ctx, SophosClient.hostOnly(fw.host))) return
        val history = History(ctx, fw.id)

        // 1. Joignabilité
        val downKey = "${fw.id}_down"
        val reachable = try {
            SophosApi(SophosClient(fw.host, fw.username, fw.password, fw.certFingerprint)).ping()
            true
        } catch (e: SophosException) {
            e.kind != SophosException.Kind.Offline
        }
        if (!reachable && !flag(downKey)) {
            setFlag(downKey, true)
            alert(fw, history, "down", "${fw.name} ne répond plus", "Le pare-feu est injoignable depuis le réseau local.")
        } else if (reachable && flag(downKey)) {
            setFlag(downKey, false)
            alert(fw, history, "down", "${fw.name} répond à nouveau", "Le pare-feu est de nouveau joignable.")
        }
        if (!reachable || fw.snmpCommunity.isBlank()) {
            history.add(Sample(System.currentTimeMillis(), reachable))
            return
        }

        // 2. Ressources et interfaces
        val s = runCatching { Monitor(fw.host, fw.snmpCommunity, fw.snmpPort).sample() }.getOrNull()
        val sfos = SfosSnmp(fw.host, fw.snmpCommunity, fw.snmpPort)
        val info = runCatching { sfos.info() }.getOrNull()
        history.add(
            Sample(
                t = System.currentTimeMillis(), reachable = true,
                cpu = s?.cpu, ram = s?.ramPct ?: info?.memPct, disk = info?.diskPct ?: s?.diskPct,
                users = info?.liveUsers, conns = info?.tcpEstablished,
                ifs = s?.ifs?.filter { it.inOctets != null && it.outOctets != null }
                    ?.associate { it.name to (it.inOctets!! to it.outOctets!!) } ?: emptyMap(),
            ),
        )
        if (s == null) return

        fun threshold(key: String, label: String, value: Int?, max: Int) {
            if (value == null) return
            val k = "${fw.id}_$key"
            if (value >= max && !flag(k)) {
                setFlag(k, true)
                alert(fw, history, key, "${fw.name} : $label élevé", "$label à $value % (seuil $max %).")
            } else if (value < max - 5 && flag(k)) {
                setFlag(k, false)
            }
        }
        threshold("cpu", "CPU", s.cpu, fw.cpuThreshold)
        threshold("ram", "Mémoire", s.ramPct, fw.ramThreshold)
        threshold("disk", "Disque", info?.diskPct, 90)

        fun transition(key: String, nowOk: Boolean, downTitle: String, upTitle: String, text: String) {
            val k = "${fw.id}_$key"
            val known = state.contains(k)
            val wasOk = state.getBoolean(k, nowOk)
            state.edit().putBoolean(k, nowOk).apply()
            if (!known) return
            if (wasOk && !nowOk) alert(fw, history, key, downTitle, text)
            if (!wasOk && nowOk) alert(fw, history, key, upTitle, text)
        }

        for (i in s.ifs) {
            transition("if_${i.name}", i.up, "${fw.name} : ${i.name} est tombé", "${fw.name} : ${i.name} rétabli", "Interface ${i.name}")
        }

        // 3. Services, tunnels VPN, licences (MIB Sophos)
        runCatching {
            sfos.services().filter { it.relevant || state.contains("${fw.id}_svc_${it.key}") }.forEach {
                transition("svc_${it.key}", it.ok, "${fw.name} : service ${it.name} ${it.label}", "${fw.name} : service ${it.name} en marche", "Service ${it.name}")
            }
        }
        runCatching {
            sfos.tunnels().filter { it.activated == 1 }.forEach {
                transition("vpn_${it.name}", it.status == 1, "${fw.name} : tunnel ${it.name} coupé", "${fw.name} : tunnel ${it.name} rétabli", "Tunnel VPN ${it.name}")
            }
        }
        runCatching {
            sfos.licences().filter { it.owned }.forEach { l ->
                val d = l.daysLeft() ?: return@forEach
                val step = when { d < 0 -> 0; d <= 7 -> 7; d <= 30 -> 30; else -> return@forEach }
                val k = "${fw.id}_lic_${l.module}_$step"
                if (!flag(k)) {
                    setFlag(k, true)
                    val txt = if (d < 0) "La licence ${l.module} a expiré." else "La licence ${l.module} expire dans $d jour(s) (${l.expiry})."
                    alert(fw, history, "lic${l.module}", "${fw.name} : licence ${l.module}", txt)
                }
            }
        }
    }

    companion object {
        private const val WORK = "sophos_alerts"

        fun schedule(context: Context, anyEnabled: Boolean) {
            val wm = WorkManager.getInstance(context)
            if (!anyEnabled) {
                wm.cancelUniqueWork(WORK)
                return
            }
            val req = PeriodicWorkRequestBuilder<AlertWorker>(15, TimeUnit.MINUTES)
                .setConstraints(Constraints.Builder().setRequiredNetworkType(NetworkType.CONNECTED).build())
                .build()
            wm.enqueueUniquePeriodicWork(WORK, ExistingPeriodicWorkPolicy.KEEP, req)
        }
    }
}
