package fr.sophosmobile.ui

import android.app.Application
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateMapOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import fr.sophosmobile.alerts.AlertWorker
import fr.sophosmobile.alerts.LocalNetwork
import fr.sophosmobile.data.Firewall
import fr.sophosmobile.data.FirewallStore
import fr.sophosmobile.net.SophosApi
import fr.sophosmobile.net.SophosClient
import fr.sophosmobile.net.SophosException
import fr.sophosmobile.net.friendly
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

sealed interface Screen {
    data object Home : Screen
    data class Edit(val id: String?) : Screen
    data class Detail(val id: String) : Screen
}

sealed interface QuickStatus {
    data object Loading : QuickStatus
    data class Online(val apiVersion: String?) : QuickStatus
    data object Offline : QuickStatus
    data object NotLocal : QuickStatus
    data class Failed(val message: String) : QuickStatus
}

class AppViewModel(app: Application) : AndroidViewModel(app) {
    val store = FirewallStore(app)
    var list by mutableStateOf(store.load())
        private set
    var screen by mutableStateOf<Screen>(Screen.Home)
    val quick = mutableStateMapOf<String, QuickStatus>()

    fun reload() {
        list = store.load()
        AlertWorker.schedule(getApplication(), list.any { it.alertsEnabled })
    }

    fun find(id: String) = list.find { it.id == id }

    /** Client API ; le certificat vu à la première connexion est mémorisé. */
    fun clientFor(f: Firewall) = SophosClient(
        f.host, f.username, f.password, f.certFingerprint,
        onFirstFingerprint = { fp ->
            store.update(f.id) { it.copy(certFingerprint = fp) }
            viewModelScope.launch(Dispatchers.Main) { list = store.load() }
        },
    )

    fun apiFor(f: Firewall) = SophosApi(clientFor(f))

    /** Client console web ; réutilise le certificat mémorisé. */
    fun consoleFor(f: Firewall) = fr.sophosmobile.net.ConsoleApi(
        fr.sophosmobile.net.WebConsole(f.host, f.consoleUser, f.consolePass, f.certFingerprint),
    )

    fun save(f: Firewall) {
        store.upsert(f)
        quick.remove(f.id)
        reload()
    }

    fun delete(f: Firewall) {
        store.delete(f.id)
        quick.remove(f.id)
        reload()
    }

    fun refreshQuick(f: Firewall) {
        if (quick[f.id] == QuickStatus.Loading) return
        quick[f.id] = QuickStatus.Loading
        viewModelScope.launch {
            quick[f.id] = withContext(Dispatchers.IO) {
                if (!LocalNetwork.isOnSameSubnet(getApplication(), SophosClient.hostOnly(f.host))) {
                    QuickStatus.NotLocal
                } else try {
                    QuickStatus.Online(apiFor(f).ping())
                } catch (e: SophosException) {
                    if (e.kind == SophosException.Kind.Offline) QuickStatus.Offline else QuickStatus.Failed(e.friendly())
                } catch (e: Exception) {
                    QuickStatus.Failed(e.friendly())
                }
            }
        }
    }
}
