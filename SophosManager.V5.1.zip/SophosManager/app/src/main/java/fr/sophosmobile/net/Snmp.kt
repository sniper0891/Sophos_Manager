package fr.sophosmobile.net

import java.io.ByteArrayOutputStream
import java.net.DatagramPacket
import java.net.DatagramSocket
import java.net.InetAddress
import java.net.SocketTimeoutException
import kotlin.random.Random

/** Client SNMP v2c minimal (GET et GETBULK), sans dépendance. */
class Snmp(
    host: String,
    private val community: String,
    private val port: Int = 161,
    private val timeoutMs: Int = 2_000,
    private val retries: Int = 1,
) {
    sealed class Value {
        data class Num(val v: Long) : Value()
        class Bytes(val v: ByteArray) : Value() {
            fun str(): String = String(v, Charsets.UTF_8).trimEnd('\u0000')
        }
        data class Oid(val v: String) : Value()
        data object Null : Value()
        data object Missing : Value()
        data object End : Value()
    }

    private val address: InetAddress by lazy { InetAddress.getByName(host) }

    fun get(vararg oids: String): Map<String, Value> =
        request(0xA0, oids.toList(), 0, 0).toMap()

    /** Parcourt une colonne (sous-arbre) avec GETBULK. */
    fun walk(root: String, maxRows: Int = 500): List<Pair<String, Value>> {
        val out = ArrayList<Pair<String, Value>>()
        var current = root
        while (out.size < maxRows) {
            val batch = request(0xA5, listOf(current), 0, 25)
            if (batch.isEmpty()) break
            var done = false
            for ((oid, v) in batch) {
                if (v is Value.End || !oid.startsWith("$root.")) { done = true; break }
                out += oid to v
                current = oid
            }
            if (done) break
        }
        return out
    }

    private fun request(pduType: Int, oids: List<String>, nonRep: Int, maxRep: Int): List<Pair<String, Value>> {
        val id = Random.nextInt(1, Int.MAX_VALUE)
        val varbinds = seq(oids.map { seq(listOf(oid(it), byteArrayOf(0x05, 0x00))) })
        val pdu = tlv(pduType, int(id.toLong()) + int(nonRep.toLong()) + int(maxRep.toLong()) + varbinds)
        val msg = seq(listOf(int(1), tlv(0x04, community.toByteArray()), pdu))

        DatagramSocket().use { sock ->
            sock.soTimeout = timeoutMs
            repeat(retries + 1) {
                sock.send(DatagramPacket(msg, msg.size, address, port))
                val buf = ByteArray(65_535)
                val pkt = DatagramPacket(buf, buf.size)
                try {
                    while (true) {
                        sock.receive(pkt)
                        val parsed = parseResponse(buf.copyOf(pkt.length)) ?: continue
                        if (parsed.first != id) continue
                        return parsed.second
                    }
                } catch (_: SocketTimeoutException) {
                    // nouvel essai
                }
            }
        }
        throw SophosException(
            "Pas de réponse SNMP. Vérifie que SNMP est activé, la communauté, et que l'IP du téléphone est autorisée.",
            SophosException.Kind.Offline,
        )
    }

    // ----- Encodage BER -----

    private fun len(n: Int): ByteArray = when {
        n < 0x80 -> byteArrayOf(n.toByte())
        n < 0x100 -> byteArrayOf(0x81.toByte(), n.toByte())
        else -> byteArrayOf(0x82.toByte(), (n shr 8).toByte(), n.toByte())
    }

    private fun tlv(tag: Int, body: ByteArray) = byteArrayOf(tag.toByte()) + len(body.size) + body
    private fun seq(items: List<ByteArray>) = tlv(0x30, items.fold(ByteArray(0)) { a, b -> a + b })

    private fun int(v: Long): ByteArray {
        var bytes = java.math.BigInteger.valueOf(v).toByteArray()
        if (bytes.isEmpty()) bytes = byteArrayOf(0)
        return tlv(0x02, bytes)
    }

    private fun oid(s: String): ByteArray {
        val parts = s.trim('.').split('.').map { it.toLong() }
        val out = ByteArrayOutputStream()
        out.write((parts[0] * 40 + parts[1]).toInt())
        for (p in parts.drop(2)) {
            val tmp = ArrayList<Int>()
            var x = p
            tmp += (x and 0x7F).toInt()
            x = x shr 7
            while (x > 0) { tmp += ((x and 0x7F) or 0x80).toInt(); x = x shr 7 }
            tmp.reversed().forEach { out.write(it) }
        }
        return tlv(0x06, out.toByteArray())
    }

    // ----- Décodage BER -----

    private class Reader(val b: ByteArray, var pos: Int = 0, val end: Int = b.size) {
        fun tag(): Int = b[pos++].toInt() and 0xFF
        fun length(): Int {
            val first = b[pos++].toInt() and 0xFF
            if (first < 0x80) return first
            var n = 0
            repeat(first and 0x7F) { n = (n shl 8) or (b[pos++].toInt() and 0xFF) }
            return n
        }
        fun read(): Pair<Int, ByteArray> {
            val t = tag()
            val l = length()
            val v = b.copyOfRange(pos, pos + l)
            pos += l
            return t to v
        }
        fun more() = pos < end
    }

    private fun parseResponse(data: ByteArray): Pair<Int, List<Pair<String, Value>>>? = try {
        val (t, body) = Reader(data).read()
        if (t != 0x30) null else {
            val r = Reader(body)
            r.read() // version
            r.read() // communauté
            val (pduTag, pdu) = r.read()
            if (pduTag != 0xA2) null else {
                val p = Reader(pdu)
                val id = decodeInt(p.read().second).toInt()
                val err = decodeInt(p.read().second)
                p.read() // index d'erreur
                if (err != 0L) throw SophosException("Erreur SNMP $err", SophosException.Kind.Other)
                val vbs = Reader(p.read().second)
                val out = ArrayList<Pair<String, Value>>()
                while (vbs.more()) {
                    val vb = Reader(vbs.read().second)
                    val oid = decodeOid(vb.read().second)
                    val (vt, vv) = vb.read()
                    out += oid to decodeValue(vt, vv)
                }
                id to out
            }
        }
    } catch (e: SophosException) {
        throw e
    } catch (_: Exception) {
        null
    }

    private fun decodeInt(b: ByteArray): Long = if (b.isEmpty()) 0 else java.math.BigInteger(b).toLong()
    private fun decodeUnsigned(b: ByteArray): Long = if (b.isEmpty()) 0 else java.math.BigInteger(1, b).toLong()

    private fun decodeOid(b: ByteArray): String {
        if (b.isEmpty()) return ""
        val parts = arrayListOf((b[0].toInt() and 0xFF) / 40L, (b[0].toInt() and 0xFF) % 40L)
        var acc = 0L
        for (i in 1 until b.size) {
            val x = b[i].toInt() and 0xFF
            acc = (acc shl 7) or (x and 0x7F).toLong()
            if (x and 0x80 == 0) { parts += acc; acc = 0 }
        }
        return parts.joinToString(".")
    }

    private fun decodeValue(t: Int, v: ByteArray): Value = when (t) {
        0x02 -> Value.Num(decodeInt(v))
        0x41, 0x42, 0x43, 0x46, 0x47 -> Value.Num(decodeUnsigned(v))
        0x04, 0x40 -> Value.Bytes(v)
        0x06 -> Value.Oid(decodeOid(v))
        0x05 -> Value.Null
        0x80, 0x81 -> Value.Missing
        0x82 -> Value.End
        else -> Value.Bytes(v)
    }
}

fun Snmp.Value?.num(): Long? = (this as? Snmp.Value.Num)?.v
fun Snmp.Value?.str(): String? = (this as? Snmp.Value.Bytes)?.str()
