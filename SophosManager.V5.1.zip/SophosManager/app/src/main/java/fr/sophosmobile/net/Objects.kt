package fr.sophosmobile.net

import fr.sophosmobile.net.Xml.esc
import org.w3c.dom.Element

enum class FType { Text, Choice, Refs }

data class Field(
    val key: String,
    val label: String,
    val type: FType = FType.Text,
    val options: List<String> = emptyList(),
    /** Types d'objets proposés pour un champ de références. */
    val refTags: List<String> = emptyList(),
    val hint: String = "",
    val optional: Boolean = false,
    val showIf: (Map<String, String>) -> Boolean = { true },
)

/** Description d'un type d'objet : champs du formulaire, lecture et écriture XML. */
class ObjKind(
    val tag: String,
    val title: String,
    val fields: List<Field>,
    val read: (Element) -> Map<String, String>,
    val write: (Map<String, String>) -> String,
    val summary: (Element) -> String,
    val editable: (Element) -> Boolean = { true },
    val readOnly: Boolean = false,
)

data class ObjItem(val name: String, val summary: String, val editable: Boolean, internal val el: Element)

private fun refsXml(container: String, item: String, v: String?) =
    v.orEmpty().lines().filter { it.isNotBlank() }.let { l ->
        if (l.isEmpty()) "" else "<$container>${l.joinToString("") { "<$item>${esc(it)}</$item>" }}</$container>"
    }

private fun Element.refs(container: String) = listUnder(container).joinToString("\n")

object ObjectKinds {
    private val NAME = Field("Name", "Nom", hint = "Sans virgule")
    private val DESC = Field("Description", "Description", optional = true)

    fun serviceXml(name: String, desc: String, proto: String, dst: String, src: String) = buildString {
        append("<Services><Name>${esc(name)}</Name><Description>${esc(desc)}</Description><Type>TCPorUDP</Type><ServiceDetails>")
        val protos = when (proto) { "TCP+UDP" -> listOf("TCP", "UDP"); else -> listOf(proto) }
        protos.forEach {
            append("<ServiceDetail><SourcePort>${esc(src.ifBlank { "1:65535" })}</SourcePort>")
            append("<DestinationPort>${esc(dst)}</DestinationPort><Protocol>$it</Protocol></ServiceDetail>")
        }
        append("</ServiceDetails></Services>")
    }

    val IP_HOST = ObjKind(
        tag = "IPHost", title = "Hôtes IP",
        fields = listOf(
            NAME,
            Field("HostType", "Type", FType.Choice, listOf("IP", "Network", "IPRange", "IPList")),
            Field("IPAddress", "Adresse IP", hint = "192.168.1.10", showIf = { it["HostType"] == "IP" || it["HostType"] == "Network" }),
            Field("Subnet", "Masque", hint = "255.255.255.0", showIf = { it["HostType"] == "Network" }),
            Field("StartIPAddress", "IP de début", showIf = { it["HostType"] == "IPRange" }),
            Field("EndIPAddress", "IP de fin", showIf = { it["HostType"] == "IPRange" }),
            Field("ListOfIPAddresses", "Liste d'IP", hint = "Séparées par des virgules", showIf = { it["HostType"] == "IPList" }),
            Field("Groups", "Groupes", FType.Refs, refTags = listOf("IPHostGroup"), optional = true),
        ),
        read = { e ->
            mapOf(
                "Name" to (e.text("Name") ?: ""), "HostType" to (e.text("HostType") ?: "IP"),
                "IPAddress" to (e.text("IPAddress") ?: ""), "Subnet" to (e.text("Subnet") ?: ""),
                "StartIPAddress" to (e.text("StartIPAddress") ?: ""), "EndIPAddress" to (e.text("EndIPAddress") ?: ""),
                "ListOfIPAddresses" to (e.text("ListOfIPAddresses") ?: ""), "Groups" to e.refs("HostGroupList"),
            )
        },
        write = { v ->
            val t = v["HostType"] ?: "IP"
            buildString {
                append("<IPHost><Name>${esc(v["Name"]!!)}</Name><IPFamily>IPv4</IPFamily><HostType>$t</HostType>")
                when (t) {
                    "IP" -> append("<IPAddress>${esc(v["IPAddress"].orEmpty())}</IPAddress>")
                    "Network" -> append("<IPAddress>${esc(v["IPAddress"].orEmpty())}</IPAddress><Subnet>${esc(v["Subnet"].orEmpty())}</Subnet>")
                    "IPRange" -> append("<StartIPAddress>${esc(v["StartIPAddress"].orEmpty())}</StartIPAddress><EndIPAddress>${esc(v["EndIPAddress"].orEmpty())}</EndIPAddress>")
                    "IPList" -> append("<ListOfIPAddresses>${esc(v["ListOfIPAddresses"].orEmpty().replace(" ", ""))}</ListOfIPAddresses>")
                }
                append(refsXml("HostGroupList", "HostGroup", v["Groups"]))
                append("</IPHost>")
            }
        },
        summary = { e ->
            when (e.text("HostType")) {
                "Network" -> "${e.text("IPAddress")} / ${e.text("Subnet")}"
                "IPRange" -> "${e.text("StartIPAddress")} → ${e.text("EndIPAddress")}"
                "IPList" -> e.text("ListOfIPAddresses") ?: ""
                else -> e.text("IPAddress") ?: (e.text("HostType") ?: "")
            }
        },
        editable = { it.text("HostType") in setOf("IP", "Network", "IPRange", "IPList") && it.text("IPFamily") != "IPv6" },
    )

    val IP_GROUP = ObjKind(
        tag = "IPHostGroup", title = "Groupes IP",
        fields = listOf(NAME, DESC, Field("Hosts", "Membres", FType.Refs, refTags = listOf("IPHost"), optional = true)),
        read = { e -> mapOf("Name" to (e.text("Name") ?: ""), "Description" to (e.text("Description") ?: ""), "Hosts" to e.refs("HostList")) },
        write = { v ->
            "<IPHostGroup><Name>${esc(v["Name"]!!)}</Name><Description>${esc(v["Description"].orEmpty())}</Description>" +
                refsXml("HostList", "Host", v["Hosts"]) + "<IPFamily>IPv4</IPFamily></IPHostGroup>"
        },
        summary = { e -> e.listUnder("HostList").let { if (it.isEmpty()) "Vide" else "${it.size} membre(s) : ${it.take(3).joinToString()}" } },
    )

    val FQDN_HOST = ObjKind(
        tag = "FQDNHost", title = "Hôtes FQDN",
        fields = listOf(
            NAME, DESC, Field("FQDN", "Domaine", hint = "exemple.com ou *.exemple.com"),
            Field("Groups", "Groupes", FType.Refs, refTags = listOf("FQDNHostGroup"), optional = true),
        ),
        read = { e -> mapOf("Name" to (e.text("Name") ?: ""), "Description" to (e.text("Description") ?: ""), "FQDN" to (e.text("FQDN") ?: ""), "Groups" to e.refs("FQDNHostGroupList")) },
        write = { v ->
            "<FQDNHost><Name>${esc(v["Name"]!!)}</Name><Description>${esc(v["Description"].orEmpty())}</Description>" +
                "<FQDN>${esc(v["FQDN"].orEmpty())}</FQDN>" + refsXml("FQDNHostGroupList", "FQDNHostGroup", v["Groups"]) + "</FQDNHost>"
        },
        summary = { e -> e.text("FQDN") ?: "" },
    )

    val FQDN_GROUP = ObjKind(
        tag = "FQDNHostGroup", title = "Groupes FQDN",
        fields = listOf(NAME, DESC, Field("Hosts", "Membres", FType.Refs, refTags = listOf("FQDNHost"), optional = true)),
        read = { e -> mapOf("Name" to (e.text("Name") ?: ""), "Description" to (e.text("Description") ?: ""), "Hosts" to e.refs("FQDNHostList")) },
        write = { v ->
            "<FQDNHostGroup><Name>${esc(v["Name"]!!)}</Name><Description>${esc(v["Description"].orEmpty())}</Description>" +
                refsXml("FQDNHostList", "FQDNHost", v["Hosts"]) + "</FQDNHostGroup>"
        },
        summary = { e -> e.listUnder("FQDNHostList").let { if (it.isEmpty()) "Vide" else "${it.size} membre(s)" } },
    )

    val MAC_HOST = ObjKind(
        tag = "MACHost", title = "Hôtes MAC",
        fields = listOf(NAME, DESC, Field("MACAddress", "Adresse MAC", hint = "AA:BB:CC:DD:EE:FF")),
        read = { e -> mapOf("Name" to (e.text("Name") ?: ""), "Description" to (e.text("Description") ?: ""), "MACAddress" to (e.text("MACAddress") ?: "")) },
        write = { v ->
            "<MACHost><Name>${esc(v["Name"]!!)}</Name><Description>${esc(v["Description"].orEmpty())}</Description>" +
                "<Type>MACAddress</Type><MACAddress>${esc(v["MACAddress"].orEmpty().uppercase().replace('-', ':'))}</MACAddress></MACHost>"
        },
        summary = { e -> e.text("MACAddress") ?: e.listUnder("ListOfMACAddresses").joinToString() },
        editable = { it.text("Type") != "MACLIST" && it.child("ListOfMACAddresses") == null },
    )

    val SERVICE = ObjKind(
        tag = "Services", title = "Services",
        fields = listOf(
            NAME, DESC,
            Field("Protocol", "Protocole", FType.Choice, listOf("TCP", "UDP", "TCP+UDP")),
            Field("DestinationPort", "Port(s) de destination", hint = "443 ou 8000:8010"),
            Field("SourcePort", "Port(s) source", hint = "1:65535 par défaut", optional = true),
        ),
        read = { e ->
            val d = e.child("ServiceDetails")?.children("ServiceDetail") ?: emptyList()
            val protos = d.mapNotNull { it.text("Protocol") }.toSet()
            mapOf(
                "Name" to (e.text("Name") ?: ""), "Description" to (e.text("Description") ?: ""),
                "Protocol" to if (protos.containsAll(listOf("TCP", "UDP"))) "TCP+UDP" else (protos.firstOrNull() ?: "TCP"),
                "DestinationPort" to (d.firstOrNull()?.text("DestinationPort") ?: ""),
                "SourcePort" to (d.firstOrNull()?.text("SourcePort") ?: "1:65535"),
            )
        },
        write = { v -> serviceXml(v["Name"]!!, v["Description"].orEmpty(), v["Protocol"] ?: "TCP", v["DestinationPort"].orEmpty(), v["SourcePort"].orEmpty()) },
        summary = { e ->
            val d = e.child("ServiceDetails")?.children("ServiceDetail") ?: emptyList()
            when (e.text("Type")) {
                "TCPorUDP" -> d.joinToString(", ") { "${it.text("Protocol")} ${it.text("DestinationPort")}" }
                else -> e.text("Type") ?: ""
            }
        },
        editable = { e ->
            val d = e.child("ServiceDetails")?.children("ServiceDetail") ?: emptyList()
            e.text("Type") == "TCPorUDP" && d.size in 1..2 && d.map { it.text("DestinationPort") }.distinct().size == 1
        },
    )

    val SERVICE_GROUP = ObjKind(
        tag = "ServiceGroup", title = "Groupes de services",
        fields = listOf(NAME, DESC, Field("Services", "Membres", FType.Refs, refTags = listOf("Services"), optional = true)),
        read = { e -> mapOf("Name" to (e.text("Name") ?: ""), "Description" to (e.text("Description") ?: ""), "Services" to e.refs("ServiceList")) },
        write = { v ->
            "<ServiceGroup><Name>${esc(v["Name"]!!)}</Name><Description>${esc(v["Description"].orEmpty())}</Description>" +
                refsXml("ServiceList", "Service", v["Services"]) + "</ServiceGroup>"
        },
        summary = { e -> e.listUnder("ServiceList").let { if (it.isEmpty()) "Vide" else it.take(4).joinToString() } },
    )

    private fun readOnly(tag: String, title: String, summary: (Element) -> String) = ObjKind(
        tag = tag, title = title, fields = emptyList(), read = { emptyMap() }, write = { "" },
        summary = summary, editable = { false }, readOnly = true,
    )

    val ZONE = readOnly("Zone", "Zones") { e -> listOfNotNull(e.text("Type"), e.text("Description")).joinToString(" · ") }
    val SCHEDULE = readOnly("Schedule", "Plannings") { e -> listOfNotNull(e.text("Type"), e.text("Description")).joinToString(" · ") }
    val INTERFACE = readOnly("Interface", "Interfaces") { e ->
        listOfNotNull(e.text("NetworkZone"), e.text("IPAddress")?.let { ip -> e.text("Netmask")?.let { "$ip / $it" } ?: ip }, e.text("Status"))
            .joinToString(" · ")
    }

    val ALL = listOf(IP_HOST, IP_GROUP, FQDN_HOST, FQDN_GROUP, MAC_HOST, SERVICE, SERVICE_GROUP, INTERFACE, ZONE, SCHEDULE)
}

fun SophosApi.objects(kind: ObjKind): List<ObjItem> = getAll(kind.tag).map { e ->
    ObjItem(e.text("Name") ?: "?", runCatching { kind.summary(e) }.getOrDefault(""), !kind.readOnly && kind.editable(e), e)
}.sortedBy { it.name.lowercase() }

fun SophosApi.saveObject(kind: ObjKind, values: Map<String, String>, isNew: Boolean) {
    val name = values["Name"].orEmpty().trim()
    require(name.isNotEmpty() && !name.contains(',')) { "Nom invalide" }
    for (f in kind.fields) {
        if (!f.showIf(values) || f.optional || f.type == FType.Refs) continue
        require(!values[f.key].isNullOrBlank()) { "Champ obligatoire : ${f.label}" }
    }
    val xml = kind.write(values + ("Name" to name))
    if (isNew) add(xml) else update(xml)
}

fun SophosApi.deleteObject(kind: ObjKind, item: ObjItem) = remove(kind.tag, item.name)

fun ObjKind.valuesOf(item: ObjItem): Map<String, String> = read(item.el)
