package fr.sophosmobile.ui

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.Card
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateMapOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.dp
import fr.sophosmobile.data.Firewall
import fr.sophosmobile.net.ApInfo
import fr.sophosmobile.net.HaInfo
import fr.sophosmobile.net.IfStat
import fr.sophosmobile.net.License
import fr.sophosmobile.net.Monitor
import fr.sophosmobile.net.ServiceState
import fr.sophosmobile.net.SfosInfo
import fr.sophosmobile.net.SfosSnmp
import fr.sophosmobile.net.Snapshot
import fr.sophosmobile.net.Tunnel
import fr.sophosmobile.net.formatBps
import fr.sophosmobile.net.formatUptime
import fr.sophosmobile.net.friendly
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.isActive
import kotlinx.coroutines.withContext

private data class SlowData(
    val info: SfosInfo?,
    val services: List<ServiceState>,
    val licences: List<License>,
    val tunnels: List<Tunnel>,
    val ha: HaInfo?,
    val aps: List<ApInfo>,
)

val BlueIn = Color(0xFF1E88E5)
val PurpleOut = Color(0xFF8E24AA)

/** Équivalent du centre de contrôle de la console web. */
@Composable
fun DashboardTab(fw: Firewall) {
    if (fw.snmpCommunity.isBlank()) {
        Column(Modifier.padding(16.dp)) {
            ErrorBox(
                "Le tableau de bord utilise SNMP. Active-le sur le pare-feu (Administration > SNMP : agent activé, " +
                    "communauté v2c avec l'IP du téléphone), puis saisis la communauté dans la fiche du pare-feu.",
            )
        }
        return
    }
    val monitor = remember(fw.host, fw.snmpCommunity) { Monitor(fw.host, fw.snmpCommunity, fw.snmpPort) }
    val sfos = remember(fw.host, fw.snmpCommunity) { SfosSnmp(fw.host, fw.snmpCommunity, fw.snmpPort) }
    var snap by remember { mutableStateOf<Snapshot?>(null) }
    var slow by remember { mutableStateOf<SlowData?>(null) }
    var error by remember { mutableStateOf<String?>(null) }
    val cpuHist = remember { mutableStateMapOf<Int, Int>() }
    val ifHist = remember { mutableStateMapOf<String, List<Pair<Float?, Float?>>>() }
    var tick by remember { mutableStateOf(0) }

    LaunchedEffect(monitor) {
        var n = 0
        while (isActive) {
            try {
                val s = withContext(Dispatchers.IO) { monitor.sample() }
                snap = s
                error = null
                s.cpu?.let { cpuHist[n] = it; cpuHist.keys.filter { k -> k < n - 60 }.forEach { k -> cpuHist.remove(k) } }
                s.ifs.forEach { i ->
                    val h = (ifHist[i.name] ?: emptyList()) + ((i.inBps?.toFloat()) to (i.outBps?.toFloat()))
                    ifHist[i.name] = h.takeLast(60)
                }
                if (n % 12 == 0) {
                    slow = withContext(Dispatchers.IO) {
                        SlowData(
                            runCatching { sfos.info() }.getOrNull(),
                            runCatching { sfos.services() }.getOrDefault(emptyList()),
                            runCatching { sfos.licences() }.getOrDefault(emptyList()),
                            runCatching { sfos.tunnels() }.getOrDefault(emptyList()),
                            runCatching { sfos.ha() }.getOrNull(),
                            runCatching { sfos.accessPoints() }.getOrDefault(emptyList()),
                        )
                    }
                }
            } catch (e: Exception) {
                error = e.friendly()
            }
            n++
            tick = n
            delay(5_000)
        }
    }

    val s = snap
    val d = slow
    LazyColumn(
        Modifier.fillMaxSize(),
        contentPadding = PaddingValues(16.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp),
    ) {
        error?.let { item { ErrorBox(it) } }
        if (s == null && error == null) item { CenteredLoading() }
        if (s != null) {
            item { SystemCard(fw, s, d?.info, cpuHist.toSortedMap().values.toList()) }
            d?.info?.let { info -> item { ActivityCard(info) } }
            item { Text("Interfaces", style = MaterialTheme.typography.titleMedium) }
            items(s.ifs, key = { it.index }) { InterfaceCard(it, ifHist[it.name] ?: emptyList()) }
            d?.services?.filter { it.relevant }?.takeIf { it.isNotEmpty() }?.let { svc -> item { ServicesCard(svc) } }
            d?.tunnels?.takeIf { it.isNotEmpty() }?.let { t -> item { TunnelsCard(t) } }
            d?.licences?.filter { it.status != 0 }?.takeIf { it.isNotEmpty() }?.let { l -> item { LicencesCard(l) } }
            d?.ha?.takeIf { it.enabled }?.let { ha ->
                item {
                    SectionCard("Haute disponibilité") {
                        KeyValue("Cet appareil", HaInfo.stateLabel(ha.current))
                        KeyValue("Pair", HaInfo.stateLabel(ha.peer))
                        ha.mode?.let { KeyValue("Mode", it) }
                    }
                }
            }
            d?.aps?.takeIf { it.isNotEmpty() }?.let { aps ->
                item {
                    SectionCard("Points d'accès Wi-Fi") {
                        aps.forEach { a ->
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Dot(if (a.connected) Green else Red)
                                Spacer(Modifier.width(8.dp))
                                Text("${a.name} ${a.model.orEmpty()}", Modifier.weight(1f))
                                Text("${a.clients ?: 0} client(s)", style = MaterialTheme.typography.bodySmall)
                            }
                        }
                    }
                }
            }
            item { InfoText("Ressources et débits toutes les 5 s, services et licences toutes les minutes.") }
        }
    }
}

@Composable
private fun SystemCard(fw: Firewall, s: Snapshot, info: SfosInfo?, cpuHist: List<Int>) {
    SectionCard(info?.model?.let { "Sophos $it" } ?: (s.sysName ?: fw.name)) {
        info?.firmware?.let { KeyValue("Firmware", it) }
        KeyValue("En fonctionnement depuis", formatUptime(s.uptimeSec))
        info?.date?.let { KeyValue("Heure du pare-feu", it) }
        Gauge("CPU", s.cpu, null)
        if (cpuHist.size > 1) LineChart(listOf(ChartSeries("CPU %", MaterialTheme.colorScheme.primary, cpuHist.map { it.toFloat() })), maxY = 100f, height = 60)
        Gauge("Mémoire", s.ramPct ?: info?.memPct, s.ramUsedMb?.let { u -> s.ramTotalMb?.let { t -> "$u / $t Mo" } })
        Gauge("Disque", info?.diskPct ?: s.diskPct, null)
        info?.swapPct?.let { Gauge("Swap", it, null) }
        info?.temps?.forEach { (n, t) -> KeyValue("Température $n", "%.1f °C".format(t)) }
    }
}

@Composable
private fun ActivityCard(info: SfosInfo) {
    SectionCard("Activité") {
        info.liveUsers?.let { KeyValue("Utilisateurs connectés", it.toString()) }
        info.tcpEstablished?.let { KeyValue("Connexions TCP établies", it.toString()) }
        info.httpHits?.let { KeyValue("Requêtes web traitées (cumul)", "%,d".format(it)) }
        info.ipsVersion?.let { KeyValue("Signatures IPS", it) }
        info.webcatVersion?.let { KeyValue("Catégories web", it) }
    }
}

@Composable
fun Gauge(label: String, pct: Int?, detail: String?) {
    Column {
        Row {
            Text(label, Modifier.weight(1f))
            Text(if (pct == null) "—" else "$pct %" + (detail?.let { " · $it" } ?: ""))
        }
        Spacer(Modifier.height(4.dp))
        val color = when {
            pct == null -> Grey
            pct >= 90 -> Red
            pct >= 75 -> Orange
            else -> Green
        }
        LinearProgressIndicator(progress = { (pct ?: 0) / 100f }, color = color, modifier = Modifier.fillMaxWidth().height(8.dp))
    }
}

@Composable
private fun InterfaceCard(i: IfStat, hist: List<Pair<Float?, Float?>>) {
    Card(Modifier.fillMaxWidth()) {
        Column(Modifier.padding(12.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Dot(if (i.up) Green else Grey)
                Spacer(Modifier.width(12.dp))
                Text(i.name, Modifier.weight(1f), style = MaterialTheme.typography.titleSmall)
                if (i.up) {
                    Column(horizontalAlignment = Alignment.End) {
                        Text("↓ ${formatBps(i.inBps)}", style = MaterialTheme.typography.bodySmall, color = BlueIn)
                        Text("↑ ${formatBps(i.outBps)}", style = MaterialTheme.typography.bodySmall, color = PurpleOut)
                    }
                } else {
                    Text("pas de lien", style = MaterialTheme.typography.bodySmall)
                }
            }
            if (i.up && hist.count { it.first != null } > 1) {
                Spacer(Modifier.height(6.dp))
                LineChart(
                    listOf(
                        ChartSeries("Entrant", BlueIn, hist.map { it.first }),
                        ChartSeries("Sortant", PurpleOut, hist.map { it.second }),
                    ),
                    height = 50, format = { formatBps(it.toDouble()) },
                )
            }
        }
    }
}

@OptIn(ExperimentalLayoutApi::class)
@Composable
private fun ServicesCard(svc: List<ServiceState>) {
    val bad = svc.count { !it.ok }
    SectionCard(if (bad == 0) "Services : tous en marche" else "Services : $bad en anomalie") {
        FlowRow(horizontalArrangement = Arrangement.spacedBy(6.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
            svc.forEach { Pill(it.name, if (it.ok) Green else Red) }
        }
        svc.filter { !it.ok }.forEach { InfoText("${it.name} : ${it.label}") }
    }
}

@Composable
private fun TunnelsCard(t: List<Tunnel>) {
    SectionCard("Tunnels VPN IPsec") {
        t.forEach { x ->
            Row(verticalAlignment = Alignment.CenterVertically) {
                Dot(
                    when {
                        x.status == 1 -> Green
                        x.status == 2 -> Orange
                        x.activated == 1 -> Red
                        else -> Grey
                    },
                )
                Spacer(Modifier.width(8.dp))
                Column(Modifier.weight(1f)) {
                    Text(x.name)
                    InfoText(listOfNotNull(x.typeLabel.ifBlank { null }, x.description).joinToString(" · "))
                }
                Text(x.statusLabel, style = MaterialTheme.typography.bodySmall)
            }
        }
    }
}

@Composable
private fun LicencesCard(l: List<License>) {
    SectionCard("Licences") {
        l.forEach { x ->
            val days = x.daysLeft()
            val color = when {
                x.status == 4 || (days != null && days < 0) -> Red
                days != null && days <= 30 -> Orange
                x.status == 3 || x.status == 1 -> Green
                else -> Grey
            }
            Row(verticalAlignment = Alignment.CenterVertically) {
                Dot(color)
                Spacer(Modifier.width(8.dp))
                Column(Modifier.weight(1f)) {
                    Text(x.module)
                    InfoText(x.statusLabel + (x.expiry?.let { " · jusqu'au $it" } ?: ""))
                }
                if (days != null && x.owned) Text(if (days < 0) "expirée" else "$days j", style = MaterialTheme.typography.bodySmall)
            }
        }
    }
}
