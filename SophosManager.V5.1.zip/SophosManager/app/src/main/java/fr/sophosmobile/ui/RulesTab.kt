package fr.sophosmobile.ui

import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.MoreVert
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material3.Card
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.ExtendedFloatingActionButton
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.SnackbarHostState
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.AlertDialog
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import fr.sophosmobile.net.ruleOptions
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import fr.sophosmobile.net.FwRule
import fr.sophosmobile.net.RuleDraft
import fr.sophosmobile.net.SophosApi
import fr.sophosmobile.net.deleteRule
import fr.sophosmobile.net.duplicateRule
import fr.sophosmobile.net.moveRule

@Composable
fun ListHeader(text: String, loading: Boolean, onRefresh: () -> Unit) {
    Row(verticalAlignment = Alignment.CenterVertically) {
        Text(text, Modifier.weight(1f), style = MaterialTheme.typography.titleSmall)
        IconButton(onClick = onRefresh, enabled = !loading) { Icon(Icons.Default.Refresh, contentDescription = "Actualiser") }
    }
}

sealed interface RuleEdit {
    data object New : RuleEdit
    data class Existing(val rule: FwRule) : RuleEdit
}

@Composable
fun RulesTab(api: SophosApi, snackbar: SnackbarHostState) {
    val loader = rememberLoader(api) { api.rules() }
    LaunchedEffect(api) {
        // Préchauffe le cache des objets pour que l'éditeur s'ouvre avec les listes déjà prêtes.
        withContext(Dispatchers.IO) { runCatching { api.ruleOptions() } }
    }
    val scope = rememberCoroutineScope()
    var busy by remember { mutableStateOf(false) }
    var confirmOff by remember { mutableStateOf<FwRule?>(null) }
    var confirmDelete by remember { mutableStateOf<FwRule?>(null) }
    var duplicate by remember { mutableStateOf<FwRule?>(null) }
    var editing by remember { mutableStateOf<RuleEdit?>(null) }
    var filter by remember { mutableStateOf("") }

    fun act(msg: String, block: () -> Unit) {
        busy = true
        scope.runAction(snackbar, msg, after = { busy = false; loader.reload() }, block = block)
    }

    Box(Modifier.fillMaxSize()) {
        LazyColumn(
            Modifier.fillMaxSize(),
            contentPadding = PaddingValues(start = 16.dp, end = 16.dp, top = 8.dp, bottom = 96.dp),
            verticalArrangement = Arrangement.spacedBy(8.dp),
        ) {
            val all = loader.data
            item { ListHeader(all?.let { "${it.size} règles, dans l'ordre d'évaluation" } ?: "Règles", loader.loading) { loader.reload() } }
            item {
                OutlinedTextField(filter, { filter = it }, label = { Text("Filtrer") }, singleLine = true, modifier = Modifier.fillMaxWidth())
            }
            loader.error?.let { item { ErrorBox(it) { loader.reload() } } }
            if (all == null && loader.loading) item { CenteredLoading() }
            val rules = all?.filter { filter.isBlank() || it.name.contains(filter, true) } ?: emptyList()
            itemsIndexed(rules, key = { _, r -> r.name }) { _, r ->
                val list = all!!
                val idx = list.indexOf(r)
                RuleCard(
                    r, idx + 1, enabled = !busy,
                    onOpen = { editing = RuleEdit.Existing(r) },
                    onToggle = { on ->
                        if (on) {
                            act("${r.name} activée") { api.setRuleEnabledCompat(r, true) }
                        } else {
                            confirmOff = r
                        }
                    },
                    onMenu = { action ->
                        when (action) {
                            "edit" -> editing = RuleEdit.Existing(r)
                            "dup" -> duplicate = r
                            "top" -> act("${r.name} placée en tête") { api.moveRule(r, "Top") }
                            "bottom" -> act("${r.name} placée en fin") { api.moveRule(r, "Bottom") }
                            "up" -> list.getOrNull(idx - 1)?.let { prev -> act("${r.name} montée") { api.moveRule(r, "Before", prev.name) } }
                            "down" -> list.getOrNull(idx + 1)?.let { next -> act("${r.name} descendue") { api.moveRule(r, "After", next.name) } }
                            "delete" -> confirmDelete = r
                        }
                    },
                )
            }
        }
        ExtendedFloatingActionButton(
            onClick = { editing = RuleEdit.New },
            icon = { Icon(Icons.Default.Add, null) },
            text = { Text("Nouvelle règle") },
            modifier = Modifier.align(Alignment.BottomEnd).padding(16.dp),
        )
    }

    editing?.let { e ->
        RuleEditor(api, e, snackbar, onClose = { editing = null }, onSaved = { editing = null; loader.reload() })
    }

    confirmOff?.let { r ->
        ConfirmDialog(
            title = "Désactiver « ${r.name} » ?",
            text = "Le trafic concerné ne sera plus traité par cette règle. L'accès d'administration depuis le LAN dépend de « Device access », pas des règles : tu ne perds pas la main sur le pare-feu.",
            confirm = "Désactiver",
            onConfirm = { act("${r.name} désactivée") { api.setRuleEnabledCompat(r, false) } },
            onDismiss = { confirmOff = null },
        )
    }
    confirmDelete?.let { r ->
        ConfirmDialog(
            title = "Supprimer « ${r.name} » ?",
            text = "La règle sera définitivement supprimée du pare-feu.",
            confirm = "Supprimer",
            onConfirm = { act("${r.name} supprimée") { api.deleteRule(r) } },
            onDismiss = { confirmDelete = null },
        )
    }
    duplicate?.let { r ->
        var name by remember(r) { mutableStateOf("${r.name} (copie)") }
        AlertDialog(
            onDismissRequest = { duplicate = null },
            title = { Text("Dupliquer « ${r.name} »") },
            text = {
                Column {
                    OutlinedTextField(name, { name = it }, label = { Text("Nom de la copie") }, singleLine = true)
                    InfoText("La copie est créée désactivée, juste après l'originale.")
                }
            },
            confirmButton = {
                TextButton(enabled = name.isNotBlank() && !name.contains(','), onClick = {
                    duplicate = null
                    act("Copie créée") { api.duplicateRule(r, name.trim()) }
                }) { Text("Dupliquer") }
            },
            dismissButton = { TextButton(onClick = { duplicate = null }) { Text("Annuler") } },
        )
    }
}

private fun SophosApi.setRuleEnabledCompat(r: FwRule, on: Boolean) = setRuleEnabled(r, on)

@Composable
private fun RuleCard(r: FwRule, position: Int, enabled: Boolean, onOpen: () -> Unit, onToggle: (Boolean) -> Unit, onMenu: (String) -> Unit) {
    var menu by remember { mutableStateOf(false) }
    val d = remember(r) { RuleDraft.from(r) }
    Card(Modifier.fillMaxWidth().clickable(onClick = onOpen)) {
        Row(Modifier.padding(start = 12.dp, end = 0.dp, top = 10.dp, bottom = 10.dp), verticalAlignment = Alignment.CenterVertically) {
            Text("$position", style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
            Spacer(Modifier.width(8.dp))
            Column(Modifier.weight(1f)) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    val a = r.action ?: "?"
                    Pill(a, if (a.equals("Accept", true)) Green else Red)
                    Spacer(Modifier.width(8.dp))
                    Text(r.name, style = MaterialTheme.typography.titleSmall)
                }
                val sz = d.srcZones.ifEmpty { listOf("Any") }.joinToString(",")
                val dz = d.dstZones.ifEmpty { listOf("Any") }.joinToString(",")
                InfoText("$sz → $dz")
                val src = r.sources.ifEmpty { listOf("Any") }.joinToString(", ")
                val dst = r.destinations.ifEmpty { listOf("Any") }.joinToString(", ")
                InfoText("$src → $dst · ${d.services.ifEmpty { listOf("Tous services") }.joinToString(", ")}")
                val sec = listOfNotNull(
                    d.ips.takeIf { it != "None" }?.let { "IPS" },
                    d.webFilter.takeIf { it != "None" }?.let { "Web" },
                    d.appControl.takeIf { it != "None" }?.let { "Applis" },
                    "AV".takeIf { d.scanVirus },
                )
                if (sec.isNotEmpty() && d.action == "Accept") InfoText("Protection : ${sec.joinToString(", ")}")
                if (r.name in SophosApi.BLOCK_RULES) InfoText("Règle du blocage rapide")
            }
            Switch(checked = r.enabled, enabled = enabled, onCheckedChange = onToggle)
            Box {
                IconButton(onClick = { menu = true }, enabled = enabled) { Icon(Icons.Default.MoreVert, contentDescription = "Actions") }
                DropdownMenu(expanded = menu, onDismissRequest = { menu = false }) {
                    listOf(
                        "edit" to "Modifier", "dup" to "Dupliquer", "up" to "Monter d'un cran", "down" to "Descendre d'un cran",
                        "top" to "Placer en tête", "bottom" to "Placer en fin", "delete" to "Supprimer",
                    ).forEach { (k, l) ->
                        DropdownMenuItem(text = { Text(l) }, onClick = { menu = false; onMenu(k) })
                    }
                }
            }
        }
    }
}
