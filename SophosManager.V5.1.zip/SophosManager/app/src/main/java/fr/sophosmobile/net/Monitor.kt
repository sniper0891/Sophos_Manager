package fr.sophosmobile.net

data class IfStat(
    val index: String,
    val name: String,
    val up: Boolean,
    val inOctets: Long?,
    val outOctets: Long?,
    /** Débits en bits/s, calculés entre deux mesures. */
    val inBps: Double? = null,
    val outBps: Double? = null,
)

data class Snapshot(
    val time: Long,
    val sysName: String?,
    val descr: String?,
    val uptimeSec: Long?,
    val cpu: Int?,
    val ramPct: Int?,
    val ramUsedMb: Long?,
    val ramTotalMb: Long?,
    val diskPct: Int?,
    val ifs: List<IfStat>,
)

/** Surveillance par SNMP : MIB standard (HOST-RESOURCES et IF-MIB). */
class Monitor(host: String, community: String, port: Int = 161) {
    private val snmp = Snmp(SophosClient.hostOnly(host), community, port)
    private var previous: Snapshot? = null

    fun sample(): Snapshot {
        val sys = snmp.get(SYS_DESCR, SYS_UPTIME, SYS_NAME)
        val hrUptime = runCatching { snmp.get(HR_UPTIME)[HR_UPTIME].num() }.getOrNull()

        val cpu = runCatching {
            val loads = snmp.walk(HR_PROC_LOAD).mapNotNull { it.second.num() }
            if (loads.isEmpty()) null else loads.average().toInt()
        }.getOrNull() ?: runCatching {
            // Repli : UCD-SNMP (net-snmp), pourcentage d'inactivité du CPU.
            snmp.get(UCD_CPU_IDLE)[UCD_CPU_IDLE].num()?.let { (100 - it).toInt().coerceIn(0, 100) }
        }.getOrNull()

        var ramPct: Int? = null
        var ramUsed: Long? = null
        var ramTotal: Long? = null
        var diskPct: Int? = null
        runCatching {
            val types = snmp.walk(HR_ST_TYPE).associate { it.first.substringAfterLast('.') to (it.second as? Snmp.Value.Oid)?.v }
            val descr = snmp.walk(HR_ST_DESCR).associate { it.first.substringAfterLast('.') to it.second.str().orEmpty() }
            val units = snmp.walk(HR_ST_UNITS).associate { it.first.substringAfterLast('.') to (it.second.num() ?: 1L) }
            val size = snmp.walk(HR_ST_SIZE).associate { it.first.substringAfterLast('.') to (it.second.num() ?: 0L) }
            val used = snmp.walk(HR_ST_USED).associate { it.first.substringAfterLast('.') to (it.second.num() ?: 0L) }
            fun bytes(map: Map<String, Long>, i: String) = (map[i] ?: 0L) * (units[i] ?: 1L)

            val ram = types.entries.firstOrNull { it.value?.trim('.') == HR_TYPE_RAM }?.key
            if (ram != null) {
                val total = bytes(size, ram)
                var u = bytes(used, ram)
                // Linux compte le cache et les tampons comme « utilisés » : on les retire.
                descr.forEach { (i, d) ->
                    if (d.equals("Cached memory", true) || d.equals("Memory buffers", true)) u -= bytes(used, i)
                }
                if (total > 0) {
                    u = u.coerceIn(0, total)
                    ramTotal = total / 1_048_576
                    ramUsed = u / 1_048_576
                    ramPct = (u * 100 / total).toInt()
                }
            }
            val disks = types.filter { it.value?.trim('.') == HR_TYPE_DISK }.keys
            val biggest = disks.maxByOrNull { bytes(size, it) }
            if (biggest != null && bytes(size, biggest) > 0) {
                diskPct = (bytes(used, biggest) * 100 / bytes(size, biggest)).toInt()
            }
        }

        val names = runCatching { snmp.walk(IF_NAME) }.getOrDefault(emptyList())
            .associate { it.first.substringAfterLast('.') to it.second.str().orEmpty() }
        val oper = runCatching { snmp.walk(IF_OPER) }.getOrDefault(emptyList())
            .associate { it.first.substringAfterLast('.') to it.second.num() }
        val inO = runCatching { snmp.walk(IF_HC_IN) }.getOrDefault(emptyList())
            .associate { it.first.substringAfterLast('.') to it.second.num() }
        val outO = runCatching { snmp.walk(IF_HC_OUT) }.getOrDefault(emptyList())
            .associate { it.first.substringAfterLast('.') to it.second.num() }

        val now = System.currentTimeMillis()
        val prev = previous
        val dt = prev?.let { (now - it.time) / 1000.0 }?.takeIf { it > 0.5 }
        val ifs = names.filter { (_, n) -> n.isNotBlank() && n != "lo" && !n.startsWith("ipsec") }
            .map { (i, n) ->
                val p = prev?.ifs?.firstOrNull { it.index == i }
                fun rate(cur: Long?, old: Long?) =
                    if (dt != null && cur != null && old != null && cur >= old) (cur - old) * 8 / dt else null
                IfStat(
                    index = i, name = n, up = oper[i] == 1L,
                    inOctets = inO[i], outOctets = outO[i],
                    inBps = rate(inO[i], p?.inOctets), outBps = rate(outO[i], p?.outOctets),
                )
            }
            .sortedWith(compareBy({ !it.up }, { it.name }))

        val snap = Snapshot(
            time = now,
            sysName = sys[SYS_NAME].str(),
            descr = sys[SYS_DESCR].str(),
            uptimeSec = (hrUptime ?: sys[SYS_UPTIME].num())?.div(100),
            cpu = cpu, ramPct = ramPct, ramUsedMb = ramUsed, ramTotalMb = ramTotal,
            diskPct = diskPct, ifs = ifs,
        )
        previous = snap
        return snap
    }

    companion object {
        const val SYS_DESCR = "1.3.6.1.2.1.1.1.0"
        const val SYS_UPTIME = "1.3.6.1.2.1.1.3.0"
        const val SYS_NAME = "1.3.6.1.2.1.1.5.0"
        const val HR_UPTIME = "1.3.6.1.2.1.25.1.1.0"
        const val UCD_CPU_IDLE = "1.3.6.1.4.1.2021.11.11.0"
        const val HR_PROC_LOAD = "1.3.6.1.2.1.25.3.3.1.2"
        const val HR_ST_TYPE = "1.3.6.1.2.1.25.2.3.1.2"
        const val HR_ST_DESCR = "1.3.6.1.2.1.25.2.3.1.3"
        const val HR_ST_UNITS = "1.3.6.1.2.1.25.2.3.1.4"
        const val HR_ST_SIZE = "1.3.6.1.2.1.25.2.3.1.5"
        const val HR_ST_USED = "1.3.6.1.2.1.25.2.3.1.6"
        const val HR_TYPE_RAM = "1.3.6.1.2.1.25.2.1.2"
        const val HR_TYPE_DISK = "1.3.6.1.2.1.25.2.1.4"
        const val IF_OPER = "1.3.6.1.2.1.2.2.1.8"
        const val IF_NAME = "1.3.6.1.2.1.31.1.1.1.1"
        const val IF_HC_IN = "1.3.6.1.2.1.31.1.1.1.6"
        const val IF_HC_OUT = "1.3.6.1.2.1.31.1.1.1.10"
    }
}

fun formatBps(bps: Double?): String = when {
    bps == null -> "—"
    bps >= 1e9 -> "%.2f Gb/s".format(bps / 1e9)
    bps >= 1e6 -> "%.1f Mb/s".format(bps / 1e6)
    bps >= 1e3 -> "%.0f kb/s".format(bps / 1e3)
    else -> "%.0f b/s".format(bps)
}

fun formatUptime(sec: Long?): String {
    if (sec == null) return "—"
    val d = sec / 86_400
    val h = (sec % 86_400) / 3_600
    val m = (sec % 3_600) / 60
    return if (d > 0) "${d} j ${h} h" else "${h} h ${m} min"
}
