package fr.sophosmobile.net

import java.time.LocalDate
import java.time.format.DateTimeFormatter
import java.time.temporal.ChronoUnit
import java.util.Locale

data class SfosInfo(
    val name: String?,
    val model: String?,
    val firmware: String?,
    val ipsVersion: String?,
    val webcatVersion: String?,
    val date: String?,
    val liveUsers: Long?,
    val httpHits: Long?,
    val tcpEstablished: Long?,
    val diskPct: Int?,
    val memPct: Int?,
    val swapPct: Int?,
    val temps: List<Pair<String, Double>>,
)

data class ServiceState(val key: Int, val name: String, val code: Int) {
    /** 0 = jamais démarré, 7 = non enregistré : service non utilisé, on l'ignore. */
    val relevant get() = code != 0 && code != 7
    val ok get() = code == 3 || code == 2
    val label get() = when (code) {
        0 -> "inutilisé"; 1 -> "arrêté"; 2 -> "démarrage"; 3 -> "en marche"
        4 -> "arrêt en cours"; 5 -> "planté"; 6 -> "figé"; 7 -> "non enregistré"; else -> "?"
    }
}

data class License(val module: String, val status: Int, val expiry: String?) {
    val statusLabel get() = when (status) {
        0 -> "aucune"; 1 -> "évaluation"; 2 -> "non souscrite"; 3 -> "active"
        4 -> "expirée"; 5 -> "désactivée"; else -> "?"
    }
    val owned get() = status == 1 || status == 3 || status == 4
    fun daysLeft(): Long? = parseDate(expiry)?.let { ChronoUnit.DAYS.between(LocalDate.now(), it) }

    companion object {
        private val formats = listOf(
            "MMM dd yyyy", "MMM d yyyy", "dd MMM yyyy", "d MMM yyyy", "yyyy-MM-dd",
            "dd/MM/yyyy", "MM/dd/yyyy", "yyyy/MM/dd", "dd-MM-yyyy", "MMM dd, yyyy",
        ).map { DateTimeFormatter.ofPattern(it, Locale.ENGLISH) }

        fun parseDate(s: String?): LocalDate? {
            val t = s?.trim()?.replace(Regex("\\s+"), " ") ?: return null
            if (t.isEmpty() || t.equals("fail", true) || t.equals("N/A", true)) return null
            for (f in formats) runCatching { return LocalDate.parse(t, f) }
            return null
        }
    }
}

data class Tunnel(val name: String, val description: String?, val status: Int?, val activated: Int?, val type: Int?) {
    val statusLabel get() = when (status) { 1 -> "actif"; 2 -> "partiellement actif"; 0 -> "inactif"; else -> "?" }
    val typeLabel get() = when (type) { 1 -> "hôte à hôte"; 2 -> "site à site"; 3 -> "interface tunnel"; else -> "" }
}

data class HaInfo(val enabled: Boolean, val current: Int?, val peer: Int?, val mode: String?) {
    companion object {
        fun stateLabel(s: Int?) = when (s) {
            0 -> "non applicable"; 1 -> "auxiliaire"; 2 -> "autonome"; 3 -> "primaire"
            4 -> "en défaut"; 5 -> "prêt"; else -> "?"
        }
    }
}

data class ApInfo(val name: String, val model: String?, val ip: String?, val connected: Boolean, val clients: Long?)
data class ArpEntry(val ip: String, val mac: String, val iface: String)
data class RouteEntry(val dest: String, val mask: String, val nextHop: String, val iface: String)
data class IfDetail(
    val name: String, val alias: String?, val mac: String?, val speedMbps: Long?, val up: Boolean,
    val inErrors: Long?, val outErrors: Long?, val inDiscards: Long?, val outDiscards: Long?,
)

/** Lecture de la MIB propriétaire Sophos (SFOS-FIREWALL-MIB) et de quelques tables standard. */
class SfosSnmp(host: String, community: String, port: Int = 161) {
    private val snmp = Snmp(SophosClient.hostOnly(host), community, port)

    private fun idx(oid: String) = oid.substringAfterLast('.')

    fun info(): SfosInfo {
        val v = snmp.get(
            "$B.1.1.0", "$B.1.2.0", "$B.1.3.0", "$B.1.5.0", "$B.1.6.0",
            "$B.2.1.0", "$B.2.6.0", "$B.2.7.0", "$B.2.4.2.0", "$B.2.5.2.0", "$B.2.5.4.0", TCP_ESTAB,
        )
        val temps = runCatching {
            snmp.walk("$B.9").mapNotNull { (oid, value) ->
                val n = value.num() ?: return@mapNotNull null
                val label = when {
                    oid.startsWith("$B.9.1") -> "NPU"
                    oid.startsWith("$B.9.2") -> "CPU"
                    else -> "Capteur"
                }
                label to n / 10.0
            }.filter { it.second in 1.0..150.0 }
        }.getOrDefault(emptyList())
        return SfosInfo(
            name = v["$B.1.1.0"].str(), model = v["$B.1.2.0"].str(), firmware = v["$B.1.3.0"].str(),
            webcatVersion = v["$B.1.5.0"].str(), ipsVersion = v["$B.1.6.0"].str(), date = v["$B.2.1.0"].str(),
            liveUsers = v["$B.2.6.0"].num(), httpHits = v["$B.2.7.0"].num(), tcpEstablished = v[TCP_ESTAB].num(),
            diskPct = v["$B.2.4.2.0"].num()?.toInt(), memPct = v["$B.2.5.2.0"].num()?.toInt(),
            swapPct = v["$B.2.5.4.0"].num()?.toInt(), temps = temps,
        )
    }

    fun services(): List<ServiceState> {
        val oids = SERVICES.keys.map { "$B.3.$it.0" }
        val v = snmp.get(*oids.toTypedArray())
        return SERVICES.mapNotNull { (k, name) ->
            v["$B.3.$k.0"].num()?.let { ServiceState(k, name, it.toInt()) }
        }.sortedBy { it.name }
    }

    fun licences(): List<License> {
        val oids = LICENCES.keys.flatMap { listOf("$B.5.$it.1.0", "$B.5.$it.2.0") }
        val v = snmp.get(*oids.toTypedArray())
        return LICENCES.mapNotNull { (k, name) ->
            val st = v["$B.5.$k.1.0"].num() ?: return@mapNotNull null
            License(name, st.toInt(), v["$B.5.$k.2.0"].str())
        }
    }

    fun tunnels(): List<Tunnel> {
        val base = "$B.6.1.1.1.1"
        val names = snmp.walk("$base.2").associate { idx(it.first) to it.second.str().orEmpty() }
        if (names.isEmpty()) return emptyList()
        val desc = snmp.walk("$base.3").associate { idx(it.first) to it.second.str() }
        val type = snmp.walk("$base.6").associate { idx(it.first) to it.second.num()?.toInt() }
        val status = snmp.walk("$base.9").associate { idx(it.first) to it.second.num()?.toInt() }
        val act = snmp.walk("$base.10").associate { idx(it.first) to it.second.num()?.toInt() }
        return names.map { (i, n) -> Tunnel(n, desc[i]?.ifBlank { null }, status[i], act[i], type[i]) }.sortedBy { it.name }
    }

    fun ha(): HaInfo? {
        val v = snmp.get("$B.4.1.0", "$B.4.4.0", "$B.4.5.0", "$B.4.6.0")
        val st = v["$B.4.1.0"].num() ?: return null
        return HaInfo(st == 1L, v["$B.4.4.0"].num()?.toInt(), v["$B.4.5.0"].num()?.toInt(), v["$B.4.6.0"].str())
    }

    fun accessPoints(): List<ApInfo> {
        val base = "$B.7.1.1"
        val names = snmp.walk("$base.1")
        if (names.isEmpty()) return emptyList()
        val suffix = { oid: String -> oid.removePrefix("$base.1.") }
        val model = snmp.walk("$base.2").associate { it.first.removePrefix("$base.2.") to it.second.str() }
        val ip = snmp.walk("$base.3").associate { it.first.removePrefix("$base.3.") to ipOf(it.second) }
        val st = snmp.walk("$base.5").associate { it.first.removePrefix("$base.5.") to it.second.num() }
        val cl = snmp.walk("$base.6").associate { it.first.removePrefix("$base.6.") to it.second.num() }
        return names.map { (oid, v) ->
            val s = suffix(oid)
            ApInfo(v.str().orEmpty(), model[s], ip[s], st[s] == 0L, cl[s])
        }
    }

    private fun ifNames(): Map<String, String> =
        snmp.walk(Monitor.IF_NAME).associate { idx(it.first) to it.second.str().orEmpty() }

    fun arp(): List<ArpEntry> {
        val names = ifNames()
        val root = "1.3.6.1.2.1.4.22.1.2"
        return snmp.walk(root).mapNotNull { (oid, v) ->
            val rest = oid.removePrefix("$root.").split('.')
            if (rest.size < 5) return@mapNotNull null
            val mac = macOf(v) ?: return@mapNotNull null
            if (mac == "00:00:00:00:00:00") return@mapNotNull null
            ArpEntry(rest.takeLast(4).joinToString("."), mac, names[rest[0]] ?: rest[0])
        }.sortedBy { it.ip.split('.').fold(0L) { a, b -> a * 256 + (b.toLongOrNull() ?: 0) } }
    }

    fun routes(): List<RouteEntry> {
        val names = ifNames()
        val r = "1.3.6.1.2.1.4.21.1"
        val dest = snmp.walk("$r.1")
        if (dest.isNotEmpty()) {
            val key = { o: String, col: Int -> o.removePrefix("$r.$col.") }
            val ifx = snmp.walk("$r.2").associate { key(it.first, 2) to it.second.num()?.toString() }
            val nh = snmp.walk("$r.7").associate { key(it.first, 7) to ipOf(it.second) }
            val mask = snmp.walk("$r.11").associate { key(it.first, 11) to ipOf(it.second) }
            return dest.map { (o, v) ->
                val k = key(o, 1)
                RouteEntry(ipOf(v) ?: k, mask[k] ?: "?", nh[k] ?: "?", ifx[k]?.let { names[it] ?: it } ?: "?")
            }
        }
        // Repli : ipCidrRouteTable (index = dest.masque.tos.nexthop)
        val c = "1.3.6.1.2.1.4.24.4.1"
        return snmp.walk("$c.5").mapNotNull { (o, v) ->
            val p = o.removePrefix("$c.5.").split('.')
            if (p.size < 13) return@mapNotNull null
            RouteEntry(
                p.subList(0, 4).joinToString("."), p.subList(4, 8).joinToString("."),
                p.subList(9, 13).joinToString("."), v.num()?.toString()?.let { names[it] ?: it } ?: "?",
            )
        }
    }

    fun interfaces(): List<IfDetail> {
        val names = ifNames()
        fun col(oid: String) = runCatching { snmp.walk(oid) }.getOrDefault(emptyList()).associate { idx(it.first) to it.second }
        val alias = col("1.3.6.1.2.1.31.1.1.1.18")
        val speed = col("1.3.6.1.2.1.31.1.1.1.15")
        val mac = col("1.3.6.1.2.1.2.2.1.6")
        val oper = col(Monitor.IF_OPER)
        val inE = col("1.3.6.1.2.1.2.2.1.14")
        val outE = col("1.3.6.1.2.1.2.2.1.20")
        val inD = col("1.3.6.1.2.1.2.2.1.13")
        val outD = col("1.3.6.1.2.1.2.2.1.19")
        return names.filter { it.value.isNotBlank() && it.value != "lo" }.map { (i, n) ->
            IfDetail(
                n, alias[i].str()?.ifBlank { null }, macOf(mac[i]), speed[i].num()?.takeIf { it > 0 },
                oper[i].num() == 1L, inE[i].num(), outE[i].num(), inD[i].num(), outD[i].num(),
            )
        }.sortedWith(compareBy({ !it.up }, { it.name }))
    }

    companion object {
        const val B = "1.3.6.1.4.1.2604.5.1"
        const val TCP_ESTAB = "1.3.6.1.2.1.6.9.0"

        val SERVICES = mapOf(
            1 to "POP3", 2 to "IMAP4", 3 to "SMTP", 4 to "FTP", 5 to "Proxy web", 6 to "Antivirus",
            7 to "Antispam", 8 to "DNS", 9 to "Haute dispo", 10 to "IPS", 11 to "Console web",
            12 to "NTP", 13 to "Tomcat", 14 to "SSL VPN", 15 to "IPsec VPN", 16 to "Base de données",
            17 to "Réseau", 18 to "Journaux (Garner)", 19 to "Routage dynamique", 20 to "SSH",
            21 to "Passerelles (DGD)",
        )

        /** Services dont l'arrêt compromet la protection. */
        val CRITICAL_SERVICES = setOf(6, 8, 10, 16, 17)

        val LICENCES = mapOf(
            1 to "Base Firewall", 2 to "Network Protection", 3 to "Web Protection", 4 to "Email Protection",
            5 to "Web Server Protection", 6 to "Zero-Day Protection", 7 to "Support Enhanced",
            8 to "Support Enhanced Plus", 9 to "Central Orchestration",
        )

        fun ipOf(v: Snmp.Value?): String? {
            val b = (v as? Snmp.Value.Bytes)?.v ?: return null
            return if (b.size == 4) b.joinToString(".") { (it.toInt() and 0xFF).toString() } else null
        }

        fun macOf(v: Snmp.Value?): String? {
            val b = (v as? Snmp.Value.Bytes)?.v ?: return null
            return if (b.size == 6) b.joinToString(":") { "%02X".format(it) } else null
        }
    }
}
