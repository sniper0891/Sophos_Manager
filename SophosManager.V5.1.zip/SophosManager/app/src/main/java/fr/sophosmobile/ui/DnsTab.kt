package fr.sophosmobile.ui

import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Card
import androidx.compose.material3.ExtendedFloatingActionButton
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.SnackbarHostState
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import fr.sophosmobile.net.DnsEntry
import fr.sophosmobile.net.SophosApi
import fr.sophosmobile.net.deleteDnsEntry
import fr.sophosmobile.net.dnsEntries
import fr.sophosmobile.net.dnsSettings
import fr.sophosmobile.net.saveDnsEntry

private data class DnsData(val entries: List<DnsEntry>, val settings: List<Pair<String, String>>)

@Composable
fun DnsTab(api: SophosApi, snackbar: SnackbarHostState) {
    val loader = rememberLoader(api) { DnsData(api.dnsEntries(), runCatching { api.dnsSettings() }.getOrDefault(emptyList())) }
    val scope = rememberCoroutineScope()
    var editing by remember { mutableStateOf<DnsEntry?>(null) }
    var creating by remember { mutableStateOf(false) }
    var toDelete by remember { mutableStateOf<DnsEntry?>(null) }

    Box(Modifier.fillMaxSize()) {
        LazyColumn(
            Modifier.fillMaxSize(),
            contentPadding = PaddingValues(start = 16.dp, end = 16.dp, top = 8.dp, bottom = 96.dp),
            verticalArrangement = Arrangement.spacedBy(8.dp),
        ) {
            val d = loader.data
            item { ListHeader("Entrées DNS locales", loader.loading) { loader.reload() } }
            loader.error?.let { item { ErrorBox(it) { loader.reload() } } }
            if (d == null && loader.loading) item { CenteredLoading() }
            if (d != null && d.entries.isEmpty()) item { EmptyText("Aucune entrée. Ajoute par exemple nas.maison → 192.168.1.10.") }
            items(d?.entries ?: emptyList(), key = { it.host }) { e ->
                Card(Modifier.fillMaxWidth().clickable { editing = e }) {
                    Row(Modifier.padding(start = 16.dp, end = 4.dp, top = 8.dp, bottom = 8.dp), verticalAlignment = Alignment.CenterVertically) {
                        Column(Modifier.weight(1f)) {
                            Text(e.host, style = MaterialTheme.typography.titleSmall)
                            InfoText(e.ips.joinToString(", ") + if (e.reverse) " · DNS inverse" else "")
                        }
                        IconButton(onClick = { toDelete = e }) { Icon(Icons.Default.Delete, contentDescription = "Supprimer") }
                    }
                }
            }
            if (d != null && d.settings.isNotEmpty()) {
                item {
                    SectionCard("Configuration DNS du pare-feu") {
                        d.settings.forEach { (k, v) -> KeyValue(k, v) }
                        InfoText("Lecture seule. Ces entrées ne répondent qu'aux appareils qui utilisent le pare-feu comme serveur DNS.")
                    }
                }
            }
        }
        ExtendedFloatingActionButton(
            onClick = { creating = true },
            icon = { Icon(Icons.Default.Add, null) },
            text = { Text("Ajouter") },
            modifier = Modifier.align(Alignment.BottomEnd).padding(16.dp),
        )
    }

    if (creating || editing != null) {
        val e = editing
        DnsDialog(e, onDismiss = { creating = false; editing = null }) { host, ips, rev ->
            creating = false
            editing = null
            scope.runAction(snackbar, "$host enregistré", after = { loader.reload() }) { api.saveDnsEntry(host, ips, rev, isNew = e == null) }
        }
    }
    toDelete?.let { e ->
        ConfirmDialog(
            title = "Supprimer ${e.host} ?", text = "L'entrée DNS sera supprimée du pare-feu.", confirm = "Supprimer",
            onConfirm = { scope.runAction(snackbar, "${e.host} supprimé", after = { loader.reload() }) { api.deleteDnsEntry(e) } },
            onDismiss = { toDelete = null },
        )
    }
}

@Composable
private fun DnsDialog(existing: DnsEntry?, onDismiss: () -> Unit, onSave: (String, List<String>, Boolean) -> Unit) {
    var host by remember { mutableStateOf(existing?.host ?: "") }
    var ips by remember { mutableStateOf(existing?.ips?.joinToString(", ") ?: "") }
    var rev by remember { mutableStateOf(existing?.reverse ?: false) }
    val list = ips.split(',', ' ', ';').map { it.trim() }.filter { it.isNotEmpty() }
    val ok = host.contains('.') && list.isNotEmpty() && list.all { SophosApi.IPV4.matches(it) }
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text(if (existing == null) "Nouvelle entrée DNS" else existing.host) },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                OutlinedTextField(host, { host = it.trim().lowercase() }, label = { Text("Nom complet") }, placeholder = { Text("nas.maison") }, singleLine = true, enabled = existing == null)
                OutlinedTextField(ips, { ips = it }, label = { Text("Adresse(s) IP") }, placeholder = { Text("192.168.1.10") }, singleLine = true, isError = ips.isNotBlank() && !ok)
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text("Créer le DNS inverse (PTR)", Modifier.weight(1f))
                    Switch(rev, { rev = it })
                }
            }
        },
        confirmButton = { TextButton(enabled = ok, onClick = { onSave(host, list, rev) }) { Text("Enregistrer") } },
        dismissButton = { TextButton(onClick = onDismiss) { Text("Annuler") } },
    )
}
