package fr.sophosmobile.net

import java.net.ConnectException
import java.net.NoRouteToHostException
import java.net.SocketTimeoutException
import java.net.UnknownHostException
import javax.net.ssl.SSLException

class SophosException(message: String, val kind: Kind = Kind.Other) : Exception(message) {
    enum class Kind { Offline, Auth, IpNotAllowed, Cert, Api, Other }
}

/** Le certificat du pare-feu ne correspond plus à celui mémorisé. */
class CertificateChangedException(val expected: String, val actual: String) :
    java.security.cert.CertificateException("Certificat modifié")

fun Throwable.findCertChange(): CertificateChangedException? {
    var t: Throwable? = this
    while (t != null) {
        if (t is CertificateChangedException) return t
        t = t.cause
    }
    return null
}

fun mapNetwork(e: Throwable): SophosException = when {
    e is SophosException -> e
    e.findCertChange() != null -> SophosException(
        "Le certificat du pare-feu a changé depuis la dernière connexion. " +
            "Si c'est normal (renouvellement), réinitialise-le dans la fiche du pare-feu.",
        SophosException.Kind.Cert,
    )
    e is SocketTimeoutException || e is ConnectException || e is NoRouteToHostException || e is UnknownHostException ->
        SophosException("Pare-feu injoignable. Vérifie que le téléphone est bien sur le réseau local.", SophosException.Kind.Offline)
    e is SSLException -> SophosException("Erreur TLS : ${e.message ?: "inconnue"}", SophosException.Kind.Other)
    else -> SophosException(e.message ?: e.javaClass.simpleName)
}

fun Throwable.friendly(): String = mapNetwork(this).message ?: "Erreur inconnue"
