package fr.sophosmobile.ui

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.FilterChip
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import fr.sophosmobile.data.AlertLog
import fr.sophosmobile.data.Firewall
import fr.sophosmobile.data.History
import fr.sophosmobile.data.Sample
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

private data class ReportData(val samples: List<Sample>, val alerts: List<AlertLog>)

/** Rapports construits à partir de l'historique enregistré par la surveillance en arrière-plan. */
@Composable
fun ReportsTab(fw: Firewall) {
    val ctx = LocalContext.current
    val history = remember(fw.id) { History(ctx, fw.id) }
    var hours by rememberSaveable { mutableStateOf(24) }
    var confirmClear by remember { mutableStateOf(false) }
    val loader = rememberLoader(fw.id) { ReportData(history.samples(), history.alerts()) }

    LazyColumn(
        Modifier.fillMaxSize(),
        contentPadding = PaddingValues(16.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp),
    ) {
        item { ListHeader("Rapports", loader.loading) { loader.reload() } }
        if (!fw.alertsEnabled) {
            item { ErrorBox("Active « Surveillance en arrière-plan » dans la fiche du pare-feu : c'est cette surveillance qui enregistre l'historique (toutes les 15 min, sur le réseau local).") }
        }
        item {
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                listOf(6 to "6 h", 24 to "24 h", 72 to "3 jours", 168 to "7 jours").forEach { (h, l) ->
                    FilterChip(selected = hours == h, onClick = { hours = h }, label = { Text(l) })
                }
            }
        }
        val d = loader.data
        if (d != null) {
            val from = System.currentTimeMillis() - hours * 3600_000L
            val s = d.samples.filter { it.t >= from }
            if (s.isEmpty()) {
                item { EmptyText("Pas encore de mesures sur cette période.") }
            } else {
                item {
                    val ok = s.count { it.reachable }
                    SectionCard("Disponibilité") {
                        KeyValue("Pare-feu joignable", "%.1f %%".format(ok * 100.0 / s.size))
                        KeyValue("Mesures", "${s.size} (du ${fmt(s.first().t)} au ${fmt(s.last().t)})")
                    }
                }
                item {
                    SectionCard("CPU et mémoire") {
                        LineChart(
                            listOf(
                                ChartSeries("CPU %", MaterialTheme.colorScheme.primary, s.map { it.cpu?.toFloat() }),
                                ChartSeries("Mémoire %", Orange, s.map { it.ram?.toFloat() }),
                                ChartSeries("Disque %", Grey, s.map { it.disk?.toFloat() }),
                            ),
                            maxY = 100f,
                        )
                        val cpus = s.mapNotNull { it.cpu }
                        if (cpus.isNotEmpty()) KeyValue("CPU moyen / max", "${cpus.average().toInt()} % / ${cpus.max()} %")
                    }
                }
                if (s.any { it.users != null || it.conns != null }) {
                    item {
                        SectionCard("Activité") {
                            LineChart(
                                listOf(
                                    ChartSeries("Utilisateurs", BlueIn, s.map { it.users?.toFloat() }),
                                    ChartSeries("Connexions TCP", PurpleOut, s.map { it.conns?.toFloat() }),
                                ),
                            )
                        }
                    }
                }
                val volumes = trafficVolumes(s)
                if (volumes.isNotEmpty()) {
                    item {
                        SectionCard("Volume de trafic par interface") {
                            BarList(volumes.map { (n, v) -> "$n ↓" to v.first.toDouble() } + volumes.map { (n, v) -> "$n ↑" to v.second.toDouble() }) { formatBytes(it) }
                            InfoText("Calculé entre deux mesures consécutives ; les périodes hors réseau local ne sont pas comptées.")
                        }
                    }
                }
            }
            item { Text("Journal des alertes", style = MaterialTheme.typography.titleMedium) }
            val alerts = d.alerts.filter { it.t >= from }.reversed()
            if (alerts.isEmpty()) item { InfoText("Aucune alerte sur la période.") }
            items(alerts) { a ->
                Column {
                    Text(a.title, style = MaterialTheme.typography.bodyMedium)
                    InfoText("${fmt(a.t)} · ${a.text}")
                }
            }
            item {
                TextButton(onClick = { confirmClear = true }) { Text("Effacer l'historique") }
                InfoText("Les rapports détaillés de Sophos (applications, sites, utilisateurs, menaces) ne sont pas accessibles par l'API : consulte-les dans la console web ou Sophos Central.")
            }
        }
    }

    if (confirmClear) {
        ConfirmDialog(
            "Effacer l'historique ?", "Mesures et journal des alertes de ce pare-feu seront supprimés du téléphone.", "Effacer",
            onConfirm = { history.clear(); loader.reload() }, onDismiss = { confirmClear = false },
        )
    }
}

private fun fmt(t: Long) = SimpleDateFormat("dd/MM HH:mm", Locale.FRANCE).format(Date(t))

/** Octets entrants/sortants par interface, en sommant les écarts entre mesures proches (< 1 h). */
private fun trafficVolumes(s: List<Sample>): List<Pair<String, Pair<Long, Long>>> {
    val acc = HashMap<String, Pair<Long, Long>>()
    for (i in 1 until s.size) {
        val a = s[i - 1]
        val b = s[i]
        if (b.t - a.t > 3600_000L) continue
        for ((name, cur) in b.ifs) {
            val prev = a.ifs[name] ?: continue
            val di = cur.first - prev.first
            val dout = cur.second - prev.second
            if (di < 0 || dout < 0) continue
            val old = acc[name] ?: (0L to 0L)
            acc[name] = (old.first + di) to (old.second + dout)
        }
    }
    return acc.entries.filter { it.value.first + it.value.second > 0 }
        .sortedByDescending { it.value.first + it.value.second }
        .map { it.key to it.value }
}
