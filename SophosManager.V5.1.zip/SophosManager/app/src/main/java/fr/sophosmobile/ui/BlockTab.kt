package fr.sophosmobile.ui

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material3.Card
import androidx.compose.material3.FilterChip
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.SnackbarHostState
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import fr.sophosmobile.net.BlockKind
import fr.sophosmobile.net.Blocked
import fr.sophosmobile.net.SophosApi

private data class BlockData(val blocked: List<Blocked>, val disabledRules: List<String>)

private fun BlockKind.label() = when (this) {
    BlockKind.Ip -> "IP externe"
    BlockKind.Site -> "Site web"
    BlockKind.Device -> "Appareil du réseau"
}

@Composable
fun BlockTab(api: SophosApi, snackbar: SnackbarHostState) {
    val loader = rememberLoader(api) {
        val rules = api.rules()
        BlockData(
            api.blocked(),
            rules.filter { it.name in SophosApi.BLOCK_RULES && !it.enabled }.map { it.name },
        )
    }
    val scope = rememberCoroutineScope()
    var kind by rememberSaveable { mutableStateOf(BlockKind.Ip) }
    var value by rememberSaveable { mutableStateOf("") }
    var busy by remember { mutableStateOf(false) }
    var toRemove by remember { mutableStateOf<Blocked?>(null) }

    LazyColumn(
        Modifier.fillMaxSize(),
        contentPadding = PaddingValues(16.dp),
        verticalArrangement = Arrangement.spacedBy(8.dp),
    ) {
        item {
            Card(Modifier.fillMaxWidth()) {
                Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Text("Bloquer", style = MaterialTheme.typography.titleMedium)
                    Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                        BlockKind.entries.forEach { k ->
                            FilterChip(selected = kind == k, onClick = { kind = k }, label = { Text(k.label()) })
                        }
                    }
                    OutlinedTextField(
                        value, { value = it },
                        label = { Text(if (kind == BlockKind.Site) "Domaine" else "Adresse IP") },
                        placeholder = {
                            Text(
                                when (kind) {
                                    BlockKind.Ip -> "203.0.113.25"
                                    BlockKind.Site -> "tiktok.com ou *.tiktok.com"
                                    BlockKind.Device -> "192.168.1.50"
                                },
                            )
                        },
                        singleLine = true,
                        keyboardOptions = KeyboardOptions(keyboardType = if (kind == BlockKind.Site) KeyboardType.Uri else KeyboardType.Decimal),
                        modifier = Modifier.fillMaxWidth(),
                    )
                    InfoText(
                        when (kind) {
                            BlockKind.Ip -> "Bloque tout le trafic vers et depuis cette adresse."
                            BlockKind.Site -> "Bloque l'accès à ce domaine depuis le réseau (résolution DNS par le pare-feu)."
                            BlockKind.Device -> "Coupe l'accès réseau de cet appareil (Internet et autres réseaux)."
                        },
                    )
                    PrimaryButton(
                        if (busy) "En cours…" else "Bloquer",
                        enabled = value.isNotBlank() && !busy,
                        modifier = Modifier.fillMaxWidth(),
                    ) {
                        busy = true
                        val v = value
                        val k = kind
                        scope.runAction(snackbar, "$v bloqué", after = { busy = false; loader.reload() }) {
                            api.block(k, v)
                        }
                    }
                }
            }
        }

        val d = loader.data
        if (d != null && d.disabledRules.isNotEmpty()) {
            item { ErrorBox("Règle(s) de blocage désactivée(s) : ${d.disabledRules.joinToString()}. Réactive-les dans l'onglet Règles.") }
        }
        item { ListHeader(d?.let { "${it.blocked.size} élément(s) bloqué(s)" } ?: "Éléments bloqués", loader.loading) { loader.reload() } }
        loader.error?.let { item { ErrorBox(it) { loader.reload() } } }
        if (d == null && loader.loading) item { CenteredLoading() }
        if (d != null && d.blocked.isEmpty()) item { EmptyText("Rien n'est bloqué par l'appli pour le moment.") }
        items(d?.blocked ?: emptyList(), key = { it.hostName }) { b ->
            Card(Modifier.fillMaxWidth()) {
                Row(Modifier.padding(start = 16.dp, end = 4.dp, top = 8.dp, bottom = 8.dp), verticalAlignment = Alignment.CenterVertically) {
                    Column(Modifier.weight(1f)) {
                        Text(b.value, style = MaterialTheme.typography.titleSmall)
                        InfoText(b.kind.label())
                    }
                    IconButton(onClick = { toRemove = b }) { Icon(Icons.Default.Delete, contentDescription = "Débloquer") }
                }
            }
        }
        item {
            InfoText(
                "La première fois, l'appli crée les groupes APP-Bloques-* et trois règles « APP Blocage » " +
                    "placées en tête de la liste des règles.",
            )
        }
    }

    toRemove?.let { b ->
        ConfirmDialog(
            title = "Débloquer ${b.value} ?",
            text = "L'objet sera supprimé du pare-feu.",
            confirm = "Débloquer",
            onConfirm = { scope.runAction(snackbar, "${b.value} débloqué", after = { loader.reload() }) { api.unblock(b) } },
            onDismiss = { toRemove = null },
        )
    }
}
