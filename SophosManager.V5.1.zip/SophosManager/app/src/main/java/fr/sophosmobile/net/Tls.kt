package fr.sophosmobile.net

import java.security.MessageDigest
import java.security.SecureRandom
import java.security.cert.X509Certificate
import javax.net.ssl.SSLContext
import javax.net.ssl.SSLSocketFactory
import javax.net.ssl.X509TrustManager

/**
 * Le pare-feu utilise un certificat auto-signé : on fait confiance au premier certificat vu,
 * puis on vérifie qu'il ne change pas (empreinte SHA-256 mémorisée).
 */
object Tls {
    fun fingerprint(cert: X509Certificate): String =
        MessageDigest.getInstance("SHA-256").digest(cert.encoded).joinToString(":") { "%02X".format(it) }

    class PinnedTrustManager(private val expected: String?) : X509TrustManager {
        @Volatile var seen: String? = null
            private set

        override fun checkClientTrusted(chain: Array<X509Certificate>, authType: String) {}

        override fun checkServerTrusted(chain: Array<X509Certificate>, authType: String) {
            val fp = fingerprint(chain[0])
            seen = fp
            if (expected != null && !expected.equals(fp, ignoreCase = true)) {
                throw CertificateChangedException(expected, fp)
            }
        }

        override fun getAcceptedIssuers(): Array<X509Certificate> = arrayOf()
    }

    fun socketFactory(tm: X509TrustManager): SSLSocketFactory {
        val ctx = SSLContext.getInstance("TLS")
        ctx.init(null, arrayOf(tm), SecureRandom())
        return ctx.socketFactory
    }
}
