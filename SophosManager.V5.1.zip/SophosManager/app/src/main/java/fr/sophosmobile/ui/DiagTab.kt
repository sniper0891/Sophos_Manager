package fr.sophosmobile.ui

import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material3.FilterChip
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import fr.sophosmobile.data.Firewall
import fr.sophosmobile.net.Diag
import fr.sophosmobile.net.SfosSnmp
import fr.sophosmobile.net.SophosApi
import fr.sophosmobile.net.SophosClient
import fr.sophosmobile.net.friendly
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

private val TOOLS = listOf("Ping", "Traceroute", "DNS", "Port TCP", "Appareils (ARP)", "Routes", "Interfaces")

@Composable
fun DiagTab(fw: Firewall, api: SophosApi) {
    var tool by rememberSaveable { mutableStateOf(0) }
    val fwIp = SophosClient.hostOnly(fw.host)
    Column(Modifier.fillMaxSize()) {
        Row(
            Modifier.horizontalScroll(rememberScrollState()).padding(horizontal = 16.dp, vertical = 8.dp),
            horizontalArrangement = Arrangement.spacedBy(6.dp),
        ) {
            TOOLS.forEachIndexed { i, t -> FilterChip(selected = tool == i, onClick = { tool = i }, label = { Text(t) }) }
        }
        when (tool) {
            0 -> CommandTool("Cible", "1.1.1.1", "Lancer le ping") { target, out -> Diag.ping(target) { out(it) } }
            1 -> CommandTool("Cible", "1.1.1.1", "Lancer le traceroute") { target, out ->
                out("Traceroute vers $target (depuis le téléphone, via le pare-feu)")
                Diag.traceroute(target) { h ->
                    out("%2d  %-16s %s".format(h.ttl, h.address ?: "*", h.ms?.let { "%.0f ms".format(it) } ?: ""))
                }
            }
            2 -> CommandTool("Nom à résoudre", "sophos.com", "Interroger") { name, out ->
                out("Serveur DNS du pare-feu ($fwIp) :")
                try {
                    val r = Diag.dnsQuery(fwIp, name)
                    out("  ${Diag.rcodeLabel(r.rcode)} en ${r.ms} ms → ${r.answers.ifEmpty { listOf("aucune réponse") }.joinToString(", ")}")
                } catch (e: Exception) {
                    out("  échec : ${e.javaClass.simpleName} (le pare-feu répond-il en DNS sur cette interface ?)")
                }
                out("Résolveur du téléphone :")
                try {
                    val all = java.net.InetAddress.getAllByName(name).map { it.hostAddress }
                    out("  → ${all.joinToString(", ")}")
                } catch (e: Exception) {
                    out("  échec : ${e.javaClass.simpleName}")
                }
                out("Astuce : un domaine bloqué par le blocage rapide reste résolu, c'est la connexion qui est coupée.")
            }
            3 -> PortTool(fwIp)
            4 -> SnmpTable(fw, "ARP") { s ->
                val leases = runCatching { api.dhcpServers().flatMap { it.leases } }.getOrDefault(emptyList())
                    .associateBy { it.mac.uppercase() }
                s.arp().map { e -> listOf(e.ip, e.mac, leases[e.mac.uppercase()]?.host ?: "", e.iface) }
            }
            5 -> SnmpTable(fw, "Routes") { s -> s.routes().map { listOf(it.dest, it.mask, it.nextHop, it.iface) } }
            6 -> SnmpTable(fw, "Interfaces") { s ->
                s.interfaces().map {
                    listOf(
                        "${it.name}${it.alias?.let { a -> " ($a)" } ?: ""}",
                        if (it.up) "lien OK${it.speedMbps?.let { m -> " · $m Mb/s" } ?: ""}" else "pas de lien",
                        it.mac ?: "",
                        "erreurs ${(it.inErrors ?: 0) + (it.outErrors ?: 0)} · rejets ${(it.inDiscards ?: 0) + (it.outDiscards ?: 0)}",
                    )
                }
            }
        }
    }
}

@Composable
private fun CommandTool(label: String, default: String, button: String, run: (String, (String) -> Unit) -> Unit) {
    var target by rememberSaveable(label) { mutableStateOf(default) }
    val lines = remember(label) { mutableStateListOf<String>() }
    var running by remember { mutableStateOf(false) }
    val scope = rememberCoroutineScope()
    LazyColumn(Modifier.fillMaxSize(), contentPadding = PaddingValues(16.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
        item {
            OutlinedTextField(target, { target = it.trim() }, label = { Text(label) }, singleLine = true, modifier = Modifier.fillMaxWidth())
        }
        item {
            PrimaryButton(if (running) "En cours…" else button, enabled = target.isNotBlank() && !running, modifier = Modifier.fillMaxWidth()) {
                lines.clear()
                running = true
                scope.launch {
                    try {
                        withContext(Dispatchers.IO) { run(target) { l -> scope.launch { lines += l } } }
                    } catch (e: Exception) {
                        lines += "Erreur : ${e.friendly()}"
                    } finally {
                        running = false
                    }
                }
            }
        }
        items(lines) { Text(it, fontFamily = FontFamily.Monospace, style = MaterialTheme.typography.bodySmall) }
    }
}

@Composable
private fun PortTool(defaultHost: String) {
    var host by rememberSaveable { mutableStateOf(defaultHost) }
    var port by rememberSaveable { mutableStateOf("4444") }
    var result by remember { mutableStateOf<String?>(null) }
    val scope = rememberCoroutineScope()
    Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
        OutlinedTextField(host, { host = it.trim() }, label = { Text("Hôte") }, singleLine = true, modifier = Modifier.fillMaxWidth())
        OutlinedTextField(
            port, { port = it.filter(Char::isDigit) }, label = { Text("Port") }, singleLine = true,
            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number), modifier = Modifier.fillMaxWidth(),
        )
        PrimaryButton("Tester", enabled = host.isNotBlank() && port.isNotBlank(), modifier = Modifier.fillMaxWidth()) {
            result = "Test…"
            scope.launch {
                val r = withContext(Dispatchers.IO) { Diag.tcpPort(host, port.toInt()) }
                result = if (r.open) "Port $port ouvert (${r.ms} ms)" else "Port $port fermé ou filtré (${r.error})"
            }
        }
        result?.let { Text(it) }
        InfoText("Teste l'accès depuis le téléphone. Pour vérifier une redirection de port, teste depuis l'extérieur (4G, Wi-Fi désactivé).")
    }
}

@Composable
private fun SnmpTable(fw: Firewall, key: String, load: (SfosSnmp) -> List<List<String>>) {
    if (fw.snmpCommunity.isBlank()) {
        Column(Modifier.padding(16.dp)) { ErrorBox("Cet outil utilise SNMP : renseigne la communauté dans la fiche du pare-feu.") }
        return
    }
    val loader = rememberLoader(key) { load(SfosSnmp(fw.host, fw.snmpCommunity, fw.snmpPort)) }
    LazyColumn(Modifier.fillMaxSize(), contentPadding = PaddingValues(16.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
        val rows = loader.data
        item { ListHeader(rows?.let { "${it.size} entrée(s)" } ?: key, loader.loading) { loader.reload() } }
        loader.error?.let { item { ErrorBox(it) { loader.reload() } } }
        if (rows == null && loader.loading) item { CenteredLoading() }
        items(rows ?: emptyList()) { r ->
            Row(verticalAlignment = Alignment.CenterVertically) {
                Column(Modifier.weight(1f)) {
                    Text(r.getOrElse(0) { "" }, style = MaterialTheme.typography.bodyMedium)
                    InfoText(r.drop(1).filter { it.isNotBlank() }.joinToString(" · "))
                }
                Spacer(Modifier.width(4.dp))
            }
        }
        if (key == "ARP") item { InfoText("Appareils vus récemment par le pare-feu (table ARP). Les noms viennent des réservations DHCP.") }
        item { InfoText("Capture de paquets, connexions actives et journaux en direct ne sont pas exposés par l'API : console web, onglet Diagnostic.") }
    }
}
