package fr.sophosmobile.net

/** Fonctions tirées de la console web : baux DHCP, services, utilisateurs VPN. */

data class DhcpLease(
    val ip: String,
    val startTime: String,
    val endTime: String,
    val mac: String,
    val hostName: String,
    val type: String, // Static / Dynamic
    val server: String,
) {
    val isStatic get() = type.equals("Static", true)
    val displayHost get() = hostName.takeIf { it.isNotBlank() && it != "-" } ?: "(inconnu)"
}

data class SvcState(val key: String, val name: String, val running: Boolean, val available: Boolean, val actions: List<String>)

data class VpnLiveUser(
    val user: String,
    val sourceIp: String,
    val mode: String,
    val leasedIp: String,
    val since: String,
    val bytesSent: Long,
    val bytesReceived: Long,
    val durationSec: Long,
)

class ConsoleApi(private val c: WebConsole) {

    fun login() = c.login()

    // ---------- Baux DHCP ----------

    fun dhcpLeases(): List<DhcpLease> {
        val html = c.get("/webpages/includes/ManagePage.jsp?datagridid=44&mode=301&mgrid=1&cardView=off&popup=0&operation=13&t=${System.currentTimeMillis()}")
        return parseManagePageRecords(html, "DHCPLeasedManage").mapNotNull { r ->
            val ip = r["c1"] ?: return@mapNotNull null
            DhcpLease(
                ip = ip,
                startTime = r["c2"] ?: "",
                endTime = r["c3"] ?: "",
                mac = r["c4"] ?: "",
                hostName = r["c5"] ?: "",
                type = r["c6"] ?: "",
                server = r["c7"] ?: "",
            )
        }
    }

    // ---------- Services ----------

    fun services(): List<SvcState> {
        val body = c.get("/Controller?mode=300&operation=257&_=${System.currentTimeMillis()}")
        return SERVICES.mapNotNull { (key, def) ->
            val running = valueOf(body, key)?.contains("RUNNING", true) ?: return@mapNotNull null
            // Compteurs d'objets : un service « sans serveur configuré » ne propose pas d'action.
            val available = when (key) {
                "dhcpd" -> (valueOf(body, "dhcpcount")?.toIntOrNull() ?: 1) > 0
                "waf" -> (valueOf(body, "webservercount")?.toIntOrNull() ?: 1) > 0
                "dhcpd6" -> (valueOf(body, "dhcpv6count")?.toIntOrNull() ?: 1) > 0
                "radvd" -> (valueOf(body, "racount")?.toIntOrNull() ?: 1) > 0
                else -> true
            }
            SvcState(key, def.first, running, available, def.second)
        }.sortedBy { it.name.lowercase() }
    }

    /** action : "start", "stop" ou "restart". Le nom interne du service est [server]. */
    fun serviceAction(key: String, action: String) {
        val server = INTERNAL[key] ?: key
        val msg = when (action) { "start" -> "started"; "stop" -> "stopped"; else -> "restarted" }
        val json = "{\"server\":\"$server\",\"actionval\":\"$action\",\"actionmsg\":\"$msg\"}"
        val resp = c.post("/Controller", "mode=257&json=" + WebConsole.enc(json) + "&__RequestType=ajax")
        if (resp.contains("\"status\":5", false) && !resp.contains("\"status\":200")) {
            val m = Regex("\"opcodeMessage\":\"([^\"]+)\"").find(resp)?.groupValues?.getOrNull(1)
            throw WebConsole.WebException("Le pare-feu a refusé l'action : ${m ?: "service indisponible"}", WebConsole.WebException.Kind.Access)
        }
    }

    // ---------- Utilisateurs VPN ----------

    fun vpnLiveUsers(): List<VpnLiveUser> {
        val html = c.get("/webpages/includes/ManagePage.jsp?datagridid=43&mode=301&operation=240&popup=0&t=${System.currentTimeMillis()}")
        return parseManagePageRecords(html, "SSLVPNLiveUsersManage").mapNotNull { r ->
            val user = r["c1"] ?: return@mapNotNull null
            VpnLiveUser(
                user = user,
                sourceIp = r["c2"] ?: "",
                mode = r["c3"] ?: "",
                leasedIp = r["c5"] ?: "",
                since = r["c6"] ?: "",
                bytesSent = r["c7"]?.toLongOrNull() ?: 0,
                bytesReceived = r["c8"]?.toLongOrNull() ?: 0,
                durationSec = r["c9"]?.toLongOrNull() ?: 0,
            )
        }
    }

    private fun valueOf(body: String, key: String): String? =
        Regex("\"" + Regex.escape(key) + "\"\\s*:\\s*\"([^\"]*)\"").find(body)?.groupValues?.getOrNull(1)

    companion object {
        // clé d'état -> (nom affiché, actions possibles)
        val SERVICES = linkedMapOf(
            "sasi" to ("Antispam" to listOf("start", "stop")),
            "antivirus" to ("Antivirus" to listOf("start", "stop")),
            "access_server" to ("Authentification" to listOf("restart")),
            "dnsd" to ("Serveur DNS" to listOf("start", "stop")),
            "ips" to ("IPS" to listOf("start", "stop")),
            "awarrenhttp" to ("Proxy web" to listOf("restart")),
            "dhcpd" to ("Serveur DHCP" to listOf("start", "stop")),
            "waf" to ("WAF" to listOf("start", "stop")),
            "hotspot" to ("Hotspot" to listOf("start", "stop")),
            "pktcapd" to ("Capture de paquets" to listOf("restart")),
            "dhcpd6" to ("Serveur DHCPv6" to listOf("start", "stop")),
            "radvd" to ("Annonce de routeur" to listOf("start", "stop")),
        )

        // clé d'état -> nom interne envoyé au pare-feu
        val INTERNAL = mapOf(
            "sasi" to "kasd", "antivirus" to "kavd", "access_server" to "access_server",
            "dnsd" to "dns", "ips" to "ips", "awarrenhttp" to "awarrenhttp",
            "dhcpd" to "dhcpserver", "waf" to "waf", "hotspot" to "hotspot",
            "pktcapd" to "pktcapd", "dhcpd6" to "dhcpd6", "radvd" to "radvd",
        )
    }
}

fun formatDuration(sec: Long): String {
    val h = sec / 3600
    val m = (sec % 3600) / 60
    return when {
        h >= 24 -> "${h / 24} j ${h % 24} h"
        h > 0 -> "$h h $m min"
        else -> "$m min"
    }
}
