package fr.sophosmobile.ui

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.SnackbarHostState
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import fr.sophosmobile.data.Firewall
import fr.sophosmobile.net.SvcState

/** Carte de pilotage des services, affichée dans l'onglet Intégrité si la console est activée. */
@Composable
fun ServicesControlCard(fw: Firewall, vm: AppViewModel, snackbar: SnackbarHostState) {
    if (!fw.consoleEnabled) return
    val loader = rememberLoader(fw.id + "svc") { vm.consoleFor(fw).services() }
    val scope = rememberCoroutineScope()
    var busy by remember { mutableStateOf<String?>(null) }
    var confirm by remember { mutableStateOf<Triple<SvcState, String, String>?>(null) }

    SectionCard("Services" + (loader.data?.let { " (${it.count { s -> s.running }}/${it.size} en marche)" } ?: "")) {
        loader.error?.let { InfoText("Indisponible : $it") }
        if (loader.data == null && loader.loading) InfoText("Chargement…")
        loader.data?.forEach { s ->
            Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.padding(vertical = 2.dp)) {
                Dot(if (s.running) Green else if (s.available) Red else Grey)
                Spacer(Modifier.width(10.dp))
                Column(Modifier.weight(1f)) {
                    Text(s.name, style = MaterialTheme.typography.bodyMedium)
                    InfoText(if (!s.available) "Aucun serveur configuré" else if (s.running) "En marche" else "Arrêté")
                }
                if (s.available && busy != s.key) {
                    Row(horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                        s.actions.forEach { action ->
                            // N'affiche Démarrer que si arrêté, Arrêter que si en marche.
                            val show = when (action) {
                                "start" -> !s.running
                                "stop" -> s.running
                                else -> true
                            }
                            if (show) {
                                OutlinedButton(onClick = {
                                    confirm = Triple(s, action, labelOf(action))
                                }) { Text(labelOf(action)) }
                            }
                        }
                    }
                } else if (busy == s.key) {
                    Text("…", style = MaterialTheme.typography.bodySmall)
                }
            }
        }
        InfoText("Pilotage via la console web. Arrêter un service comme l'IPS ou le DNS peut interrompre la protection ou l'accès réseau.")
    }

    confirm?.let { (s, action, label) ->
        ConfirmDialog(
            title = "$label « ${s.name} » ?",
            text = when (action) {
                "stop" -> "Le service sera arrêté. Selon le service, cela peut couper une protection ou un accès réseau."
                "restart" -> "Le service va redémarrer : une courte interruption est possible."
                else -> "Le service va démarrer."
            },
            confirm = label,
            onConfirm = {
                busy = s.key
                scope.runAction(snackbar, "${s.name} : $label demandé", after = { busy = null; loader.reload() }) {
                    vm.consoleFor(fw).serviceAction(s.key, action)
                }
            },
            onDismiss = { confirm = null },
        )
    }
}

private fun labelOf(action: String) = when (action) {
    "start" -> "Démarrer"
    "stop" -> "Arrêter"
    else -> "Redémarrer"
}
