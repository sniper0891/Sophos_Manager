package fr.sophosmobile.ui

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material3.Card
import androidx.compose.material3.ExtendedFloatingActionButton
import androidx.compose.material3.FilterChip
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.SnackbarHostState
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import fr.sophosmobile.net.ruleOptions
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import fr.sophosmobile.net.NatRule
import fr.sophosmobile.net.PortForward
import fr.sophosmobile.net.SophosApi
import fr.sophosmobile.net.createPortForward
import fr.sophosmobile.net.deleteNat
import fr.sophosmobile.net.friendly
import fr.sophosmobile.net.wanInterfaces
import fr.sophosmobile.net.WanInterface
import fr.sophosmobile.net.portValid
import kotlinx.coroutines.launch

@Composable
fun NatTab(api: SophosApi, snackbar: SnackbarHostState) {
    val loader = rememberLoader(api) { api.natRules() }
    LaunchedEffect(api) {
        // Préchauffe le cache des objets pour que l'éditeur s'ouvre avec les listes déjà prêtes.
        withContext(Dispatchers.IO) { runCatching { api.ruleOptions() } }
    }
    val scope = rememberCoroutineScope()
    var busy by remember { mutableStateOf(false) }
    var toDelete by remember { mutableStateOf<NatRule?>(null) }
    var wizard by remember { mutableStateOf(false) }

    Box(Modifier.fillMaxSize()) {
        LazyColumn(
            Modifier.fillMaxSize(),
            contentPadding = PaddingValues(start = 16.dp, end = 16.dp, top = 8.dp, bottom = 96.dp),
            verticalArrangement = Arrangement.spacedBy(8.dp),
        ) {
            val rules = loader.data
            item { ListHeader(rules?.let { "${it.size} règles NAT" } ?: "Règles NAT", loader.loading) { loader.reload() } }
            loader.error?.let { item { ErrorBox(it) { loader.reload() } } }
            if (rules == null && loader.loading) item { CenteredLoading() }
            if (rules != null && rules.isEmpty()) item { EmptyText("Aucune règle NAT.") }
            items(rules ?: emptyList(), key = { it.name }) { r ->
                Card(Modifier.fillMaxWidth()) {
                    Row(Modifier.padding(start = 16.dp, end = 4.dp, top = 10.dp, bottom = 10.dp), verticalAlignment = Alignment.CenterVertically) {
                        Column(Modifier.weight(1f)) {
                            Text(r.name, style = MaterialTheme.typography.titleSmall)
                            InfoText(r.summary)
                        }
                        Switch(
                            checked = r.enabled,
                            enabled = !busy,
                            onCheckedChange = { on ->
                                busy = true
                                scope.runAction(snackbar, "${r.name} ${if (on) "activée" else "désactivée"}", after = { busy = false; loader.reload() }) {
                                    api.setNatEnabled(r, on)
                                }
                            },
                        )
                        IconButton(onClick = { toDelete = r }, enabled = !busy) { Icon(Icons.Default.Delete, contentDescription = "Supprimer") }
                    }
                }
            }
        }
        ExtendedFloatingActionButton(
            onClick = { wizard = true },
            icon = { Icon(Icons.Default.Add, null) },
            text = { Text("Redirection de port") },
            modifier = Modifier.align(Alignment.BottomEnd).padding(16.dp),
        )
    }

    toDelete?.let { r ->
        ConfirmDialog(
            title = "Supprimer « ${r.name} » ?",
            text = "La règle NAT sera supprimée. Si une règle de pare-feu « APP NAT » lui est associée, supprime-la aussi dans l'onglet Règles.",
            confirm = "Supprimer",
            onConfirm = { scope.runAction(snackbar, "Règle NAT supprimée", after = { loader.reload() }) { api.deleteNat(r) } },
            onDismiss = { toDelete = null },
        )
    }

    if (wizard) PortForwardWizard(api, snackbar, onClose = { wizard = false }, onDone = { wizard = false; loader.reload() })
}

@Composable
private fun PortForwardWizard(api: SophosApi, snackbar: SnackbarHostState, onClose: () -> Unit, onDone: () -> Unit) {
    val opts = rememberLoader("pf") { api.wanInterfaces() to api.ruleOptions() }
    var name by remember { mutableStateOf("") }
    var iface by remember { mutableStateOf<WanInterface?>(null) }
    var proto by remember { mutableStateOf("TCP") }
    var ext by remember { mutableStateOf("") }
    var ip by remember { mutableStateOf("") }
    var internal by remember { mutableStateOf("") }
    var zone by remember { mutableStateOf("LAN") }
    var sources by remember { mutableStateOf(emptyList<String>()) }
    var ips by remember { mutableStateOf("None") }
    var saving by remember { mutableStateOf(false) }
    var error by remember { mutableStateOf<String?>(null) }
    val scope = rememberCoroutineScope()
    val ipOk = SophosApi.IPV4.matches(ip.trim())
    val extOk = portValid(ext)
    val intOk = internal.isBlank() || portValid(internal)
    val nameOk = name.isNotBlank() && !name.contains(',')
    val valid = nameOk && iface != null && extOk && ipOk && intOk
    val missing = listOfNotNull(
        "nom".takeIf { !nameOk },
        "interface WAN".takeIf { iface == null },
        "port externe".takeIf { !extOk },
        "IP du serveur".takeIf { !ipOk },
        "port interne".takeIf { !intOk },
    )

    FullScreenDialog(
        title = "Redirection de port",
        onDismiss = onClose,
        actions = {
            TextButton(enabled = valid && !saving, onClick = {
                saving = true
                error = null
                scope.launch {
                    try {
                        withContext(Dispatchers.IO) {
                            api.createPortForward(
                                PortForward(name.trim(), iface!!, proto, ext.trim(), ip.trim(), internal.trim(), zone, sources, ips),
                            )
                        }
                        snackbar.showSnackbar("Redirection créée")
                        onDone()
                    } catch (e: Exception) {
                        error = (e as? IllegalArgumentException)?.message ?: e.friendly()
                    } finally {
                        saving = false
                    }
                }
            }) { Text(if (saving) "…" else "Créer") }
        },
    ) { mod ->
        Column(mod.verticalScroll(rememberScrollState()).padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
            error?.let { ErrorBox(it) }
            opts.error?.let { ErrorBox(it) { opts.reload() } }
            val ifaces = opts.data?.first ?: emptyList()
            val o = opts.data?.second
            if (missing.isNotEmpty()) InfoText("Le bouton Créer s'active quand ces champs sont valides : ${missing.joinToString(", ")}.")
            InfoText(
                "L'appli crée l'objet du serveur, les services, une règle de pare-feu « APP NAT » et une règle NAT « APP DNAT », " +
                    "placées en tête.",
            )
            OutlinedTextField(name, { name = it }, label = { Text("Nom (ex. Plex, Serveur web)") }, singleLine = true, modifier = Modifier.fillMaxWidth())
            SelectField(
                "Interface WAN d'entrée", iface?.hardware ?: "", ifaces.map { it.hardware }, loading = opts.loading,
                display = { h -> ifaces.firstOrNull { it.hardware == h }?.label ?: "Choisir…" },
            ) { h -> iface = ifaces.first { it.hardware == h } }
            Text("Protocole", style = MaterialTheme.typography.titleSmall)
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                listOf("TCP", "UDP", "TCP+UDP").forEach { p -> FilterChip(selected = proto == p, onClick = { proto = p }, label = { Text(p) }) }
            }
            OutlinedTextField(
                ext, { ext = it.trim() }, label = { Text("Port externe (côté Internet)") }, placeholder = { Text("443 ou 8000:8010") }, singleLine = true,
                isError = ext.isNotBlank() && !extOk,
                supportingText = { if (ext.isNotBlank() && !extOk) Text("Port de 1 à 65535, ou plage début:fin") },
                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number), modifier = Modifier.fillMaxWidth(),
            )
            OutlinedTextField(
                ip, { ip = it.trim() }, label = { Text("IP du serveur interne") }, placeholder = { Text("172.16.10.50") }, singleLine = true,
                isError = ip.isNotBlank() && !ipOk,
                supportingText = { Text(if (ip.isNotBlank() && !ipOk) "Adresse IPv4 attendue, ex. 172.16.10.50 (pas un port)" else "L'adresse locale de la machine qui reçoit le trafic") },
                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal), modifier = Modifier.fillMaxWidth(),
            )
            OutlinedTextField(
                internal, { internal = it.trim() }, label = { Text("Port interne (vide = identique)") }, singleLine = true,
                isError = !intOk,
                supportingText = { if (!intOk) Text("Port de 1 à 65535") },
                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number), modifier = Modifier.fillMaxWidth(),
            )
            SelectField("Zone du serveur", zone, o?.zones ?: listOf("LAN", "DMZ")) { zone = it }
            MultiSelectField(
                "Sources autorisées (vide = tout Internet)", sources,
                o?.networks?.filterNot { it.startsWith("#") } ?: emptyList(), "Tout Internet", loading = opts.loading,
            ) { sources = it }
            InfoText("Limite aux adresses externes qui doivent accéder au service (ex. l'IP de ton travail). Laisse vide pour tout Internet.")
            SelectField("Prévention d'intrusion (IPS)", ips, o?.ipsPolicies ?: listOf("None"), display = { if (it == "None") "Aucun" else it }) { ips = it }
            InfoText("Conseil : applique une stratégie IPS (ex. « WAN TO LAN ») et limite les sources quand c'est possible.")
        }
    }
}
