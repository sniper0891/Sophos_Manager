package fr.sophosmobile.ui

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.Card
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.SnackbarHostState
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import fr.sophosmobile.data.Firewall
import fr.sophosmobile.net.Audit
import fr.sophosmobile.net.Finding
import fr.sophosmobile.net.Severity
import fr.sophosmobile.net.SfosSnmp
import fr.sophosmobile.net.SophosApi

fun Severity.color() = when (this) {
    Severity.Critical -> Red
    Severity.Warning -> Orange
    Severity.Info -> BlueIn
    Severity.Ok -> Green
}

fun Severity.label() = when (this) {
    Severity.Critical -> "Critique"
    Severity.Warning -> "Attention"
    Severity.Info -> "Conseil"
    Severity.Ok -> "OK"
}

@Composable
fun HealthTab(fw: Firewall, api: SophosApi, vm: AppViewModel, snackbar: SnackbarHostState) {
    val loader = rememberLoader(api) {
        val sfos = fw.snmpCommunity.takeIf { it.isNotBlank() }?.let { SfosSnmp(fw.host, it, fw.snmpPort) }
        Audit.run(api, sfos)
    }

    LazyColumn(
        Modifier.fillMaxSize(),
        contentPadding = PaddingValues(16.dp),
        verticalArrangement = Arrangement.spacedBy(8.dp),
    ) {
        val r = loader.data
        item { ListHeader("Bilan d'intégrité", loader.loading) { loader.reload() } }
        loader.error?.let { item { ErrorBox(it) { loader.reload() } } }
        if (r == null && loader.loading) item { CenteredLoading() }
        if (r != null) {
            item {
                Card(Modifier.fillMaxWidth()) {
                    Row(Modifier.padding(16.dp), verticalAlignment = Alignment.CenterVertically) {
                        val c = when {
                            r.score >= 85 -> Green
                            r.score >= 60 -> Orange
                            else -> Red
                        }
                        Box(contentAlignment = Alignment.Center) {
                            CircularProgressIndicator(progress = { r.score / 100f }, color = c, strokeWidth = 8.dp, modifier = Modifier.size(84.dp))
                            Text("${r.score}", style = MaterialTheme.typography.headlineMedium, fontWeight = FontWeight.Bold)
                        }
                        Spacer(Modifier.width(16.dp))
                        Column {
                            Text(
                                when {
                                    r.score >= 85 -> "Bonne santé"
                                    r.score >= 60 -> "Points à corriger"
                                    else -> "Action nécessaire"
                                },
                                style = MaterialTheme.typography.titleMedium,
                            )
                            val crit = r.findings.count { it.severity == Severity.Critical }
                            val warn = r.findings.count { it.severity == Severity.Warning }
                            InfoText("$crit critique(s), $warn avertissement(s)")
                            InfoText("Sources : ${r.sources.joinToString(" + ").ifEmpty { "aucune" }}")
                        }
                    }
                }
            }
            if (fw.consoleEnabled) item { ServicesControlCard(fw, vm, snackbar) }
            r.findings.groupBy { it.category }.forEach { (cat, list) ->
                item { Text(cat, style = MaterialTheme.typography.titleSmall, modifier = Modifier.padding(top = 8.dp)) }
                items(list) { FindingRow(it) }
            }
            if (fw.snmpCommunity.isBlank()) item { InfoText("Active SNMP dans la fiche du pare-feu pour inclure services, licences et ressources.") }
        }
    }
}

@Composable
private fun FindingRow(f: Finding) {
    Card(Modifier.fillMaxWidth()) {
        Row(Modifier.padding(12.dp), verticalAlignment = Alignment.Top) {
            Pill(f.severity.label(), f.severity.color())
            Spacer(Modifier.width(10.dp))
            Column(Modifier.weight(1f)) {
                Text(f.title, style = MaterialTheme.typography.bodyMedium)
                if (f.detail.isNotBlank()) InfoText(f.detail)
            }
        }
    }
}
