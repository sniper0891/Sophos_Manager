package fr.sophosmobile.data

import android.content.Context
import android.security.keystore.KeyGenParameterSpec
import android.security.keystore.KeyProperties
import android.util.Base64
import org.json.JSONArray
import org.json.JSONObject
import java.security.KeyStore
import javax.crypto.Cipher
import javax.crypto.KeyGenerator
import javax.crypto.SecretKey
import javax.crypto.spec.GCMParameterSpec

data class Firewall(
    val id: String,
    val name: String,
    /** IP ou nom du pare-feu, avec :port si l'admin n'est pas sur 4444. */
    val host: String,
    val username: String,
    val password: String,
    /** Empreinte SHA-256 du certificat, mémorisée à la première connexion. */
    val certFingerprint: String? = null,
    /** Communauté SNMP v2c ; vide = surveillance désactivée. */
    val snmpCommunity: String = "",
    val snmpPort: Int = 161,
    val alertsEnabled: Boolean = false,
    val cpuThreshold: Int = 90,
    val ramThreshold: Int = 90,
    /** Accès à la console web pour baux DHCP, services et VPN. Vide = on réutilise username/password de l'API. */
    val consoleEnabled: Boolean = false,
    val consoleUsername: String = "",
    val consolePassword: String = "",
) {
    /** Identifiants effectifs pour la console : ceux dédiés s'ils existent, sinon ceux de l'API. */
    val consoleUser get() = consoleUsername.ifBlank { username }
    val consolePass get() = consolePassword.ifBlank { password }
}

/** Liste des pare-feux ; tout le contenu est chiffré avec une clé AES du Keystore Android. */
class FirewallStore(context: Context) {
    private val prefs = context.getSharedPreferences("firewalls", Context.MODE_PRIVATE)

    fun load(): List<Firewall> {
        val enc = prefs.getString("data", null) ?: return emptyList()
        return try {
            val arr = JSONArray(Crypto.decrypt(enc))
            (0 until arr.length()).map { i ->
                val o = arr.getJSONObject(i)
                Firewall(
                    id = o.getString("id"),
                    name = o.getString("name"),
                    host = o.getString("host"),
                    username = o.getString("username"),
                    password = o.getString("password"),
                    certFingerprint = o.optString("fp").ifEmpty { null },
                    snmpCommunity = o.optString("snmp"),
                    snmpPort = o.optInt("snmpPort", 161),
                    alertsEnabled = o.optBoolean("alerts"),
                    cpuThreshold = o.optInt("cpuMax", 90),
                    ramThreshold = o.optInt("ramMax", 90),
                    consoleEnabled = o.optBoolean("console"),
                    consoleUsername = o.optString("cuser"),
                    consolePassword = o.optString("cpass"),
                )
            }
        } catch (e: Exception) {
            emptyList()
        }
    }

    @Synchronized
    private fun saveAll(list: List<Firewall>) {
        val arr = JSONArray()
        list.forEach { f ->
            arr.put(
                JSONObject()
                    .put("id", f.id).put("name", f.name).put("host", f.host)
                    .put("username", f.username).put("password", f.password)
                    .put("fp", f.certFingerprint ?: "")
                    .put("snmp", f.snmpCommunity).put("snmpPort", f.snmpPort)
                    .put("alerts", f.alertsEnabled)
                    .put("cpuMax", f.cpuThreshold).put("ramMax", f.ramThreshold)
                    .put("console", f.consoleEnabled).put("cuser", f.consoleUsername).put("cpass", f.consolePassword),
            )
        }
        prefs.edit().putString("data", Crypto.encrypt(arr.toString())).apply()
    }

    @Synchronized
    fun upsert(f: Firewall) {
        val list = load().toMutableList()
        val i = list.indexOfFirst { it.id == f.id }
        if (i >= 0) list[i] = f else list += f
        saveAll(list)
    }

    @Synchronized
    fun update(id: String, change: (Firewall) -> Firewall) {
        saveAll(load().map { if (it.id == id) change(it) else it })
    }

    @Synchronized
    fun delete(id: String) = saveAll(load().filterNot { it.id == id })
}

private object Crypto {
    private const val ALIAS = "sophos_manager_key"

    private fun key(): SecretKey {
        val ks = KeyStore.getInstance("AndroidKeyStore").apply { load(null) }
        (ks.getKey(ALIAS, null) as? SecretKey)?.let { return it }
        val gen = KeyGenerator.getInstance(KeyProperties.KEY_ALGORITHM_AES, "AndroidKeyStore")
        gen.init(
            KeyGenParameterSpec.Builder(ALIAS, KeyProperties.PURPOSE_ENCRYPT or KeyProperties.PURPOSE_DECRYPT)
                .setBlockModes(KeyProperties.BLOCK_MODE_GCM)
                .setEncryptionPaddings(KeyProperties.ENCRYPTION_PADDING_NONE)
                .build(),
        )
        return gen.generateKey()
    }

    fun encrypt(plain: String): String {
        val c = Cipher.getInstance("AES/GCM/NoPadding")
        c.init(Cipher.ENCRYPT_MODE, key())
        val out = c.iv + c.doFinal(plain.toByteArray())
        return Base64.encodeToString(out, Base64.NO_WRAP)
    }

    fun decrypt(enc: String): String {
        val all = Base64.decode(enc, Base64.NO_WRAP)
        val c = Cipher.getInstance("AES/GCM/NoPadding")
        c.init(Cipher.DECRYPT_MODE, key(), GCMParameterSpec(128, all.copyOfRange(0, 12)))
        return String(c.doFinal(all.copyOfRange(12, all.size)))
    }
}
