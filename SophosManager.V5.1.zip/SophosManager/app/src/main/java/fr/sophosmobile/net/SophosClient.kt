package fr.sophosmobile.net

import org.w3c.dom.Element
import java.net.HttpURLConnection
import java.net.URL
import java.net.URLEncoder
import javax.net.ssl.HostnameVerifier
import javax.net.ssl.HttpsURLConnection

/**
 * Client de l'API XML de Sophos Firewall (SFOS).
 * Chaque requête contient les identifiants : il n'y a pas de session à gérer.
 */
class SophosClient(
    host: String,
    private val username: String,
    private val password: String,
    private val fingerprint: String?,
    private val onFirstFingerprint: (String) -> Unit = {},
    private val timeoutMs: Int = 12_000,
) {
    val baseUrl: String = baseUrlOf(host)

    /** Envoie les opérations (Get/Set/Remove) et renvoie l'élément <Response>. */
    fun call(operations: String): Element {
        val xml = "<Request><Login><Username>${Xml.esc(username)}</Username>" +
            "<Password>${Xml.esc(password)}</Password></Login>$operations</Request>"
        val tm = Tls.PinnedTrustManager(fingerprint)
        val conn = URL("$baseUrl/webconsole/APIController").openConnection() as HttpsURLConnection
        val code: Int
        val body: String
        try {
            conn.sslSocketFactory = Tls.socketFactory(tm)
            conn.hostnameVerifier = HostnameVerifier { _, _ -> true }
            conn.connectTimeout = timeoutMs
            conn.readTimeout = timeoutMs * 2
            conn.requestMethod = "POST"
            conn.doOutput = true
            conn.setRequestProperty("Content-Type", "application/x-www-form-urlencoded")
            val payload = "reqxml=" + URLEncoder.encode(xml, "UTF-8")
            conn.outputStream.use { it.write(payload.toByteArray()) }
            code = conn.responseCode
            val stream = if (code < 400) conn.inputStream else conn.errorStream
            body = stream?.bufferedReader()?.use { it.readText() } ?: ""
        } catch (e: Exception) {
            throw mapNetwork(e)
        } finally {
            conn.disconnect()
        }
        if (fingerprint == null) tm.seen?.let(onFirstFingerprint)
        if (code != HttpURLConnection.HTTP_OK) {
            throw SophosException("Le pare-feu a répondu HTTP $code. L'API est-elle activée ?", SophosException.Kind.Api)
        }

        val root = try {
            Xml.parse(body)
        } catch (e: Exception) {
            throw SophosException("Réponse illisible du pare-feu.", SophosException.Kind.Api)
        }

        root.child("Status")?.let { st ->
            val msg = st.textContent.trim()
            val c = st.getAttribute("code")
            if (c == "534" || msg.contains("not allowed", true) || msg.contains("requester IP", true)) {
                throw SophosException(
                    "Le pare-feu refuse l'API depuis l'IP de ce téléphone. Ajoute-la dans " +
                        "Backup & firmware > API > Allowed IP address.",
                    SophosException.Kind.IpNotAllowed,
                )
            }
            if (c.isNotEmpty() && c != "200" && root.child("Login") == null) {
                throw SophosException("Erreur API ($c) : $msg", SophosException.Kind.Api)
            }
        }

        val login = root.child("Login")?.text("status")
        if (login != null && !login.contains("Success", true)) {
            throw SophosException("Identifiant ou mot de passe refusé par le pare-feu.", SophosException.Kind.Auth)
        }
        return root
    }

    companion object {
        fun baseUrlOf(host: String): String {
            val h = host.trim().removePrefix("https://").removePrefix("http://").trimEnd('/')
            return if (h.contains(':')) "https://$h" else "https://$h:4444"
        }

        /** Adresse sans port, pour SNMP et le test de réseau local. */
        fun hostOnly(host: String): String =
            host.trim().removePrefix("https://").removePrefix("http://").trimEnd('/').substringBefore(':')
    }
}
