package fr.sophosmobile.alerts

import android.content.Context
import android.net.ConnectivityManager
import java.net.Inet4Address
import java.net.InetAddress

/** L'appli fonctionne uniquement en local : on vérifie que le téléphone est sur le même sous-réseau. */
object LocalNetwork {
    /** À appeler hors du thread principal (résolution DNS possible). */
    fun isOnSameSubnet(context: Context, host: String): Boolean {
        val target = runCatching { InetAddress.getByName(host) }.getOrNull() as? Inet4Address ?: return false
        val cm = context.getSystemService(ConnectivityManager::class.java) ?: return false
        val lp = cm.getLinkProperties(cm.activeNetwork) ?: return false
        return lp.linkAddresses.any { la ->
            val a = la.address as? Inet4Address ?: return@any false
            sameSubnet(a.address, target.address, la.prefixLength)
        }
    }

    private fun sameSubnet(a: ByteArray, b: ByteArray, prefix: Int): Boolean {
        var bits = prefix
        for (i in 0 until 4) {
            val mask = when {
                bits >= 8 -> 0xFF
                bits <= 0 -> 0
                else -> (0xFF shl (8 - bits)) and 0xFF
            }
            if ((a[i].toInt() and mask) != (b[i].toInt() and mask)) return false
            bits -= 8
        }
        return true
    }
}
