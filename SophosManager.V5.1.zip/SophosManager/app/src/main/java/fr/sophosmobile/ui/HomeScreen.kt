package fr.sophosmobile.ui

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.Edit
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material3.Card
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FloatingActionButton
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import fr.sophosmobile.data.Firewall

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun HomeScreen(vm: AppViewModel) {
    var toDelete by remember { mutableStateOf<Firewall?>(null) }

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("Sophos Manager") },
                actions = {
                    IconButton(onClick = { vm.list.forEach { vm.refreshQuick(it) } }) {
                        Icon(Icons.Default.Refresh, contentDescription = "Actualiser")
                    }
                },
            )
        },
        floatingActionButton = {
            FloatingActionButton(onClick = { vm.screen = Screen.Edit(null) }) {
                Icon(Icons.Default.Add, contentDescription = "Ajouter")
            }
        },
    ) { pad ->
        if (vm.list.isEmpty()) {
            Column(Modifier.padding(pad).fillMaxSize().padding(24.dp)) {
                EmptyText(
                    "Aucun pare-feu.\n\nAvant d'en ajouter un, active l'API dans Backup & firmware > API " +
                        "et autorise l'IP de ce téléphone.",
                )
            }
        } else {
            LazyColumn(
                Modifier.padding(pad).fillMaxSize(),
                contentPadding = PaddingValues(16.dp),
                verticalArrangement = Arrangement.spacedBy(12.dp),
            ) {
                items(vm.list, key = { it.id }) { f ->
                    LaunchedEffect(f.id) { if (vm.quick[f.id] == null) vm.refreshQuick(f) }
                    FirewallCard(
                        f, vm.quick[f.id],
                        onOpen = { vm.screen = Screen.Detail(f.id) },
                        onEdit = { vm.screen = Screen.Edit(f.id) },
                        onDelete = { toDelete = f },
                    )
                }
            }
        }
    }

    toDelete?.let { f ->
        ConfirmDialog(
            title = "Supprimer ${f.name} ?",
            text = "Le pare-feu et ses identifiants seront retirés de l'application. Le pare-feu lui-même n'est pas modifié.",
            confirm = "Supprimer",
            onConfirm = { vm.delete(f) },
            onDismiss = { toDelete = null },
        )
    }
}

@Composable
private fun FirewallCard(f: Firewall, status: QuickStatus?, onOpen: () -> Unit, onEdit: () -> Unit, onDelete: () -> Unit) {
    Card(onClick = onOpen, modifier = Modifier.fillMaxWidth()) {
        Row(Modifier.padding(start = 16.dp, top = 12.dp, bottom = 12.dp, end = 4.dp), verticalAlignment = Alignment.CenterVertically) {
            when (status) {
                is QuickStatus.Online -> Dot(Green, 14.dp)
                QuickStatus.Loading, null -> CircularProgressIndicator(Modifier.size(14.dp), strokeWidth = 2.dp)
                QuickStatus.Offline -> Dot(Red, 14.dp)
                QuickStatus.NotLocal -> Dot(Grey, 14.dp)
                is QuickStatus.Failed -> Dot(Orange, 14.dp)
            }
            Spacer(Modifier.width(12.dp))
            Column(Modifier.weight(1f)) {
                Text(f.name, style = MaterialTheme.typography.titleMedium)
                Text(f.host, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                val line = when (status) {
                    is QuickStatus.Online -> "En ligne" + (status.apiVersion?.let { " · API $it" } ?: "")
                    QuickStatus.Offline -> "Injoignable"
                    QuickStatus.NotLocal -> "Hors du réseau local"
                    is QuickStatus.Failed -> status.message
                    else -> "Connexion…"
                }
                Text(line, style = MaterialTheme.typography.bodySmall)
            }
            IconButton(onClick = onEdit) { Icon(Icons.Default.Edit, contentDescription = "Modifier") }
            IconButton(onClick = onDelete) { Icon(Icons.Default.Delete, contentDescription = "Supprimer") }
        }
    }
}
