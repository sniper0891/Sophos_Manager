package fr.sophosmobile.net

enum class Severity { Critical, Warning, Info, Ok }

data class Finding(val severity: Severity, val title: String, val detail: String, val category: String)

data class HealthReport(val score: Int, val findings: List<Finding>, val sources: List<String>)

/**
 * Bilan d'intégrité : état des services, licences et ressources (SNMP)
 * et analyse de la configuration des règles (API).
 */
object Audit {
    fun run(api: SophosApi, sfos: SfosSnmp?): HealthReport {
        val f = ArrayList<Finding>()
        val sources = ArrayList<String>()

        if (sfos != null) {
            runCatching {
                val info = sfos.info()
                sources += "SNMP"
                info.diskPct?.let {
                    when {
                        it >= 95 -> f += Finding(Severity.Critical, "Disque presque plein ($it %)", "Purge les journaux et rapports anciens dans la console.", "Ressources")
                        it >= 85 -> f += Finding(Severity.Warning, "Disque chargé ($it %)", "Surveille l'espace : les journaux et rapports s'accumulent.", "Ressources")
                        else -> f += Finding(Severity.Ok, "Disque : $it %", "", "Ressources")
                    }
                }
                info.swapPct?.let {
                    if (it >= 50) f += Finding(Severity.Warning, "Swap utilisé à $it %", "La mémoire vive est insuffisante pour la charge actuelle.", "Ressources")
                }
                info.temps.forEach { (n, t) ->
                    if (t >= 85) f += Finding(Severity.Warning, "Température $n élevée (${t.toInt()} °C)", "Vérifie la ventilation de l'appareil.", "Matériel")
                }
                info.firmware?.let { f += Finding(Severity.Info, "Firmware : $it", "Vérifie les mises à jour dans Backup & firmware.", "Système") }
            }.onFailure { f += Finding(Severity.Warning, "SNMP indisponible", it.friendly(), "Système") }

            runCatching {
                val svc = sfos.services().filter { it.relevant }
                val bad = svc.filter { !it.ok }
                bad.forEach {
                    val sev = if (it.key in SfosSnmp.CRITICAL_SERVICES) Severity.Critical else Severity.Warning
                    f += Finding(sev, "Service ${it.name} : ${it.label}", "Redémarre le service dans Diagnostic > Services, ou redémarre l'appareil.", "Services")
                }
                if (bad.isEmpty() && svc.isNotEmpty()) f += Finding(Severity.Ok, "${svc.size} services en marche", "", "Services")
            }

            runCatching {
                sfos.licences().filter { it.owned }.forEach { l ->
                    val d = l.daysLeft()
                    when {
                        l.status == 4 || (d != null && d < 0) ->
                            f += Finding(Severity.Critical, "Licence ${l.module} expirée", "La protection correspondante n'est plus mise à jour.", "Licences")
                        d != null && d <= 30 ->
                            f += Finding(Severity.Warning, "Licence ${l.module} : $d jour(s) restant(s)", "Expire le ${l.expiry}. Pense au renouvellement.", "Licences")
                        else -> f += Finding(Severity.Ok, "Licence ${l.module}", l.expiry?.let { "Valide jusqu'au $it" } ?: "Active", "Licences")
                    }
                }
            }

            runCatching {
                sfos.ha()?.takeIf { it.enabled }?.let { ha ->
                    if (ha.current == 4 || ha.peer == 4) {
                        f += Finding(Severity.Critical, "Haute disponibilité en défaut", "État local : ${HaInfo.stateLabel(ha.current)}, pair : ${HaInfo.stateLabel(ha.peer)}.", "Système")
                    }
                }
            }

            runCatching {
                sfos.tunnels().filter { it.activated == 1 && it.status != 1 }.forEach {
                    f += Finding(Severity.Warning, "Tunnel VPN ${it.name} : ${it.statusLabel}", "Le tunnel est activé mais pas établi.", "VPN")
                }
            }
        }

        runCatching {
            val rules = api.rules()
            sources += "API"
            auditRules(rules, f)
        }.onFailure { f += Finding(Severity.Warning, "API indisponible", it.friendly(), "Configuration") }

        val crit = f.count { it.severity == Severity.Critical }
        val warn = f.count { it.severity == Severity.Warning }
        val info = f.count { it.severity == Severity.Info }
        val score = (100 - crit * 20 - warn * 7 - info).coerceIn(0, 100)
        return HealthReport(score, f.sortedBy { it.severity.ordinal }, sources)
    }

    private fun auditRules(rules: List<FwRule>, f: MutableList<Finding>) {
        val enabled = rules.filter { it.enabled }
        val disabled = rules.size - enabled.size
        var noLog = 0
        var outNoIps = 0
        var outNoWeb = 0

        for (r in enabled) {
            val d = RuleDraft.from(r)
            if (d.action != "Accept") continue
            val srcAny = d.srcZones.isEmpty()
            val fromWan = srcAny || d.srcZones.any { it.equals("WAN", true) }
            val toInside = d.dstZones.isEmpty() || d.dstZones.any { it.uppercase() in setOf("LAN", "DMZ", "WIFI", "LOCAL") }
            val toWan = d.dstZones.any { it.equals("WAN", true) }
            val anyNets = d.srcNets.isEmpty() && d.dstNets.isEmpty()
            val anySvc = d.services.isEmpty()

            if (srcAny && d.dstZones.isEmpty() && anyNets && anySvc) {
                f += Finding(Severity.Critical, "« ${r.name} » autorise tout vers tout", "Aucune zone, réseau ni service n'est restreint. Restreins ou supprime cette règle.", "Règles")
                continue
            }
            if (fromWan && toInside) {
                if (d.srcNets.isEmpty() && anySvc) {
                    f += Finding(Severity.Critical, "« ${r.name} » ouvre l'accès depuis Internet", "Trafic WAN entrant autorisé sans restriction de service. Limite les services et les sources.", "Règles")
                } else if (d.ips == "None") {
                    f += Finding(Severity.Warning, "« ${r.name} » : trafic entrant sans IPS", "Applique une stratégie IPS (ex. « WAN TO LAN ») aux flux venant d'Internet.", "Règles")
                }
            }
            if (toWan && !fromWan) {
                if (d.ips == "None") outNoIps++
                if (d.webFilter == "None") outNoWeb++
            }
            if (!d.log) noLog++
        }

        if (outNoIps > 0) f += Finding(Severity.Info, "$outNoIps règle(s) sortante(s) sans IPS", "L'IPS protège aussi les postes internes contre les exploits.", "Règles")
        if (outNoWeb > 0) f += Finding(Severity.Info, "$outNoWeb règle(s) sortante(s) sans filtrage web", "Le filtrage web bloque les sites malveillants connus.", "Règles")
        if (noLog > 0) f += Finding(Severity.Info, "$noLog règle(s) sans journalisation", "Sans journal, impossible d'analyser le trafic en cas d'incident.", "Règles")
        if (disabled > 0) f += Finding(Severity.Info, "$disabled règle(s) désactivée(s)", "Supprime celles qui ne servent plus pour garder une liste lisible.", "Règles")
        if (f.none { it.category == "Règles" && it.severity <= Severity.Warning }) {
            f += Finding(Severity.Ok, "${enabled.size} règles actives analysées", "Aucune règle dangereuse détectée.", "Règles")
        }
    }
}
