package fr.sophosmobile.data

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject
import java.io.File

data class Sample(
    val t: Long,
    val reachable: Boolean,
    val cpu: Int? = null,
    val ram: Int? = null,
    val disk: Int? = null,
    val users: Long? = null,
    val conns: Long? = null,
    /** Compteurs d'octets cumulés par interface : nom -> (entrée, sortie). */
    val ifs: Map<String, Pair<Long, Long>> = emptyMap(),
)

data class AlertLog(val t: Long, val title: String, val text: String)

/** Historique local (7 jours) alimenté par la surveillance en arrière-plan, et journal des alertes. */
class History(context: Context, private val id: String) {
    private val dir = File(context.filesDir, "history").apply { mkdirs() }
    private val samplesFile = File(dir, "$id.json")
    private val alertsFile = File(dir, "$id-alerts.json")

    @Synchronized
    fun samples(): List<Sample> = runCatching {
        val arr = JSONArray(samplesFile.readText())
        (0 until arr.length()).map { i ->
            val o = arr.getJSONObject(i)
            val ifs = o.optJSONObject("ifs")?.let { j ->
                j.keys().asSequence().associateWith { k ->
                    val a = j.getJSONArray(k)
                    a.getLong(0) to a.getLong(1)
                }
            } ?: emptyMap()
            Sample(
                t = o.getLong("t"), reachable = o.optBoolean("ok", true),
                cpu = o.optIntOrNull("cpu"), ram = o.optIntOrNull("ram"), disk = o.optIntOrNull("disk"),
                users = o.optLongOrNull("users"), conns = o.optLongOrNull("conns"), ifs = ifs,
            )
        }
    }.getOrDefault(emptyList())

    @Synchronized
    fun add(s: Sample) {
        val limit = System.currentTimeMillis() - 7L * 24 * 3600 * 1000
        val list = (samples() + s).filter { it.t >= limit }.takeLast(2000)
        val arr = JSONArray()
        list.forEach { x ->
            val o = JSONObject().put("t", x.t).put("ok", x.reachable)
            x.cpu?.let { o.put("cpu", it) }
            x.ram?.let { o.put("ram", it) }
            x.disk?.let { o.put("disk", it) }
            x.users?.let { o.put("users", it) }
            x.conns?.let { o.put("conns", it) }
            if (x.ifs.isNotEmpty()) {
                val j = JSONObject()
                x.ifs.forEach { (k, v) -> j.put(k, JSONArray().put(v.first).put(v.second)) }
                o.put("ifs", j)
            }
            arr.put(o)
        }
        samplesFile.writeText(arr.toString())
    }

    fun lastSampleTime(): Long? = samples().lastOrNull()?.t

    @Synchronized
    fun alerts(): List<AlertLog> = runCatching {
        val arr = JSONArray(alertsFile.readText())
        (0 until arr.length()).map { i ->
            val o = arr.getJSONObject(i)
            AlertLog(o.getLong("t"), o.getString("title"), o.optString("text"))
        }
    }.getOrDefault(emptyList())

    @Synchronized
    fun logAlert(title: String, text: String) {
        val list = (alerts() + AlertLog(System.currentTimeMillis(), title, text)).takeLast(200)
        val arr = JSONArray()
        list.forEach { arr.put(JSONObject().put("t", it.t).put("title", it.title).put("text", it.text)) }
        alertsFile.writeText(arr.toString())
    }

    @Synchronized
    fun clear() {
        samplesFile.delete()
        alertsFile.delete()
    }
}

private fun JSONObject.optIntOrNull(k: String): Int? = if (has(k)) optInt(k) else null
private fun JSONObject.optLongOrNull(k: String): Long? = if (has(k)) optLong(k) else null
