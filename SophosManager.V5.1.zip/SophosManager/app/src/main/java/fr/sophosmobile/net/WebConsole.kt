package fr.sophosmobile.net

import org.w3c.dom.Element
import java.net.HttpURLConnection
import java.net.URL
import java.net.URLEncoder
import javax.net.ssl.HostnameVerifier
import javax.net.ssl.HttpsURLConnection

/**
 * Accès à la console web (WebAdmin) pour les données que l'API XML n'expose pas :
 * baux DHCP, état et pilotage des services, utilisateurs VPN connectés, rapports.
 *
 * Cette interface n'est pas documentée par Sophos : une mise à jour du firmware peut la changer.
 * En cas d'échec, les écrans concernés affichent un message clair plutôt que de planter.
 */
class WebConsole(
    host: String,
    private val username: String,
    private val password: String,
    private val fingerprint: String?,
    private val timeoutMs: Int = 15_000,
) {
    val baseUrl: String = SophosClient.baseUrlOf(host) + "/webconsole"

    private var cookies: String? = null
    private var csrfToken: String? = null

    class WebException(message: String, val kind: Kind) : Exception(message) {
        enum class Kind { Login, Session, Access, Network, Parse }
    }

    private fun trust() = Tls.PinnedTrustManager(fingerprint)

    private fun open(path: String): HttpsURLConnection {
        val conn = URL(baseUrl + path).openConnection() as HttpsURLConnection
        conn.sslSocketFactory = Tls.socketFactory(trust())
        conn.hostnameVerifier = HostnameVerifier { _, _ -> true }
        conn.connectTimeout = timeoutMs
        conn.readTimeout = timeoutMs
        cookies?.let { conn.setRequestProperty("Cookie", it) }
        csrfToken?.let { conn.setRequestProperty("X-CSRF-Token", it) }
        conn.setRequestProperty("X-Requested-With", "XMLHttpRequest")
        conn.setRequestProperty("Referer", "$baseUrl/webpages/index.jsp")
        return conn
    }

    private fun readBody(conn: HttpsURLConnection): String {
        val code = conn.responseCode
        val stream = if (code < 400) conn.inputStream else conn.errorStream
        val body = stream?.bufferedReader()?.use { it.readText() } ?: ""
        // Mémorise les cookies de session renvoyés par le pare-feu.
        conn.headerFields["Set-Cookie"]?.let { list ->
            val jar = LinkedHashMap<String, String>()
            cookies?.split("; ")?.forEach { c -> c.substringBefore('=').let { k -> jar[k] = c } }
            list.forEach { raw ->
                val pair = raw.substringBefore(';')
                jar[pair.substringBefore('=')] = pair
            }
            cookies = jar.values.joinToString("; ")
        }
        return body
    }

    /** Ouvre une session : POST de connexion, puis lecture du jeton CSRF dans index.jsp. */
    fun login() {
        try {
            // 1. Page de connexion : récupère un premier cookie JSESSIONID.
            readBody(open("/webpages/login.jsp"))

            // 2. POST des identifiants (mode 151).
            val json = "{\"username\":${jsonStr(username)},\"password\":${jsonStr(password)},\"languageid\":\"5\"}"
            val payload = "mode=151&json=" + enc(json) + "&__RequestType=ajax&t=" + System.currentTimeMillis()
            val conn = open("/Controller")
            conn.requestMethod = "POST"
            conn.doOutput = true
            conn.setRequestProperty("Content-Type", "application/x-www-form-urlencoded; charset=UTF-8")
            conn.outputStream.use { it.write(payload.toByteArray()) }
            val resp = readBody(conn)
            if (resp.contains("Authentication Failure", true) || resp.contains("\"status\":5", false) ||
                resp.contains("Invalid", true) && resp.contains("password", true)
            ) {
                throw WebException("Identifiant ou mot de passe refusé par la console web.", WebException.Kind.Login)
            }

            // 3. index.jsp : contient le jeton CSRF utilisé pour les requêtes suivantes.
            val index = readBody(open("/webpages/index.jsp"))
            csrfToken = extractCsrf(index)
                ?: throw WebException("Connexion à la console réussie mais jeton de sécurité introuvable.", WebException.Kind.Parse)
        } catch (e: WebException) {
            throw e
        } catch (e: Exception) {
            throw WebException("Console web injoignable : ${e.message ?: e.javaClass.simpleName}", WebException.Kind.Network)
        }
    }

    private fun extractCsrf(html: String): String? {
        // Plusieurs écritures possibles selon la version du firmware.
        for (re in CSRF_PATTERNS) re.find(html)?.groupValues?.getOrNull(1)?.let { if (it.isNotBlank()) return it }
        return null
    }

    private fun ensureSession() {
        if (csrfToken == null || cookies == null) login()
    }

    /** Exécute [block] ; en cas de session expirée, se reconnecte une fois et réessaie. */
    private fun <T> withSession(block: () -> T): T {
        ensureSession()
        return try {
            block()
        } catch (e: WebException) {
            if (e.kind == WebException.Kind.Session) {
                csrfToken = null; cookies = null
                login()
                block()
            } else throw e
        }
    }

    private fun checkExpired(body: String) {
        if (body.contains("Session Expired", true) || body.contains("Language.PageDenied", false) ||
            body.contains("login.jsp", true) && body.length < 4000
        ) {
            throw WebException("Session expirée.", WebException.Kind.Session)
        }
    }

    /** GET générique sur la console (ManagePage.jsp, javascript…). */
    fun get(path: String): String = withSession {
        val body = readBody(open(path).apply { requestMethod = "GET" })
        checkExpired(body)
        body
    }

    /** POST de données encodées en formulaire. */
    fun post(path: String, form: String): String = withSession {
        val conn = open(path)
        conn.requestMethod = "POST"
        conn.doOutput = true
        conn.setRequestProperty("Content-Type", "application/x-www-form-urlencoded; charset=UTF-8")
        conn.outputStream.use { it.write(form.toByteArray()) }
        val body = readBody(conn)
        checkExpired(body)
        body
    }

    companion object {
        private val CSRF_PATTERNS = listOf(
            Regex("""X-CSRF-Token["']?\s*[:=]\s*["']([^"']+)["']""", RegexOption.IGNORE_CASE),
            Regex("""csrf[_-]?token["']?\s*[:=]\s*["']([^"']+)["']""", RegexOption.IGNORE_CASE),
            Regex("c[$]{'$'}rFt0k3n\\s*=\\s*[\"']([^\"']+)[\"']"),
            Regex("""name=["']csrf["']\s+value=["']([^"']+)["']""", RegexOption.IGNORE_CASE),
        )

        fun enc(s: String): String = URLEncoder.encode(s, "UTF-8")
        fun jsonStr(s: String): String = "\"" + s.replace("\\", "\\\\").replace("\"", "\\\"") + "\""
    }
}

/**
 * Extrait les lignes `data = {records: [ {c1:"…",c2:"…"} … ]}` d'une page ManagePage.jsp.
 * Renvoie une liste de maps clé→valeur (c1, c2, …).
 */
fun parseManagePageRecords(html: String, varPrefix: String): List<Map<String, String>> {
    val marker = "${varPrefix}data"
    val start = html.indexOf(marker).let { if (it < 0) return emptyList() else it }
    val recordsAt = html.indexOf("records:", start).let { if (it < 0) return emptyList() else it }
    val arrStart = html.indexOf('[', recordsAt).let { if (it < 0) return emptyList() else it }
    // Trouve la fin du tableau en comptant les crochets, hors chaînes.
    var depth = 0
    var i = arrStart
    var inStr = false
    var esc = false
    while (i < html.length) {
        val c = html[i]
        when {
            esc -> esc = false
            c == '\\' -> esc = true
            c == '"' -> inStr = !inStr
            !inStr && c == '[' -> depth++
            !inStr && c == ']' -> { depth--; if (depth == 0) break }
        }
        i++
    }
    val arr = html.substring(arrStart, (i + 1).coerceAtMost(html.length))
    return parseObjects(arr)
}

/** Analyse un tableau JSON-like `[{c1:"a",c2:"b"},…]` tolérant aux clés sans guillemets. */
private fun parseObjects(arr: String): List<Map<String, String>> {
    val out = ArrayList<Map<String, String>>()
    var i = 0
    while (i < arr.length) {
        if (arr[i] == '{') {
            val obj = LinkedHashMap<String, String>()
            i++
            while (i < arr.length && arr[i] != '}') {
                // clé
                while (i < arr.length && (arr[i] == ' ' || arr[i] == ',' || arr[i] == '\n' || arr[i] == '\r' || arr[i] == '\t')) i++
                val keyStart = i
                if (i < arr.length && arr[i] == '"') {
                    i++
                    val s = i
                    while (i < arr.length && arr[i] != '"') i++
                    val key = arr.substring(s, i); i++
                    i = skipColon(arr, i)
                    val value = readValue(arr, i).also { i = it.second }.first
                    obj[key] = value
                } else {
                    while (i < arr.length && arr[i] != ':') i++
                    val key = arr.substring(keyStart, i).trim()
                    i++ // ':'
                    val value = readValue(arr, i).also { i = it.second }.first
                    if (key.isNotEmpty()) obj[key] = value
                }
                while (i < arr.length && (arr[i] == ' ' || arr[i] == '\n' || arr[i] == '\r' || arr[i] == '\t')) i++
                if (i < arr.length && arr[i] == ',') i++
            }
            out += obj
            if (i < arr.length) i++ // '}'
        } else i++
    }
    return out
}

private fun skipColon(s: String, from: Int): Int {
    var i = from
    while (i < s.length && s[i] != ':') i++
    return i + 1
}

/** Lit une valeur (chaîne entre guillemets ou brute jusqu'à , ou }). Renvoie (valeur, indexSuivant). */
private fun readValue(s: String, from: Int): Pair<String, Int> {
    var i = from
    while (i < s.length && (s[i] == ' ' || s[i] == '\t')) i++
    if (i < s.length && s[i] == '"') {
        i++
        val sb = StringBuilder()
        while (i < s.length && s[i] != '"') {
            if (s[i] == '\\' && i + 1 < s.length) { sb.append(s[i + 1]); i += 2 } else { sb.append(s[i]); i++ }
        }
        i++ // guillemet fermant
        return sb.toString() to i
    }
    val start = i
    while (i < s.length && s[i] != ',' && s[i] != '}') i++
    return s.substring(start, i).trim() to i
}
