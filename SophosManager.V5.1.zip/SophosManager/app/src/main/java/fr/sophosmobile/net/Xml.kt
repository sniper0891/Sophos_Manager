package fr.sophosmobile.net

import org.w3c.dom.Document
import org.w3c.dom.Element
import org.w3c.dom.Node
import java.io.StringReader
import java.io.StringWriter
import javax.xml.parsers.DocumentBuilderFactory
import javax.xml.transform.OutputKeys
import javax.xml.transform.TransformerFactory
import javax.xml.transform.dom.DOMSource
import javax.xml.transform.stream.StreamResult
import org.xml.sax.InputSource

object Xml {
    fun parse(text: String): Element {
        val f = DocumentBuilderFactory.newInstance()
        f.isNamespaceAware = false
        val doc: Document = f.newDocumentBuilder().parse(InputSource(StringReader(text)))
        return doc.documentElement
    }

    fun serialize(e: Element): String {
        val t = TransformerFactory.newInstance().newTransformer()
        t.setOutputProperty(OutputKeys.OMIT_XML_DECLARATION, "yes")
        t.setOutputProperty(OutputKeys.INDENT, "no")
        val w = StringWriter()
        t.transform(DOMSource(e), StreamResult(w))
        return w.toString()
    }

    fun esc(s: String): String = buildString {
        for (c in s) when (c) {
            '&' -> append("&amp;")
            '<' -> append("&lt;")
            '>' -> append("&gt;")
            '"' -> append("&quot;")
            '\'' -> append("&apos;")
            else -> append(c)
        }
    }
}

fun Element.children(name: String? = null): List<Element> {
    val out = ArrayList<Element>()
    val nl = childNodes
    for (i in 0 until nl.length) {
        val n = nl.item(i)
        if (n.nodeType == Node.ELEMENT_NODE && (name == null || n.nodeName == name)) out += n as Element
    }
    return out
}

fun Element.child(name: String): Element? = children(name).firstOrNull()

/** Texte d'un enfant direct, ou null s'il est absent ou vide. */
fun Element.text(name: String): String? = child(name)?.textContent?.trim()?.ifEmpty { null }

/** Premier descendant portant ce nom (recherche en profondeur). */
fun Element.find(name: String): Element? {
    for (c in children()) {
        if (c.nodeName == name) return c
        c.find(name)?.let { return it }
    }
    return null
}

/** Textes des enfants d'un conteneur, ex. <SourceNetworks><Network>a</Network>…</SourceNetworks>. */
fun Element.listUnder(container: String): List<String> =
    find(container)?.children()?.mapNotNull { it.textContent?.trim()?.ifEmpty { null } } ?: emptyList()

fun Element.setChildText(name: String, value: String) {
    val c = child(name) ?: ownerDocument.createElement(name).also { appendChild(it) }
    c.textContent = value
}

fun Element.appendText(name: String, value: String): Element {
    val c = ownerDocument.createElement(name)
    c.textContent = value
    appendChild(c)
    return c
}
