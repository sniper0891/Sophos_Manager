package fr.sophosmobile.net

import fr.sophosmobile.net.Xml.esc
import org.w3c.dom.Element

/** Contenu éditable d'une règle de pare-feu (type « Network »). */
data class RuleDraft(
    val name: String = "",
    val description: String = "",
    val enabled: Boolean = true,
    val action: String = "Accept",
    val log: Boolean = true,
    val srcZones: List<String> = emptyList(),
    val srcNets: List<String> = emptyList(),
    val dstZones: List<String> = emptyList(),
    val dstNets: List<String> = emptyList(),
    val services: List<String> = emptyList(),
    val schedule: String = "All The Time",
    val ips: String = "None",
    val webFilter: String = "None",
    val appControl: String = "None",
    val scanVirus: Boolean = false,
    val zeroDay: Boolean = false,
    val decryptHttps: Boolean = false,
    /** Pour une création : "Top", "Bottom", "After". */
    val position: String = "Top",
    val anchor: String? = null,
) {
    companion object {
        fun policyOf(e: Element): Element? = e.child("NetworkPolicy") ?: e.child("UserPolicy")

        fun from(rule: FwRule): RuleDraft {
            val e = rule.el
            val p = policyOf(e)
            fun pt(n: String) = p?.text(n)
            fun pl(c: String) = p?.listUnder(c) ?: emptyList()
            return RuleDraft(
                name = rule.name,
                description = e.text("Description") ?: "",
                enabled = rule.enabled,
                action = pt("Action") ?: "Accept",
                log = pt("LogTraffic").equals("Enable", true),
                srcZones = pl("SourceZones"), srcNets = pl("SourceNetworks"),
                dstZones = pl("DestinationZones"), dstNets = pl("DestinationNetworks"),
                services = pl("Services"),
                schedule = pt("Schedule") ?: "All The Time",
                ips = pt("IntrusionPrevention") ?: "None",
                webFilter = pt("WebFilter") ?: "None",
                appControl = pt("ApplicationControl") ?: "None",
                scanVirus = pt("ScanVirus").equals("Enable", true),
                zeroDay = pt("ZeroDayProtection").equals("Enable", true),
                decryptHttps = pt("DecryptHTTPS").equals("Enable", true),
            )
        }
    }
}

private fun en(b: Boolean) = if (b) "Enable" else "Disable"

private fun listXml(container: String, item: String, values: List<String>) =
    if (values.isEmpty()) "" else "<$container>${values.joinToString("") { "<$item>${esc(it)}</$item>" }}</$container>"

fun RuleDraft.toNewXml(): String = buildString {
    append("<FirewallRule><Name>${esc(name)}</Name><Description>${esc(description)}</Description>")
    append("<IPFamily>IPv4</IPFamily><Status>${en(enabled)}</Status><Position>$position</Position>")
    if (position == "After" && anchor != null) append("<After><Name>${esc(anchor)}</Name></After>")
    if (position == "Before" && anchor != null) append("<Before><Name>${esc(anchor)}</Name></Before>")
    append("<PolicyType>Network</PolicyType><NetworkPolicy>")
    append("<Action>$action</Action><LogTraffic>${en(log)}</LogTraffic><SkipLocalDestined>Disable</SkipLocalDestined>")
    append(listXml("SourceZones", "Zone", srcZones))
    append(listXml("DestinationZones", "Zone", dstZones))
    append("<Schedule>${esc(schedule)}</Schedule>")
    append(listXml("SourceNetworks", "Network", srcNets))
    append(listXml("Services", "Service", services))
    append(listXml("DestinationNetworks", "Network", dstNets))
    if (action == "Accept") {
        append("<WebFilter>${esc(webFilter)}</WebFilter><ScanVirus>${en(scanVirus)}</ScanVirus>")
        append("<ZeroDayProtection>${en(zeroDay)}</ZeroDayProtection><DecryptHTTPS>${en(decryptHttps)}</DecryptHTTPS>")
        append("<ApplicationControl>${esc(appControl)}</ApplicationControl>")
        append("<IntrusionPrevention>${esc(ips)}</IntrusionPrevention>")
    }
    append("</NetworkPolicy></FirewallRule>")
}

/** Applique le brouillon sur la règle lue, sans toucher aux réglages que l'appli ne gère pas. */
internal fun RuleDraft.patch(e: Element) {
    e.setChildText("Description", description)
    e.setChildText("Status", en(enabled))
    val p = RuleDraft.policyOf(e) ?: e.ownerDocument.createElement("NetworkPolicy").also { e.appendChild(it) }
    p.setChildText("Action", action)
    p.setChildText("LogTraffic", en(log))
    p.setChildText("Schedule", schedule)
    fun setList(container: String, item: String, values: List<String>) {
        p.child(container)?.let { p.removeChild(it) }
        if (values.isNotEmpty()) {
            val c = e.ownerDocument.createElement(container)
            values.forEach { c.appendText(item, it) }
            p.appendChild(c)
        }
    }
    setList("SourceZones", "Zone", srcZones)
    setList("DestinationZones", "Zone", dstZones)
    setList("SourceNetworks", "Network", srcNets)
    setList("DestinationNetworks", "Network", dstNets)
    setList("Services", "Service", services)
    if (action == "Accept") {
        p.setChildText("IntrusionPrevention", ips)
        p.setChildText("WebFilter", webFilter)
        p.setChildText("ApplicationControl", appControl)
        p.setChildText("ScanVirus", en(scanVirus))
        p.setChildText("ZeroDayProtection", en(zeroDay))
        p.setChildText("DecryptHTTPS", en(decryptHttps))
    }
}

/** Listes proposées dans l'éditeur de règle. */
data class RuleOptions(
    val zones: List<String>,
    val networks: List<String>,
    val services: List<String>,
    val schedules: List<String>,
    val ipsPolicies: List<String>,
    val webPolicies: List<String>,
    val appPolicies: List<String>,
    val ruleNames: List<String>,
)

data class PortForward(
    val name: String,
    val inboundInterface: String,
    val protocol: String, // TCP, UDP, TCP+UDP
    val externalPort: String,
    val serverIp: String,
    val internalPort: String,
    val serverZone: String,
    val allowedSources: List<String>,
    val ips: String,
)

// ---------- Extensions de l'API ----------

fun SophosApi.ruleOptions(): RuleOptions {
    val nets = (names("IPHost") + names("IPHostGroup") + names("FQDNHost") + names("FQDNHostGroup") +
        names("MACHost") + names("CountryGroup")).distinct().sorted()
    return RuleOptions(
        zones = names("Zone").ifEmpty { listOf("LAN", "WAN", "DMZ", "VPN", "LOCAL", "WiFi") },
        networks = nets,
        services = (names("Services") + names("ServiceGroup")).distinct().sorted(),
        schedules = (listOf("All The Time") + names("Schedule")).distinct(),
        ipsPolicies = (listOf("None") + names("IPSPolicy")).distinct(),
        webPolicies = (listOf("None") + names("WebFilterPolicy")).distinct(),
        appPolicies = (listOf("None") + names("ApplicationFilterPolicy")).distinct(),
        ruleNames = names("FirewallRule"),
    )
}

fun SophosApi.addRule(d: RuleDraft) = add(d.toNewXml())

fun SophosApi.updateRule(rule: FwRule, d: RuleDraft) {
    val e = editable(rule.el)
    d.patch(e)
    update(Xml.serialize(e))
}

fun SophosApi.deleteRule(rule: FwRule) = remove("FirewallRule", rule.name)

fun SophosApi.duplicateRule(rule: FwRule, newName: String) {
    val e = editable(rule.el)
    e.setChildText("Name", newName)
    e.setChildText("Status", "Disable")
    e.setChildText("Position", "After")
    e.child("Before")?.let { e.removeChild(it) }
    e.child("After")?.let { e.removeChild(it) }
    val after = e.ownerDocument.createElement("After")
    after.appendText("Name", rule.name)
    e.appendChild(after)
    add(Xml.serialize(e))
}

/** position : "Top", "Bottom", "After" ou "Before" (avec anchor). */
fun SophosApi.moveRule(rule: FwRule, position: String, anchor: String? = null) {
    val e = editable(rule.el)
    e.setChildText("Position", position)
    e.child("Before")?.let { e.removeChild(it) }
    e.child("After")?.let { e.removeChild(it) }
    if (anchor != null && (position == "After" || position == "Before")) {
        val a = e.ownerDocument.createElement(position)
        a.appendText("Name", anchor)
        e.appendChild(a)
    }
    update(Xml.serialize(e))
}

fun SophosApi.deleteNat(rule: NatRule) = remove("NATRule", rule.name)

fun SophosApi.interfaceNames(): List<String> = names("Interface")

/**
 * Redirection de port complète : objet serveur, services, règle de pare-feu et règle NAT.
 * La règle de pare-feu utilise la destination d'origine (IP WAN) et la zone du serveur, comme l'attend SFOS.
 */
fun SophosApi.createPortForward(pf: PortForward) {
    require(SophosApi.IPV4.matches(pf.serverIp)) { "IP du serveur invalide" }
    require(pf.externalPort.matches(Regex("^\\d{1,5}(:\\d{1,5})?$"))) { "Port externe invalide (ex. 443 ou 8000:8010)" }
    val intPort = pf.internalPort.ifBlank { pf.externalPort }
    require(intPort.matches(Regex("^\\d{1,5}(:\\d{1,5})?$"))) { "Port interne invalide" }
    require(pf.name.isNotBlank() && !pf.name.contains(',')) { "Nom invalide" }

    val hosts = names("IPHost").toSet()
    val hostName = "SRV-${pf.serverIp}"
    if (hostName !in hosts) {
        add("<IPHost><Name>$hostName</Name><IPFamily>IPv4</IPFamily><HostType>IP</HostType><IPAddress>${pf.serverIp}</IPAddress></IPHost>")
    }
    val services = names("Services").toSet()
    fun ensureService(port: String): String {
        val n = "APP-${pf.protocol.replace("+", "")}-${port.replace(':', '-')}"
        if (n !in services) add(ObjectKinds.serviceXml(n, "Cree par Sophos Manager", pf.protocol, port, "1:65535"))
        return n
    }
    val extSvc = ensureService(pf.externalPort)
    val intSvc = if (intPort == pf.externalPort) null else ensureService(intPort)
    val wanIp = "#${pf.inboundInterface}"

    add(
        RuleDraft(
            name = "APP NAT ${pf.name}", description = "Redirection creee par Sophos Manager",
            action = "Accept", log = true,
            srcZones = listOf("WAN"), srcNets = pf.allowedSources,
            dstZones = listOf(pf.serverZone), dstNets = listOf(wanIp),
            services = listOf(extSvc), ips = pf.ips, position = "Top",
        ).toNewXml(),
    )
    add(
        buildString {
            append("<NATRule><Name>${esc("APP DNAT ${pf.name}")}</Name><Description>Redirection creee par Sophos Manager</Description>")
            append("<IPFamily>IPv4</IPFamily><Status>Enable</Status><Position>Top</Position>")
            append(listXml("OriginalSourceNetworks", "Network", pf.allowedSources))
            append("<TranslatedSource>Original</TranslatedSource>")
            append("<OriginalDestinationNetworks><Network>${esc(wanIp)}</Network></OriginalDestinationNetworks>")
            append("<TranslatedDestination>$hostName</TranslatedDestination>")
            append("<OriginalServices><Service>$extSvc</Service></OriginalServices>")
            append("<TranslatedService>${intSvc ?: "Original"}</TranslatedService>")
            append("<InboundInterfaces><Interface>${esc(pf.inboundInterface)}</Interface></InboundInterfaces>")
            append("<OverrideInterfaceNATPolicy>Disable</OverrideInterfaceNATPolicy>")
            append("</NATRule>")
        },
    )
}

// ---------- DNS ----------

data class DnsEntry(val host: String, val ips: List<String>, val reverse: Boolean, internal val el: Element)

fun SophosApi.dnsEntries(): List<DnsEntry> = getAll("DNSHostEntry", key = "HostName").map { e ->
    DnsEntry(
        host = e.text("HostName") ?: "?",
        ips = e.child("AddressList")?.children("Address")?.mapNotNull { it.text("IPAddress") } ?: emptyList(),
        reverse = e.text("AddReverseDNSLookUp").equals("Enable", true),
        el = e,
    )
}.sortedBy { it.host }

fun SophosApi.saveDnsEntry(host: String, ips: List<String>, reverse: Boolean, isNew: Boolean) {
    require(ips.isNotEmpty() && ips.size <= 8) { "Entre 1 et 8 adresses" }
    ips.forEach { require(SophosApi.IPV4.matches(it)) { "Adresse invalide : $it" } }
    val xml = buildString {
        append("<DNSHostEntry><HostName>${esc(host)}</HostName><AddressList>")
        ips.forEach {
            append("<Address><EntryType>Manual</EntryType><IPFamily>IPv4</IPFamily><IPAddress>$it</IPAddress>")
            append("<TTL>60</TTL><Weight>1</Weight><PublishOnWAN>Disable</PublishOnWAN></Address>")
        }
        append("</AddressList><AddReverseDNSLookUp>${en(reverse)}</AddReverseDNSLookUp></DNSHostEntry>")
    }
    if (isNew) add(xml) else update(xml)
}

fun SophosApi.deleteDnsEntry(e: DnsEntry) = remove("DNSHostEntry", e.host, key = "HostName")

/** Réglages DNS du pare-feu, aplatis en paires clé/valeur pour l'affichage. */
fun SophosApi.dnsSettings(): List<Pair<String, String>> {
    val e = runCatching { getAll("DNS", key = "IPv4Settings").firstOrNull() }.getOrNull()
        ?: runCatching { c().call("<Get><DNS/></Get>").child("DNS") }.getOrNull()
        ?: return emptyList()
    return flatten(e)
}

fun flatten(e: Element, prefix: String = ""): List<Pair<String, String>> {
    val out = ArrayList<Pair<String, String>>()
    for (ch in e.children()) {
        if (ch.hasAttribute("code")) continue
        val key = if (prefix.isEmpty()) ch.nodeName else "$prefix › ${ch.nodeName}"
        if (ch.children().isEmpty()) {
            val v = ch.textContent.trim()
            if (v.isNotEmpty()) out += key to v
        } else out += flatten(ch, key)
    }
    return out
}
