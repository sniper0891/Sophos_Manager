package fr.sophosmobile.ui

import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Card
import androidx.compose.material3.ExtendedFloatingActionButton
import androidx.compose.material3.FilterChip
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.SnackbarHostState
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateMapOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import fr.sophosmobile.net.FType
import fr.sophosmobile.net.ObjItem
import fr.sophosmobile.net.ObjKind
import fr.sophosmobile.net.ObjectKinds
import fr.sophosmobile.net.SophosApi
import fr.sophosmobile.net.deleteObject
import fr.sophosmobile.net.friendly
import fr.sophosmobile.net.objects
import fr.sophosmobile.net.saveObject
import fr.sophosmobile.net.valuesOf
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

private sealed interface ObjEdit {
    data object New : ObjEdit
    data class Existing(val item: ObjItem) : ObjEdit
}

@Composable
fun ObjectsTab(api: SophosApi, snackbar: SnackbarHostState) {
    var kindIdx by rememberSaveable { mutableStateOf(0) }
    val kind = ObjectKinds.ALL[kindIdx]
    val loader = rememberLoader(kind.tag) { api.objects(kind) }
    val scope = rememberCoroutineScope()
    var filter by remember { mutableStateOf("") }
    var editing by remember { mutableStateOf<ObjEdit?>(null) }
    var toDelete by remember { mutableStateOf<ObjItem?>(null) }

    Box(Modifier.fillMaxSize()) {
        LazyColumn(
            Modifier.fillMaxSize(),
            contentPadding = PaddingValues(start = 16.dp, end = 16.dp, top = 8.dp, bottom = 96.dp),
            verticalArrangement = Arrangement.spacedBy(8.dp),
        ) {
            item {
                Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    ObjectKinds.ALL.forEachIndexed { i, k ->
                        FilterChip(selected = i == kindIdx, onClick = { kindIdx = i; filter = "" }, label = { Text(k.title) })
                    }
                }
            }
            val items = loader.data
            item { ListHeader(items?.let { "${it.size} ${kind.title.lowercase()}" } ?: kind.title, loader.loading) { loader.reload() } }
            item { OutlinedTextField(filter, { filter = it }, label = { Text("Filtrer") }, singleLine = true, modifier = Modifier.fillMaxWidth()) }
            loader.error?.let { item { ErrorBox(it) { loader.reload() } } }
            if (items == null && loader.loading) item { CenteredLoading() }
            if (items != null && items.isEmpty()) item { EmptyText("Aucun élément.") }
            items(items?.filter { filter.isBlank() || it.name.contains(filter, true) || it.summary.contains(filter, true) } ?: emptyList(), key = { it.name }) { o ->
                Card(Modifier.fillMaxWidth().clickable(enabled = o.editable) { editing = ObjEdit.Existing(o) }) {
                    Row(Modifier.padding(start = 16.dp, end = 4.dp, top = 8.dp, bottom = 8.dp), verticalAlignment = Alignment.CenterVertically) {
                        Column(Modifier.weight(1f)) {
                            Text(o.name, style = MaterialTheme.typography.titleSmall)
                            if (o.summary.isNotBlank()) InfoText(o.summary)
                            if (!o.editable && !kind.readOnly) InfoText("Objet système ou format non géré : lecture seule")
                        }
                        if (!kind.readOnly) IconButton(onClick = { toDelete = o }) { Icon(Icons.Default.Delete, contentDescription = "Supprimer") }
                    }
                }
            }
            if (kind.readOnly) item { InfoText("Affichage seul : ces éléments se modifient dans la console web pour éviter de te couper l'accès.") }
        }
        if (!kind.readOnly) {
            ExtendedFloatingActionButton(
                onClick = { editing = ObjEdit.New },
                icon = { Icon(Icons.Default.Add, null) },
                text = { Text("Ajouter") },
                modifier = Modifier.align(Alignment.BottomEnd).padding(16.dp),
            )
        }
    }

    editing?.let { e ->
        ObjectDialog(api, kind, e, onDismiss = { editing = null }) { values, isNew ->
            scope.launch {
                try {
                    withContext(Dispatchers.IO) { api.saveObject(kind, values, isNew) }
                    editing = null
                    snackbar.showSnackbar("${values["Name"]} enregistré")
                    loader.reload()
                } catch (ex: Exception) {
                    snackbar.showSnackbar((ex as? IllegalArgumentException)?.message ?: ex.friendly())
                }
            }
        }
    }

    toDelete?.let { o ->
        ConfirmDialog(
            title = "Supprimer ${o.name} ?",
            text = "Le pare-feu refusera si l'objet est encore utilisé par une règle ou un groupe.",
            confirm = "Supprimer",
            onConfirm = { scope.runAction(snackbar, "${o.name} supprimé", after = { loader.reload() }) { api.deleteObject(kind, o) } },
            onDismiss = { toDelete = null },
        )
    }
}

@Composable
private fun ObjectDialog(api: SophosApi, kind: ObjKind, target: ObjEdit, onDismiss: () -> Unit, onSave: (Map<String, String>, Boolean) -> Unit) {
    val isNew = target is ObjEdit.New
    val values = remember(target) {
        mutableStateMapOf<String, String>().apply {
            if (target is ObjEdit.Existing) putAll(kind.valuesOf(target.item))
            kind.fields.filter { it.type == FType.Choice }.forEach { f -> if (this[f.key].isNullOrBlank()) this[f.key] = f.options.first() }
        }
    }
    val refTags = kind.fields.flatMap { it.refTags }.distinct()
    val refs = rememberLoader(kind.tag + "refs") { refTags.associateWith { api.names(it) } }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text(if (isNew) "Nouvel objet · ${kind.title}" else (values["Name"] ?: "")) },
        text = {
            Column(Modifier.heightIn(max = 520.dp).verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                kind.fields.filter { it.showIf(values) }.forEach { f ->
                    when (f.type) {
                        FType.Text -> OutlinedTextField(
                            values[f.key] ?: "", { values[f.key] = it },
                            label = { Text(f.label + if (f.optional) " (facultatif)" else "") },
                            placeholder = { if (f.hint.isNotBlank()) Text(f.hint) },
                            singleLine = true,
                            enabled = !(f.key == "Name" && !isNew),
                            modifier = Modifier.fillMaxWidth(),
                        )
                        FType.Choice -> SelectField(f.label, values[f.key] ?: f.options.first(), f.options, display = ::choiceLabel) { values[f.key] = it }
                        FType.Refs -> {
                            val opts = f.refTags.flatMap { refs.data?.get(it) ?: emptyList() }
                            MultiSelectField(f.label, values[f.key].orEmpty().lines().filter { it.isNotBlank() }, opts, "Aucun") {
                                values[f.key] = it.joinToString("\n")
                            }
                        }
                    }
                }
            }
        },
        confirmButton = { TextButton(onClick = { onSave(values.toMap(), isNew) }) { Text("Enregistrer") } },
        dismissButton = { TextButton(onClick = onDismiss) { Text("Annuler") } },
    )
}

private fun choiceLabel(v: String) = when (v) {
    "IP" -> "Adresse IP"
    "Network" -> "Réseau"
    "IPRange" -> "Plage d'IP"
    "IPList" -> "Liste d'IP"
    else -> v
}
