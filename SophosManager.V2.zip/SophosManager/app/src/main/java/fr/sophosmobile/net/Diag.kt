package fr.sophosmobile.net

import java.io.ByteArrayOutputStream
import java.net.DatagramPacket
import java.net.DatagramSocket
import java.net.InetAddress
import java.net.InetSocketAddress
import java.net.Socket
import kotlin.random.Random

/** Outils de diagnostic exécutés depuis le téléphone. */
object Diag {
    /** Ping via le binaire système d'Android. */
    fun ping(target: String, count: Int = 4, onLine: (String) -> Unit) {
        val p = ProcessBuilder("ping", "-c", count.toString(), "-W", "2", target).redirectErrorStream(true).start()
        p.inputStream.bufferedReader().useLines { lines -> lines.forEach(onLine) }
        p.waitFor()
    }

    data class Hop(val ttl: Int, val address: String?, val ms: Double?)

    /** Traceroute par ping à TTL croissant (sans droits root). */
    fun traceroute(target: String, maxHops: Int = 20, onHop: (Hop) -> Unit) {
        val dest = runCatching { InetAddress.getByName(target).hostAddress }.getOrNull()
        for (ttl in 1..maxHops) {
            val start = System.nanoTime()
            val p = ProcessBuilder("ping", "-c", "1", "-W", "2", "-t", ttl.toString(), target).redirectErrorStream(true).start()
            val out = p.inputStream.bufferedReader().readText()
            p.waitFor()
            val ms = (System.nanoTime() - start) / 1e6
            val from = Regex("""[Ff]rom ([0-9.]+)""").find(out)?.groupValues?.get(1)
                ?: Regex("""bytes from ([0-9.]+)""").find(out)?.groupValues?.get(1)
            val reached = out.contains("bytes from")
            onHop(Hop(ttl, from, if (from != null) ms else null))
            if (reached || (from != null && from == dest)) break
        }
    }

    data class DnsResult(val server: String, val answers: List<String>, val rcode: Int, val ms: Long)

    /** Requête DNS de type A envoyée directement à un serveur (par ex. le pare-feu). */
    fun dnsQuery(server: String, name: String, timeoutMs: Int = 3000): DnsResult {
        val id = Random.nextInt(0, 65535)
        val q = ByteArrayOutputStream()
        q.write(id shr 8); q.write(id and 0xFF)
        q.write(0x01); q.write(0x00) // récursion demandée
        q.write(0); q.write(1); repeat(6) { q.write(0) }
        name.trimEnd('.').split('.').forEach { label ->
            val b = label.toByteArray()
            q.write(b.size); q.write(b)
        }
        q.write(0); q.write(0); q.write(1); q.write(0); q.write(1) // type A, classe IN
        val msg = q.toByteArray()
        val start = System.currentTimeMillis()
        DatagramSocket().use { s ->
            s.soTimeout = timeoutMs
            s.send(DatagramPacket(msg, msg.size, InetAddress.getByName(server), 53))
            val buf = ByteArray(1500)
            val pkt = DatagramPacket(buf, buf.size)
            s.receive(pkt)
            val ms = System.currentTimeMillis() - start
            val r = buf.copyOf(pkt.length)
            val rcode = r[3].toInt() and 0x0F
            val qd = ((r[4].toInt() and 0xFF) shl 8) or (r[5].toInt() and 0xFF)
            val an = ((r[6].toInt() and 0xFF) shl 8) or (r[7].toInt() and 0xFF)
            var pos = 12
            fun skipName() {
                while (pos < r.size) {
                    val l = r[pos].toInt() and 0xFF
                    if (l == 0) { pos++; return }
                    if (l and 0xC0 == 0xC0) { pos += 2; return }
                    pos += l + 1
                }
            }
            repeat(qd) { skipName(); pos += 4 }
            val answers = ArrayList<String>()
            repeat(an) {
                skipName()
                if (pos + 10 > r.size) return@repeat
                val type = ((r[pos].toInt() and 0xFF) shl 8) or (r[pos + 1].toInt() and 0xFF)
                val len = ((r[pos + 8].toInt() and 0xFF) shl 8) or (r[pos + 9].toInt() and 0xFF)
                pos += 10
                if (type == 1 && len == 4) answers += (0 until 4).joinToString(".") { (r[pos + it].toInt() and 0xFF).toString() }
                if (type == 5) answers += "(alias CNAME)"
                pos += len
            }
            return DnsResult(server, answers, rcode, ms)
        }
    }

    fun rcodeLabel(c: Int) = when (c) {
        0 -> "OK"; 1 -> "requête invalide"; 2 -> "échec serveur"; 3 -> "domaine inexistant"
        4 -> "non implémenté"; 5 -> "refusé"; else -> "code $c"
    }

    data class PortResult(val open: Boolean, val ms: Long, val error: String?)

    fun tcpPort(host: String, port: Int, timeoutMs: Int = 3000): PortResult {
        val start = System.currentTimeMillis()
        return try {
            Socket().use { it.connect(InetSocketAddress(host, port), timeoutMs) }
            PortResult(true, System.currentTimeMillis() - start, null)
        } catch (e: Exception) {
            PortResult(false, System.currentTimeMillis() - start, e.javaClass.simpleName)
        }
    }
}
