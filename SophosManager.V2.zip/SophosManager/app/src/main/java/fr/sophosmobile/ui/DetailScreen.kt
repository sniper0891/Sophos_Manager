package fr.sophosmobile.ui

import android.content.Intent
import android.net.Uri
import androidx.activity.compose.BackHandler
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.Edit
import androidx.compose.material.icons.filled.Home
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.Scaffold
import androidx.compose.material3.ScrollableTabRow
import androidx.compose.material3.SnackbarHost
import androidx.compose.material3.SnackbarHostState
import androidx.compose.material3.Tab
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import fr.sophosmobile.net.SophosClient

private val TABS = listOf(
    "Tableau de bord", "Intégrité", "Règles", "NAT", "Objets", "DNS", "DHCP", "Blocage", "Rapports", "Diagnostic",
)

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun DetailScreen(vm: AppViewModel, id: String) {
    val fw = vm.find(id)
    if (fw == null) {
        LaunchedEffect(Unit) { vm.screen = Screen.Home }
        return
    }
    var tab by rememberSaveable { mutableIntStateOf(0) }
    val snackbar = remember { SnackbarHostState() }
    val ctx = LocalContext.current
    BackHandler { vm.screen = Screen.Home }

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text(fw.name) },
                navigationIcon = {
                    IconButton(onClick = { vm.screen = Screen.Home }) {
                        Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "Retour")
                    }
                },
                actions = {
                    IconButton(onClick = {
                        runCatching {
                            ctx.startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(SophosClient.baseUrlOf(fw.host))))
                        }
                    }) { Icon(Icons.Default.Home, contentDescription = "Ouvrir la console web") }
                    IconButton(onClick = { vm.screen = Screen.Edit(fw.id) }) {
                        Icon(Icons.Default.Edit, contentDescription = "Modifier")
                    }
                },
            )
        },
        snackbarHost = { SnackbarHost(snackbar) },
    ) { pad ->
        Column(Modifier.padding(pad).fillMaxSize()) {
            ScrollableTabRow(selectedTabIndex = tab, edgePadding = 8.dp) {
                TABS.forEachIndexed { i, t ->
                    Tab(selected = tab == i, onClick = { tab = i }, text = { Text(t) })
                }
            }
            val api = remember(fw) { vm.apiFor(fw) }
            when (tab) {
                0 -> DashboardTab(fw)
                1 -> HealthTab(fw, api)
                2 -> RulesTab(api, snackbar)
                3 -> NatTab(api, snackbar)
                4 -> ObjectsTab(api, snackbar)
                5 -> DnsTab(api, snackbar)
                6 -> DhcpTab(api, snackbar)
                7 -> BlockTab(api, snackbar)
                8 -> ReportsTab(fw)
                9 -> DiagTab(fw, api)
            }
        }
    }
}
