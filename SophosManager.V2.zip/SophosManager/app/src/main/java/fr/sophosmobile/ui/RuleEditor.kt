package fr.sophosmobile.ui

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.FilterChip
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.SnackbarHostState
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import fr.sophosmobile.net.RuleDraft
import fr.sophosmobile.net.SophosApi
import fr.sophosmobile.net.addRule
import fr.sophosmobile.net.friendly
import fr.sophosmobile.net.ruleOptions
import fr.sophosmobile.net.updateRule
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

/** Éditeur graphique de règle, sur le modèle de la console web. */
@Composable
fun RuleEditor(api: SophosApi, target: RuleEdit, snackbar: SnackbarHostState, onClose: () -> Unit, onSaved: () -> Unit) {
    val isNew = target is RuleEdit.New
    val initial = remember(target) { (target as? RuleEdit.Existing)?.let { RuleDraft.from(it.rule) } ?: RuleDraft() }
    var d by remember(target) { mutableStateOf(initial) }
    val opts = rememberLoader("opts") { api.ruleOptions() }
    var saving by remember { mutableStateOf(false) }
    var error by remember { mutableStateOf<String?>(null) }
    val scope = rememberCoroutineScope()

    val valid = d.name.isNotBlank() && !d.name.contains(',') && (d.position != "After" || d.anchor != null)

    FullScreenDialog(
        title = if (isNew) "Nouvelle règle" else d.name,
        onDismiss = onClose,
        actions = {
            TextButton(enabled = valid && !saving, onClick = {
                saving = true
                error = null
                scope.launch {
                    try {
                        withContext(Dispatchers.IO) {
                            val draft = d.copy(name = d.name.trim())
                            when (target) {
                                RuleEdit.New -> api.addRule(draft)
                                is RuleEdit.Existing -> api.updateRule(target.rule, draft)
                            }
                        }
                        snackbar.showSnackbar(if (isNew) "Règle créée" else "Règle enregistrée")
                        onSaved()
                    } catch (e: Exception) {
                        error = (e as? IllegalArgumentException)?.message ?: e.friendly()
                    } finally {
                        saving = false
                    }
                }
            }) { Text(if (saving) "…" else "Enregistrer") }
        },
    ) { mod ->
        Column(
            mod.verticalScroll(rememberScrollState()).padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp),
        ) {
            error?.let { ErrorBox(it) }
            opts.error?.let { ErrorBox("Listes indisponibles : $it") { opts.reload() } }
            val o = opts.data
            if (o == null && opts.loading) CenteredLoading()

            if (target is RuleEdit.Existing && target.rule.policyType == "User") {
                InfoText("Règle basée sur l'utilisateur : les membres et l'identité se modifient dans la console web.")
            }

            OutlinedTextField(
                d.name, { d = d.copy(name = it) }, label = { Text("Nom") }, singleLine = true,
                enabled = isNew, modifier = Modifier.fillMaxWidth(),
            )
            OutlinedTextField(d.description, { d = d.copy(description = it) }, label = { Text("Description") }, modifier = Modifier.fillMaxWidth())

            Row(verticalAlignment = Alignment.CenterVertically) {
                Text("Règle active", Modifier.weight(1f))
                Switch(d.enabled, { d = d.copy(enabled = it) })
            }

            Text("Action", style = MaterialTheme.typography.titleSmall)
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                listOf("Accept" to "Accepter", "Drop" to "Abandonner", "Reject" to "Rejeter").forEach { (v, l) ->
                    FilterChip(selected = d.action == v, onClick = { d = d.copy(action = v) }, label = { Text(l) })
                }
            }

            if (isNew) {
                Text("Position", style = MaterialTheme.typography.titleSmall)
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    listOf("Top" to "En tête", "Bottom" to "En fin", "After" to "Après…").forEach { (v, l) ->
                        FilterChip(selected = d.position == v, onClick = { d = d.copy(position = v) }, label = { Text(l) })
                    }
                }
                if (d.position == "After") {
                    SelectField("Après la règle", d.anchor ?: "Choisir…", o?.ruleNames ?: emptyList()) { d = d.copy(anchor = it) }
                }
            }

            HorizontalDivider()
            Text("Source", style = MaterialTheme.typography.titleMedium)
            MultiSelectField("Zones source", d.srcZones, o?.zones ?: emptyList(), "Toutes (Any)") { d = d.copy(srcZones = it) }
            MultiSelectField("Réseaux et appareils source", d.srcNets, o?.networks ?: emptyList(), "Tous (Any)") { d = d.copy(srcNets = it) }

            Text("Destination et services", style = MaterialTheme.typography.titleMedium)
            MultiSelectField("Zones de destination", d.dstZones, o?.zones ?: emptyList(), "Toutes (Any)") { d = d.copy(dstZones = it) }
            MultiSelectField("Réseaux de destination", d.dstNets, o?.networks ?: emptyList(), "Tous (Any)") { d = d.copy(dstNets = it) }
            MultiSelectField("Services", d.services, o?.services ?: emptyList(), "Tous les services") { d = d.copy(services = it) }
            SelectField("Planning", d.schedule, o?.schedules ?: listOf(d.schedule)) { d = d.copy(schedule = it) }

            Row(verticalAlignment = Alignment.CenterVertically) {
                Text("Journaliser le trafic", Modifier.weight(1f))
                Switch(d.log, { d = d.copy(log = it) })
            }

            if (d.action == "Accept") {
                HorizontalDivider()
                Text("Fonctions de sécurité", style = MaterialTheme.typography.titleMedium)
                SelectField("Prévention d'intrusion (IPS)", d.ips, o?.ipsPolicies ?: listOf(d.ips), display = ::noneLabel) { d = d.copy(ips = it) }
                SelectField("Filtrage web", d.webFilter, o?.webPolicies ?: listOf(d.webFilter), display = ::noneLabel) { d = d.copy(webFilter = it) }
                SelectField("Contrôle des applications", d.appControl, o?.appPolicies ?: listOf(d.appControl), display = ::noneLabel) { d = d.copy(appControl = it) }
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text("Analyse antivirus HTTP/HTTPS", Modifier.weight(1f))
                    Switch(d.scanVirus, { d = d.copy(scanVirus = it) })
                }
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text("Protection zero-day (sandbox)", Modifier.weight(1f))
                    Switch(d.zeroDay, { d = d.copy(zeroDay = it) })
                }
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text("Déchiffrer HTTPS (proxy web)", Modifier.weight(1f))
                    Switch(d.decryptHttps, { d = d.copy(decryptHttps = it) })
                }
                InfoText("Certaines fonctions demandent la licence correspondante (Network, Web ou Zero-Day Protection).")
            }
            InfoText("Une liste vide signifie « Any » (tout).")
        }
    }
}

private fun noneLabel(v: String) = if (v == "None") "Aucun" else v
