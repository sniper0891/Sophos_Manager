package fr.sophosmobile.ui

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.Card
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.SnackbarHostState
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import fr.sophosmobile.net.SophosApi

@Composable
fun NatTab(api: SophosApi, snackbar: SnackbarHostState) {
    val loader = rememberLoader(api) { api.natRules() }
    val scope = rememberCoroutineScope()
    var busy by remember { mutableStateOf(false) }

    LazyColumn(
        Modifier.fillMaxSize(),
        contentPadding = PaddingValues(16.dp),
        verticalArrangement = Arrangement.spacedBy(8.dp),
    ) {
        val rules = loader.data
        item { ListHeader(rules?.let { "${it.size} règles NAT" } ?: "Règles NAT", loader.loading) { loader.reload() } }
        loader.error?.let { item { ErrorBox(it) { loader.reload() } } }
        if (rules == null && loader.loading) item { CenteredLoading() }
        if (rules != null && rules.isEmpty()) item { EmptyText("Aucune règle NAT.") }
        items(rules ?: emptyList(), key = { it.name }) { r ->
            Card(Modifier.fillMaxWidth()) {
                Row(Modifier.padding(start = 16.dp, end = 8.dp, top = 10.dp, bottom = 10.dp), verticalAlignment = Alignment.CenterVertically) {
                    Column(Modifier.weight(1f)) {
                        Text(r.name, style = MaterialTheme.typography.titleSmall)
                        InfoText(r.summary)
                    }
                    Switch(
                        checked = r.enabled,
                        enabled = !busy,
                        onCheckedChange = { on ->
                            busy = true
                            scope.runAction(snackbar, "${r.name} ${if (on) "activée" else "désactivée"}", after = { busy = false; loader.reload() }) {
                                api.setNatEnabled(r, on)
                            }
                        },
                    )
                }
            }
        }
        item { InfoText("Pour créer une redirection de port, utilise la console web (Règles et stratégies > NAT).") }
    }
}
