package fr.sophosmobile.alerts

import android.content.Context
import androidx.work.Constraints
import androidx.work.CoroutineWorker
import androidx.work.ExistingPeriodicWorkPolicy
import androidx.work.NetworkType
import androidx.work.PeriodicWorkRequestBuilder
import androidx.work.WorkManager
import androidx.work.WorkerParameters
import fr.sophosmobile.data.Firewall
import fr.sophosmobile.data.FirewallStore
import fr.sophosmobile.net.Monitor
import fr.sophosmobile.net.SophosApi
import fr.sophosmobile.net.SophosClient
import fr.sophosmobile.net.SophosException
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.util.concurrent.TimeUnit

/**
 * Vérification en arrière-plan (toutes les 15 min, minimum imposé par Android).
 * On ne notifie que les changements d'état, pour ne pas répéter la même alerte.
 */
class AlertWorker(ctx: Context, params: WorkerParameters) : CoroutineWorker(ctx, params) {
    private val state = ctx.getSharedPreferences("alert_state", Context.MODE_PRIVATE)

    override suspend fun doWork(): Result = withContext(Dispatchers.IO) {
        val list = FirewallStore(applicationContext).load().filter { it.alertsEnabled }
        for (fw in list) runCatching { check(fw) }
        Result.success()
    }

    private fun notifyId(fw: Firewall, key: String) = (fw.id + key).hashCode()

    private fun flag(key: String) = state.getBoolean(key, false)
    private fun setFlag(key: String, v: Boolean) = state.edit().putBoolean(key, v).apply()

    private fun check(fw: Firewall) {
        val ctx = applicationContext
        val hostOnly = SophosClient.hostOnly(fw.host)
        if (!LocalNetwork.isOnSameSubnet(ctx, hostOnly)) return // hors de chez toi : pas de vérification

        // 1. Le pare-feu répond-il ?
        val downKey = "${fw.id}_down"
        val reachable = try {
            SophosApi(SophosClient(fw.host, fw.username, fw.password, fw.certFingerprint)).ping()
            true
        } catch (e: SophosException) {
            e.kind != SophosException.Kind.Offline
        }
        if (!reachable && !flag(downKey)) {
            setFlag(downKey, true)
            Notifier.notify(ctx, notifyId(fw, "down"), "${fw.name} ne répond plus", "Le pare-feu est injoignable depuis le réseau local.")
        } else if (reachable && flag(downKey)) {
            setFlag(downKey, false)
            Notifier.notify(ctx, notifyId(fw, "down"), "${fw.name} répond à nouveau", "Le pare-feu est de nouveau joignable.")
        }
        if (!reachable || fw.snmpCommunity.isBlank()) return

        // 2. Ressources et interfaces par SNMP
        val s = runCatching { Monitor(fw.host, fw.snmpCommunity, fw.snmpPort).sample() }.getOrNull() ?: return

        fun threshold(key: String, label: String, value: Int?, max: Int) {
            if (value == null) return
            val k = "${fw.id}_$key"
            if (value >= max && !flag(k)) {
                setFlag(k, true)
                Notifier.notify(ctx, notifyId(fw, key), "${fw.name} : $label élevé", "$label à $value % (seuil $max %).")
            } else if (value < max - 5 && flag(k)) {
                setFlag(k, false)
            }
        }
        threshold("cpu", "CPU", s.cpu, fw.cpuThreshold)
        threshold("ram", "Mémoire", s.ramPct, fw.ramThreshold)

        for (i in s.ifs) {
            val k = "${fw.id}_if_${i.name}"
            val known = state.contains(k)
            val wasUp = state.getBoolean(k, i.up)
            state.edit().putBoolean(k, i.up).apply()
            if (!known) continue
            if (wasUp && !i.up) {
                Notifier.notify(ctx, notifyId(fw, "if" + i.name), "${fw.name} : ${i.name} est tombé", "L'interface ${i.name} n'a plus de lien.")
            } else if (!wasUp && i.up) {
                Notifier.notify(ctx, notifyId(fw, "if" + i.name), "${fw.name} : ${i.name} rétabli", "L'interface ${i.name} est de nouveau active.")
            }
        }
    }

    companion object {
        private const val WORK = "sophos_alerts"

        /** Active ou coupe la tâche selon qu'au moins un pare-feu a les alertes activées. */
        fun schedule(context: Context, anyEnabled: Boolean) {
            val wm = WorkManager.getInstance(context)
            if (!anyEnabled) {
                wm.cancelUniqueWork(WORK)
                return
            }
            val req = PeriodicWorkRequestBuilder<AlertWorker>(15, TimeUnit.MINUTES)
                .setConstraints(Constraints.Builder().setRequiredNetworkType(NetworkType.CONNECTED).build())
                .build()
            wm.enqueueUniquePeriodicWork(WORK, ExistingPeriodicWorkPolicy.KEEP, req)
        }
    }
}
