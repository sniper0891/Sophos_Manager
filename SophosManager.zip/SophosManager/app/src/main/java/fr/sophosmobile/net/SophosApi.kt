package fr.sophosmobile.net

import fr.sophosmobile.net.Xml.esc
import org.w3c.dom.Element

data class FwRule(
    val name: String,
    val enabled: Boolean,
    val action: String?,
    val policyType: String?,
    val description: String?,
    val sources: List<String>,
    val destinations: List<String>,
    internal val el: Element,
)

data class NatRule(
    val name: String,
    val enabled: Boolean,
    val summary: String,
    internal val el: Element,
)

data class Lease(val host: String, val mac: String, val ip: String)

data class DhcpServer(
    val name: String,
    val iface: String?,
    val ranges: List<String>,
    val leases: List<Lease>,
    internal val el: Element,
)

enum class BlockKind { Ip, Site, Device }

data class Blocked(val kind: BlockKind, val value: String, val hostName: String)

class SophosApi(private val c: SophosClient) {

    // ---------- Primitives ----------

    /** Tous les objets d'un type. Les réponses « aucun enregistrement » sont ignorées. */
    fun getAll(tag: String): List<Element> =
        c.call("<Get><$tag/></Get>").children(tag).filter { it.child("Name") != null }

    private fun checkResult(root: Element) {
        for (e in root.children()) {
            if (e.nodeName == "Login") continue
            val st = e.children("Status").firstOrNull { it.hasAttribute("code") } ?: continue
            val code = st.getAttribute("code")
            if (code != "200" && code != "202") {
                throw SophosException("Refusé par le pare-feu ($code) : ${st.textContent.trim()}", SophosException.Kind.Api)
            }
        }
    }

    fun add(xml: String) = checkResult(c.call("<Set operation=\"add\">$xml</Set>"))
    fun update(xml: String) = checkResult(c.call("<Set operation=\"update\">$xml</Set>"))
    fun remove(tag: String, name: String) =
        checkResult(c.call("<Remove><$tag><Name>${esc(name)}</Name></$tag></Remove>"))

    /** Copie d'un objet lu, nettoyée pour être renvoyée en mise à jour. */
    private fun editable(e: Element): Element {
        val copy = e.cloneNode(true) as Element
        copy.removeAttribute("transactionid")
        copy.children("Status").filter { it.hasAttribute("code") }.forEach { copy.removeChild(it) }
        return copy
    }

    /** Vérifie la connexion (utilisé par « Tester » et les alertes). */
    fun ping(): String? {
        val root = c.call("<Get><FirewallRule/></Get>")
        return root.getAttribute("APIVersion").ifEmpty { null }
    }

    // ---------- Règles de pare-feu ----------

    fun rules(): List<FwRule> = getAll("FirewallRule").map { e ->
        FwRule(
            name = e.text("Name") ?: "?",
            enabled = e.text("Status").equals("Enable", true),
            action = e.find("Action")?.textContent?.trim(),
            policyType = e.text("PolicyType"),
            description = e.text("Description"),
            sources = e.listUnder("SourceNetworks"),
            destinations = e.listUnder("DestinationNetworks"),
            el = e,
        )
    }

    fun setRuleEnabled(rule: FwRule, enabled: Boolean) {
        val e = editable(rule.el)
        e.setChildText("Status", if (enabled) "Enable" else "Disable")
        update(Xml.serialize(e))
    }

    // ---------- NAT ----------

    fun natRules(): List<NatRule> = getAll("NATRule").map { e ->
        val origDst = e.listUnder("OriginalDestinationNetworks").ifEmpty { listOf("Any") }.joinToString(", ")
        val origSvc = e.listUnder("OriginalServices").ifEmpty { listOf("Any") }.joinToString(", ")
        val trDst = e.text("TranslatedDestination") ?: "Original"
        val trSvc = e.text("TranslatedService") ?: "Original"
        val trSrc = e.text("TranslatedSource")
        val summary = buildString {
            append("$origDst · $origSvc → $trDst")
            if (trSvc != "Original") append(" · $trSvc")
            if (trSrc != null && trSrc != "Original") append("\nSource traduite : $trSrc")
        }
        NatRule(e.text("Name") ?: "?", e.text("Status").equals("Enable", true), summary, e)
    }

    fun setNatEnabled(rule: NatRule, enabled: Boolean) {
        val e = editable(rule.el)
        e.setChildText("Status", if (enabled) "Enable" else "Disable")
        update(Xml.serialize(e))
    }

    // ---------- DHCP ----------

    fun dhcpServers(): List<DhcpServer> = getAll("DHCPServer").map { e ->
        DhcpServer(
            name = e.text("Name") ?: "?",
            iface = e.text("Interface"),
            ranges = e.listUnder("IPLease"),
            leases = e.child("StaticLease")?.children("Lease")?.map {
                Lease(it.text("HostName") ?: "", it.text("MACAddress") ?: "", it.text("IPAddress") ?: "")
            } ?: emptyList(),
            el = e,
        )
    }

    fun addLease(server: DhcpServer, lease: Lease) {
        val e = editable(server.el)
        val sl = e.child("StaticLease") ?: e.ownerDocument.createElement("StaticLease").also { node ->
            val after = e.child("ConflictDetection") ?: e.child("IPLease")
            if (after?.nextSibling != null) e.insertBefore(node, after.nextSibling) else e.appendChild(node)
        }
        val l = e.ownerDocument.createElement("Lease")
        l.appendText("HostName", lease.host)
        l.appendText("MACAddress", lease.mac)
        l.appendText("IPAddress", lease.ip)
        sl.appendChild(l)
        update(Xml.serialize(e))
    }

    fun removeLease(server: DhcpServer, lease: Lease) {
        val e = editable(server.el)
        val sl = e.child("StaticLease") ?: return
        sl.children("Lease").filter { it.text("MACAddress").equals(lease.mac, true) }.forEach { sl.removeChild(it) }
        update(Xml.serialize(e))
    }

    // ---------- Blocage rapide ----------

    fun blocked(): List<Blocked> {
        val out = ArrayList<Blocked>()
        for (h in getAll("IPHost")) {
            val n = h.text("Name") ?: continue
            val ip = h.text("IPAddress") ?: n.substringAfterLast('-')
            when {
                n.startsWith(P_IP) -> out += Blocked(BlockKind.Ip, ip, n)
                n.startsWith(P_DEV) -> out += Blocked(BlockKind.Device, ip, n)
            }
        }
        for (h in getAll("FQDNHost")) {
            val n = h.text("Name") ?: continue
            if (n.startsWith(P_SITE)) out += Blocked(BlockKind.Site, h.text("FQDN") ?: n.removePrefix(P_SITE), n)
        }
        return out
    }

    fun block(kind: BlockKind, raw: String) {
        val value = raw.trim().lowercase()
        when (kind) {
            BlockKind.Ip, BlockKind.Device -> require(IPV4.matches(value)) { "Adresse IPv4 invalide : $raw" }
            BlockKind.Site -> require(DOMAIN.matches(value)) { "Nom de domaine invalide : $raw" }
        }
        ensureSetup()
        when (kind) {
            BlockKind.Ip -> add(ipHost(P_IP + value, value, G_IP))
            BlockKind.Device -> add(ipHost(P_DEV + value, value, G_DEV))
            BlockKind.Site -> add(
                "<FQDNHost><Name>${esc(P_SITE + value)}</Name><FQDN>${esc(value)}</FQDN>" +
                    "<FQDNHostGroupList><FQDNHostGroup>$G_SITE</FQDNHostGroup></FQDNHostGroupList></FQDNHost>",
            )
        }
    }

    fun unblock(b: Blocked) {
        val tag = if (b.kind == BlockKind.Site) "FQDNHost" else "IPHost"
        val groupTag = if (b.kind == BlockKind.Site) "FQDNHostGroup" else "IPHostGroup"
        val groupName = when (b.kind) { BlockKind.Ip -> G_IP; BlockKind.Device -> G_DEV; BlockKind.Site -> G_SITE }
        try {
            remove(tag, b.hostName)
            return
        } catch (e: SophosException) {
            if (e.kind != SophosException.Kind.Api) throw e
        }
        // L'objet est encore référencé par le groupe : on l'en retire, puis on le supprime.
        getAll(groupTag).firstOrNull { it.text("Name") == groupName }?.let { g ->
            val ed = editable(g)
            removeLeavesWithText(ed, b.hostName)
            update(Xml.serialize(ed))
        }
        remove(tag, b.hostName)
    }

    private fun removeLeavesWithText(e: Element, text: String) {
        for (c in e.children()) {
            if (c.children().isEmpty()) {
                if (c.textContent.trim() == text) e.removeChild(c)
            } else removeLeavesWithText(c, text)
        }
    }

    private fun ipHost(name: String, ip: String, group: String) =
        "<IPHost><Name>${esc(name)}</Name><IPFamily>IPv4</IPFamily><HostType>IP</HostType>" +
            "<IPAddress>$ip</IPAddress><HostGroupList><HostGroup>$group</HostGroup></HostGroupList></IPHost>"

    /** Crée, la première fois, les groupes et les règles de blocage en tête de liste. */
    fun ensureSetup() {
        val ipGroups = getAll("IPHostGroup").mapNotNull { it.text("Name") }.toSet()
        for (g in listOf(G_IP, G_DEV)) if (g !in ipGroups) {
            add("<IPHostGroup><Name>$g</Name><Description>$DESC</Description><IPFamily>IPv4</IPFamily></IPHostGroup>")
        }
        val fqdnGroups = getAll("FQDNHostGroup").mapNotNull { it.text("Name") }.toSet()
        if (G_SITE !in fqdnGroups) {
            add("<FQDNHostGroup><Name>$G_SITE</Name><Description>$DESC</Description></FQDNHostGroup>")
        }
        val rules = getAll("FirewallRule").mapNotNull { it.text("Name") }.toSet()
        if (R_OUT !in rules) add(dropRule(R_OUT, dst = listOf(G_IP, G_SITE)))
        if (R_IN !in rules) add(dropRule(R_IN, src = listOf(G_IP)))
        if (R_DEV !in rules) add(dropRule(R_DEV, src = listOf(G_DEV)))
    }

    private fun dropRule(name: String, src: List<String> = emptyList(), dst: List<String> = emptyList()) = buildString {
        append("<FirewallRule><Name>$name</Name><Description>$DESC</Description>")
        append("<IPFamily>IPv4</IPFamily><Status>Enable</Status><Position>Top</Position>")
        append("<PolicyType>Network</PolicyType><NetworkPolicy>")
        append("<Action>Drop</Action><LogTraffic>Enable</LogTraffic><SkipLocalDestined>Disable</SkipLocalDestined>")
        append("<Schedule>All The Time</Schedule>")
        if (src.isNotEmpty()) append("<SourceNetworks>${src.joinToString("") { "<Network>$it</Network>" }}</SourceNetworks>")
        if (dst.isNotEmpty()) append("<DestinationNetworks>${dst.joinToString("") { "<Network>$it</Network>" }}</DestinationNetworks>")
        append("</NetworkPolicy></FirewallRule>")
    }

    companion object {
        const val DESC = "Cree par Sophos Manager (appli Android)"
        const val G_IP = "APP-Bloques-IP"
        const val G_DEV = "APP-Bloques-Appareils"
        const val G_SITE = "APP-Bloques-Sites"
        const val R_OUT = "APP Blocage sortant"
        const val R_IN = "APP Blocage entrant"
        const val R_DEV = "APP Blocage appareils"
        const val P_IP = "APP-IP-"
        const val P_DEV = "APP-DEV-"
        const val P_SITE = "APP-SITE-"
        val BLOCK_RULES = setOf(R_OUT, R_IN, R_DEV)

        val IPV4 = Regex("""^((25[0-5]|2[0-4]\d|1\d\d|[1-9]?\d)\.){3}(25[0-5]|2[0-4]\d|1\d\d|[1-9]?\d)$""")
        val DOMAIN = Regex("""^(\*\.)?([a-z0-9]([a-z0-9-]{0,61}[a-z0-9])?\.)+[a-z]{2,}$""")
        val MAC = Regex("""^([0-9A-Fa-f]{2}[:-]){5}[0-9A-Fa-f]{2}$""")
    }
}
