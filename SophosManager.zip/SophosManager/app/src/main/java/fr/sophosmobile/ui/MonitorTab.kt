package fr.sophosmobile.ui

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.Card
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.unit.dp
import fr.sophosmobile.data.Firewall
import fr.sophosmobile.net.IfStat
import fr.sophosmobile.net.Monitor
import fr.sophosmobile.net.Snapshot
import fr.sophosmobile.net.formatBps
import fr.sophosmobile.net.formatUptime
import fr.sophosmobile.net.friendly
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.isActive
import kotlinx.coroutines.withContext

@Composable
fun MonitorTab(fw: Firewall) {
    if (fw.snmpCommunity.isBlank()) {
        Column(Modifier.padding(16.dp)) {
            ErrorBox(
                "La surveillance utilise SNMP. Active-le sur le pare-feu (Administration > SNMP : agent activé, " +
                    "communauté v2c avec l'IP du téléphone), puis saisis la communauté dans la fiche du pare-feu.",
            )
        }
        return
    }
    val monitor = remember(fw.host, fw.snmpCommunity) { Monitor(fw.host, fw.snmpCommunity, fw.snmpPort) }
    var snap by remember { mutableStateOf<Snapshot?>(null) }
    var error by remember { mutableStateOf<String?>(null) }
    val cpuHist = remember { mutableStateListOf<Int>() }

    LaunchedEffect(monitor) {
        while (isActive) {
            try {
                val s = withContext(Dispatchers.IO) { monitor.sample() }
                snap = s
                error = null
                s.cpu?.let { cpuHist += it; if (cpuHist.size > 60) cpuHist.removeAt(0) }
            } catch (e: Exception) {
                error = e.friendly()
            }
            delay(5_000)
        }
    }

    val s = snap
    LazyColumn(
        Modifier.fillMaxSize(),
        contentPadding = PaddingValues(16.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp),
    ) {
        error?.let { item { ErrorBox(it) } }
        if (s == null && error == null) item { CenteredLoading() }
        if (s != null) {
            item {
                Card(Modifier.fillMaxWidth()) {
                    Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                        Text(s.sysName ?: fw.name, style = MaterialTheme.typography.titleMedium)
                        s.descr?.let { InfoText(it) }
                        Text("En fonctionnement depuis ${formatUptime(s.uptimeSec)}")
                        Gauge("CPU", s.cpu, null)
                        if (cpuHist.size > 1) Sparkline(cpuHist)
                        Gauge("Mémoire", s.ramPct, s.ramUsedMb?.let { u -> s.ramTotalMb?.let { t -> "$u / $t Mo" } })
                        Gauge("Disque", s.diskPct, null)
                    }
                }
            }
            item { Text("Interfaces", style = MaterialTheme.typography.titleMedium) }
            if (s.ifs.isEmpty()) item { EmptyText("Aucune interface remontée par SNMP.") }
            items(s.ifs, key = { it.index }) { InterfaceRow(it) }
            item { InfoText("Actualisation toutes les 5 secondes. Les débits apparaissent à partir de la 2e mesure.") }
        }
    }
}

@Composable
private fun Gauge(label: String, pct: Int?, detail: String?) {
    Column {
        Row {
            Text(label, Modifier.weight(1f))
            Text(if (pct == null) "—" else "$pct %" + (detail?.let { " · $it" } ?: ""))
        }
        Spacer(Modifier.height(4.dp))
        val color = when {
            pct == null -> Grey
            pct >= 90 -> Red
            pct >= 75 -> Orange
            else -> Green
        }
        LinearProgressIndicator(
            progress = { (pct ?: 0) / 100f },
            color = color,
            modifier = Modifier.fillMaxWidth().height(8.dp),
        )
    }
}

@Composable
private fun Sparkline(values: List<Int>) {
    val color = MaterialTheme.colorScheme.primary
    Canvas(Modifier.fillMaxWidth().height(48.dp)) {
        val stepX = size.width / (values.size - 1).coerceAtLeast(1)
        val path = Path()
        values.forEachIndexed { i, v ->
            val p = Offset(i * stepX, size.height * (1 - v / 100f))
            if (i == 0) path.moveTo(p.x, p.y) else path.lineTo(p.x, p.y)
        }
        drawPath(path, color, style = Stroke(width = 2.dp.toPx()))
    }
}

@Composable
private fun InterfaceRow(i: IfStat) {
    Card(Modifier.fillMaxWidth()) {
        Row(Modifier.padding(12.dp), verticalAlignment = Alignment.CenterVertically) {
            Dot(if (i.up) Green else Grey)
            Spacer(Modifier.width(12.dp))
            Text(i.name, Modifier.weight(1f), style = MaterialTheme.typography.titleSmall)
            if (i.up) {
                Column(horizontalAlignment = Alignment.End) {
                    Text("↓ ${formatBps(i.inBps)}", style = MaterialTheme.typography.bodySmall)
                    Text("↑ ${formatBps(i.outBps)}", style = MaterialTheme.typography.bodySmall)
                }
            } else {
                Text("pas de lien", style = MaterialTheme.typography.bodySmall)
            }
        }
    }
}
