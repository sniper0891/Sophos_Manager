package fr.sophosmobile.ui

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material3.Card
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.SnackbarHostState
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import fr.sophosmobile.net.FwRule
import fr.sophosmobile.net.SophosApi

@Composable
fun ListHeader(text: String, loading: Boolean, onRefresh: () -> Unit) {
    Row(verticalAlignment = Alignment.CenterVertically) {
        Text(text, Modifier.weight(1f), style = MaterialTheme.typography.titleSmall)
        IconButton(onClick = onRefresh, enabled = !loading) { Icon(Icons.Default.Refresh, contentDescription = "Actualiser") }
    }
}

@Composable
fun RulesTab(api: SophosApi, snackbar: SnackbarHostState) {
    val loader = rememberLoader(api) { api.rules() }
    val scope = rememberCoroutineScope()
    var busy by remember { mutableStateOf<String?>(null) }
    var confirmOff by remember { mutableStateOf<FwRule?>(null) }

    fun toggle(r: FwRule, on: Boolean) {
        busy = r.name
        scope.runAction(snackbar, "${r.name} ${if (on) "activée" else "désactivée"}", after = { busy = null; loader.reload() }) {
            api.setRuleEnabled(r, on)
        }
    }

    LazyColumn(
        Modifier.fillMaxSize(),
        contentPadding = PaddingValues(16.dp),
        verticalArrangement = Arrangement.spacedBy(8.dp),
    ) {
        val rules = loader.data
        item { ListHeader(rules?.let { "${it.size} règles, dans l'ordre d'évaluation" } ?: "Règles", loader.loading) { loader.reload() } }
        loader.error?.let { item { ErrorBox(it) { loader.reload() } } }
        if (rules == null && loader.loading) item { CenteredLoading() }
        if (rules != null && rules.isEmpty()) item { EmptyText("Aucune règle.") }
        items(rules ?: emptyList(), key = { it.name }) { r ->
            Card(Modifier.fillMaxWidth()) {
                Row(Modifier.padding(start = 16.dp, end = 8.dp, top = 10.dp, bottom = 10.dp), verticalAlignment = Alignment.CenterVertically) {
                    Column(Modifier.weight(1f)) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            val a = r.action ?: "?"
                            Pill(a, if (a.equals("Accept", true)) Green else Red)
                            Spacer(Modifier.width(8.dp))
                            Text(r.name, style = MaterialTheme.typography.titleSmall)
                        }
                        val src = r.sources.ifEmpty { listOf("Any") }.joinToString(", ")
                        val dst = r.destinations.ifEmpty { listOf("Any") }.joinToString(", ")
                        InfoText("$src → $dst")
                        if (r.name in SophosApi.BLOCK_RULES) InfoText("Règle créée par l'appli pour le blocage rapide")
                    }
                    Switch(
                        checked = r.enabled,
                        enabled = busy == null,
                        onCheckedChange = { on ->
                            if (on) {
                                toggle(r, true)
                            } else {
                                confirmOff = r
                            }
                        },
                    )
                }
            }
        }
    }

    confirmOff?.let { r ->
        ConfirmDialog(
            title = "Désactiver « ${r.name} » ?",
            text = "Le trafic concerné par cette règle ne sera plus traité par elle. Si c'est la règle qui te donne accès au pare-feu, tu pourrais perdre la main.",
            confirm = "Désactiver",
            onConfirm = { toggle(r, false) },
            onDismiss = { confirmOff = null },
        )
    }
}
