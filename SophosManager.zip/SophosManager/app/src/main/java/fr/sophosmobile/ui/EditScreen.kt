package fr.sophosmobile.ui

import android.Manifest
import android.os.Build
import androidx.activity.compose.BackHandler
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Slider
import androidx.compose.material3.SnackbarHost
import androidx.compose.material3.SnackbarHostState
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.TopAppBar
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.text.input.VisualTransformation
import androidx.compose.ui.unit.dp
import fr.sophosmobile.data.Firewall
import fr.sophosmobile.net.Monitor
import fr.sophosmobile.net.SophosApi
import fr.sophosmobile.net.SophosClient
import fr.sophosmobile.net.friendly
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.util.UUID

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun EditScreen(vm: AppViewModel, id: String?) {
    val existing = id?.let { vm.find(it) }
    var name by rememberSaveable { mutableStateOf(existing?.name ?: "XGS 107") }
    var host by rememberSaveable { mutableStateOf(existing?.host ?: "") }
    var user by rememberSaveable { mutableStateOf(existing?.username ?: "") }
    var pass by rememberSaveable { mutableStateOf(existing?.password ?: "") }
    var showPass by rememberSaveable { mutableStateOf(false) }
    var community by rememberSaveable { mutableStateOf(existing?.snmpCommunity ?: "") }
    var fingerprint by rememberSaveable { mutableStateOf(existing?.certFingerprint) }
    var alerts by rememberSaveable { mutableStateOf(existing?.alertsEnabled ?: false) }
    var cpuMax by rememberSaveable { mutableStateOf((existing?.cpuThreshold ?: 90).toFloat()) }
    var ramMax by rememberSaveable { mutableStateOf((existing?.ramThreshold ?: 90).toFloat()) }
    var testing by remember { mutableStateOf(false) }
    val snackbar = remember { SnackbarHostState() }
    val scope = rememberCoroutineScope()

    val permission = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { granted ->
        if (!granted) scope.launch { snackbar.showSnackbar("Sans autorisation, les alertes ne pourront pas s'afficher.") }
    }

    fun draft(): Firewall {
        val h = host.trim()
        val sameHost = existing?.host?.trim() == h
        return Firewall(
            id = existing?.id ?: UUID.randomUUID().toString(),
            name = name.trim().ifBlank { SophosClient.hostOnly(h) },
            host = h,
            username = user.trim(),
            password = pass,
            certFingerprint = if (sameHost) fingerprint else null,
            snmpCommunity = community.trim(),
            alertsEnabled = alerts,
            cpuThreshold = cpuMax.toInt(),
            ramThreshold = ramMax.toInt(),
        )
    }

    val valid = host.isNotBlank() && user.isNotBlank() && pass.isNotEmpty()
    BackHandler { vm.screen = Screen.Home }

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text(if (existing == null) "Nouveau pare-feu" else "Modifier") },
                navigationIcon = {
                    IconButton(onClick = { vm.screen = Screen.Home }) {
                        Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "Retour")
                    }
                },
                actions = {
                    TextButton(enabled = valid, onClick = { vm.save(draft()); vm.screen = Screen.Home }) { Text("Enregistrer") }
                },
            )
        },
        snackbarHost = { SnackbarHost(snackbar) },
    ) { pad ->
        Column(
            Modifier.padding(pad).fillMaxSize().verticalScroll(rememberScrollState()).padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp),
        ) {
            OutlinedTextField(name, { name = it }, label = { Text("Nom") }, singleLine = true, modifier = Modifier.fillMaxWidth())
            OutlinedTextField(
                host, { host = it },
                label = { Text("Adresse du pare-feu") },
                placeholder = { Text("172.16.16.16") },
                supportingText = { Text("Adresse côté LAN. Port 4444 par défaut, ajoute :port si tu l'as changé.") },
                singleLine = true,
                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Uri),
                modifier = Modifier.fillMaxWidth(),
            )
            OutlinedTextField(user, { user = it }, label = { Text("Utilisateur admin") }, singleLine = true, modifier = Modifier.fillMaxWidth())
            OutlinedTextField(
                pass, { pass = it },
                label = { Text("Mot de passe") },
                singleLine = true,
                visualTransformation = if (showPass) VisualTransformation.None else PasswordVisualTransformation(),
                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Password),
                trailingIcon = { TextButton(onClick = { showPass = !showPass }) { Text(if (showPass) "Masquer" else "Afficher") } },
                modifier = Modifier.fillMaxWidth(),
            )
            InfoText("Conseil : crée un compte admin dédié à l'appli, avec un profil limité aux fonctions utilisées.")

            HorizontalDivider()
            Text("Surveillance (SNMP)", style = MaterialTheme.typography.titleMedium)
            OutlinedTextField(
                community, { community = it },
                label = { Text("Communauté SNMP v2c") },
                supportingText = { Text("Laisse vide pour désactiver la surveillance. À créer dans Administration > SNMP.") },
                singleLine = true,
                modifier = Modifier.fillMaxWidth(),
            )

            HorizontalDivider()
            Row(verticalAlignment = Alignment.CenterVertically) {
                Column(Modifier.weight(1f)) {
                    Text("Alertes en arrière-plan", style = MaterialTheme.typography.titleMedium)
                    InfoText("Vérification toutes les 15 min, uniquement quand le téléphone est sur le réseau local.")
                }
                Switch(checked = alerts, onCheckedChange = {
                    alerts = it
                    if (it && Build.VERSION.SDK_INT >= 33) permission.launch(Manifest.permission.POST_NOTIFICATIONS)
                })
            }
            if (alerts) {
                Text("Seuil CPU : ${cpuMax.toInt()} %")
                Slider(cpuMax, { cpuMax = it }, valueRange = 50f..100f, steps = 9)
                Text("Seuil mémoire : ${ramMax.toInt()} %")
                Slider(ramMax, { ramMax = it }, valueRange = 50f..100f, steps = 9)
                if (community.isBlank()) InfoText("Sans SNMP, seule la perte de connexion au pare-feu sera signalée.")
            }

            HorizontalDivider()
            OutlinedButton(
                enabled = valid && !testing,
                modifier = Modifier.fillMaxWidth(),
                onClick = {
                    testing = true
                    scope.launch {
                        val d = draft()
                        val msg = withContext(Dispatchers.IO) {
                            val api = try {
                                val v = SophosApi(SophosClient(d.host, d.username, d.password, d.certFingerprint, onFirstFingerprint = { fp -> fingerprint = fp })).ping()
                                "API OK" + (v?.let { " (version $it)" } ?: "")
                            } catch (e: Exception) {
                                "API : ${e.friendly()}"
                            }
                            val snmp = if (d.snmpCommunity.isBlank()) "" else try {
                                val s = Monitor(d.host, d.snmpCommunity).sample()
                                "\nSNMP OK" + (s.sysName?.let { " ($it)" } ?: "")
                            } catch (e: Exception) {
                                "\nSNMP : ${e.friendly()}"
                            }
                            api + snmp
                        }
                        testing = false
                        snackbar.showSnackbar(msg)
                    }
                },
            ) { Text(if (testing) "Test en cours…" else "Tester la connexion") }

            if (fingerprint != null) {
                InfoText("Certificat mémorisé :\n$fingerprint")
                TextButton(onClick = { fingerprint = null }) { Text("Oublier le certificat (après un renouvellement)") }
            }
        }
    }
}
