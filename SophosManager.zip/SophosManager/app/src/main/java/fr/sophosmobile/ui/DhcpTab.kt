package fr.sophosmobile.ui

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Card
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.SnackbarHostState
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import fr.sophosmobile.net.DhcpServer
import fr.sophosmobile.net.Lease
import fr.sophosmobile.net.SophosApi

@Composable
fun DhcpTab(api: SophosApi, snackbar: SnackbarHostState) {
    val loader = rememberLoader(api) { api.dhcpServers() }
    val scope = rememberCoroutineScope()
    var addTo by remember { mutableStateOf<DhcpServer?>(null) }
    var toRemove by remember { mutableStateOf<Pair<DhcpServer, Lease>?>(null) }

    LazyColumn(
        Modifier.fillMaxSize(),
        contentPadding = PaddingValues(16.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp),
    ) {
        val servers = loader.data
        item { ListHeader("Serveurs DHCP et réservations", loader.loading) { loader.reload() } }
        loader.error?.let { item { ErrorBox(it) { loader.reload() } } }
        if (servers == null && loader.loading) item { CenteredLoading() }
        if (servers != null && servers.isEmpty()) item { EmptyText("Aucun serveur DHCP configuré sur le pare-feu.") }
        items(servers ?: emptyList(), key = { it.name }) { s ->
            Card(Modifier.fillMaxWidth()) {
                Column(Modifier.padding(16.dp)) {
                    Text(s.name, style = MaterialTheme.typography.titleMedium)
                    InfoText(listOfNotNull(s.iface, s.ranges.joinToString().ifEmpty { null }).joinToString(" · "))
                    HorizontalDivider(Modifier.padding(vertical = 8.dp))
                    if (s.leases.isEmpty()) InfoText("Aucune réservation.")
                    s.leases.forEach { l ->
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Column(Modifier.weight(1f)) {
                                Text("${l.ip}  ·  ${l.host}", style = MaterialTheme.typography.bodyMedium)
                                InfoText(l.mac)
                            }
                            IconButton(onClick = { toRemove = s to l }) { Icon(Icons.Default.Delete, contentDescription = "Supprimer") }
                        }
                    }
                    OutlinedButton(onClick = { addTo = s }, modifier = Modifier.fillMaxWidth().padding(top = 8.dp)) {
                        Text("Ajouter une réservation")
                    }
                }
            }
        }
    }

    addTo?.let { s ->
        LeaseDialog(
            onDismiss = { addTo = null },
            onSave = { l ->
                addTo = null
                scope.runAction(snackbar, "Réservation ${l.ip} ajoutée", after = { loader.reload() }) { api.addLease(s, l) }
            },
        )
    }

    toRemove?.let { (s, l) ->
        ConfirmDialog(
            title = "Supprimer la réservation ${l.ip} ?",
            text = "${l.host} (${l.mac}) recevra ensuite une adresse dynamique.",
            confirm = "Supprimer",
            onConfirm = { scope.runAction(snackbar, "Réservation supprimée", after = { loader.reload() }) { api.removeLease(s, l) } },
            onDismiss = { toRemove = null },
        )
    }
}

@Composable
private fun LeaseDialog(onDismiss: () -> Unit, onSave: (Lease) -> Unit) {
    var host by remember { mutableStateOf("") }
    var mac by remember { mutableStateOf("") }
    var ip by remember { mutableStateOf("") }
    val macOk = SophosApi.MAC.matches(mac.trim())
    val ipOk = SophosApi.IPV4.matches(ip.trim())
    val hostOk = host.isNotBlank() && host.none { it.isWhitespace() }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("Nouvelle réservation") },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                OutlinedTextField(host, { host = it }, label = { Text("Nom (sans espace)") }, singleLine = true)
                OutlinedTextField(
                    mac, { mac = it }, label = { Text("Adresse MAC") }, singleLine = true,
                    placeholder = { Text("AA:BB:CC:DD:EE:FF") },
                    isError = mac.isNotBlank() && !macOk,
                )
                OutlinedTextField(
                    ip, { ip = it }, label = { Text("Adresse IP") }, singleLine = true,
                    isError = ip.isNotBlank() && !ipOk,
                )
                InfoText("L'IP doit être dans le sous-réseau du serveur DHCP, idéalement hors de la plage dynamique.")
            }
        },
        confirmButton = {
            TextButton(enabled = macOk && ipOk && hostOk, onClick = {
                onSave(Lease(host.trim(), mac.trim().replace('-', ':').uppercase(), ip.trim()))
            }) { Text("Ajouter") }
        },
        dismissButton = { TextButton(onClick = onDismiss) { Text("Annuler") } },
    )
}
