package fr.sophosmobile.ui

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Card
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.SnackbarHostState
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateMapOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import fr.sophosmobile.data.Firewall
import fr.sophosmobile.net.ArpEntry
import fr.sophosmobile.net.DhcpServer
import fr.sophosmobile.net.Diag
import fr.sophosmobile.net.Lease
import fr.sophosmobile.net.SfosSnmp
import fr.sophosmobile.net.SophosApi
import fr.sophosmobile.net.SophosClient
import fr.sophosmobile.net.friendly
import fr.sophosmobile.net.ipToLong
import fr.sophosmobile.net.normalizeMac
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.FilterChip

private enum class DevKind { Reserved, Dynamic, Fixed }

private data class ActiveDevice(val ip: String, val mac: String, val name: String?, val kind: DevKind)

private data class DhcpData(
    val servers: List<DhcpServer>,
    val arp: List<ArpEntry>,
    /** Appareils actifs par serveur (clé = nom du serveur). Null si SNMP indisponible. */
    val devices: Map<String, List<ActiveDevice>>?,
    val snmpError: String?,
)

@Composable
fun DhcpTab(fw: Firewall, api: SophosApi, snackbar: SnackbarHostState) {
    val loader = rememberLoader(api) {
        val servers = api.dhcpServers()
        var err: String? = null
        var arp: List<ArpEntry> = emptyList()
        val devices = if (fw.snmpCommunity.isBlank()) null else try {
            arp = SfosSnmp(fw.host, fw.snmpCommunity, fw.snmpPort).arp()
            val names = Diag.ptrAll(SophosClient.hostOnly(fw.host), arp.map { it.ip })
            servers.associate { s ->
                val reservedMacs = s.leases.associateBy { it.mac.uppercase() }
                s.name to arp.filter { s.inSubnet(it.ip) }.map { e ->
                    val res = reservedMacs[e.mac.uppercase()]
                    val kind = when {
                        res != null -> DevKind.Reserved
                        s.inRange(e.ip) -> DevKind.Dynamic
                        else -> DevKind.Fixed
                    }
                    ActiveDevice(e.ip, e.mac, res?.host ?: names[e.ip], kind)
                }.sortedBy { ipToLong(it.ip) ?: 0L }
            }
        } catch (e: Exception) {
            err = e.friendly()
            null
        }
        DhcpData(servers, arp, devices, err)
    }
    val scope = rememberCoroutineScope()
    var addTo by remember { mutableStateOf<Pair<DhcpServer, Lease?>?>(null) }
    var toRemove by remember { mutableStateOf<Pair<DhcpServer, Lease>?>(null) }
    val expanded = remember { mutableStateMapOf<String, Boolean>() }

    LazyColumn(
        Modifier.fillMaxSize(),
        contentPadding = PaddingValues(16.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp),
    ) {
        val d = loader.data
        item { ListHeader("Serveurs DHCP, réservations et baux", loader.loading) { loader.reload() } }
        loader.error?.let { item { ErrorBox(it) { loader.reload() } } }
        if (d == null && loader.loading) item { CenteredLoading() }
        if (d != null && d.servers.isEmpty()) item { EmptyText("Aucun serveur DHCP configuré sur le pare-feu.") }
        if (d != null && fw.snmpCommunity.isBlank()) {
            item { InfoText("Renseigne la communauté SNMP dans la fiche du pare-feu pour voir les appareils actifs et les baux dynamiques.") }
        }
        d?.snmpError?.let { item { ErrorBox("Appareils actifs indisponibles : $it") } }

        items(d?.servers ?: emptyList(), key = { it.name }) { s ->
            Card(Modifier.fillMaxWidth()) {
                Column(Modifier.padding(16.dp)) {
                    Text(s.name, style = MaterialTheme.typography.titleMedium)
                    InfoText(listOfNotNull(s.iface, s.ranges.joinToString().ifEmpty { null }).joinToString(" · "))
                    HorizontalDivider(Modifier.padding(vertical = 8.dp))

                    Text("Réservations (${s.leases.size})", style = MaterialTheme.typography.titleSmall)
                    if (s.leases.isEmpty()) InfoText("Aucune réservation.")
                    s.leases.forEach { l ->
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Column(Modifier.weight(1f)) {
                                Text("${l.ip}  ·  ${l.host}", style = MaterialTheme.typography.bodyMedium)
                                InfoText(l.mac)
                            }
                            IconButton(onClick = { toRemove = s to l }) { Icon(Icons.Default.Delete, contentDescription = "Supprimer") }
                        }
                    }
                    OutlinedButton(onClick = { addTo = s to null }, modifier = Modifier.fillMaxWidth().padding(top = 8.dp)) {
                        Text("Ajouter une réservation")
                    }

                    val devs = d?.devices?.get(s.name)
                    if (devs != null) {
                        HorizontalDivider(Modifier.padding(vertical = 8.dp))
                        val dyn = devs.count { it.kind == DevKind.Dynamic }
                        Text("Appareils actifs (${devs.size}, dont $dyn en bail dynamique)", style = MaterialTheme.typography.titleSmall)
                        if (devs.isEmpty()) InfoText("Aucun appareil vu récemment sur ce réseau.")
                        val showAll = expanded[s.name] == true
                        devs.take(if (showAll) devs.size else 15).forEach { dev ->
                            Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.padding(vertical = 2.dp)) {
                                Column(Modifier.weight(1f)) {
                                    Row(verticalAlignment = Alignment.CenterVertically) {
                                        Text(dev.ip, style = MaterialTheme.typography.bodyMedium)
                                        Spacer(Modifier.width(8.dp))
                                        when (dev.kind) {
                                            DevKind.Reserved -> Pill("Réservé", Green)
                                            DevKind.Dynamic -> Pill("Bail", BlueIn)
                                            DevKind.Fixed -> Pill("IP fixe", Grey)
                                        }
                                    }
                                    InfoText(listOfNotNull(dev.name, dev.mac).joinToString(" · "))
                                }
                                if (dev.kind != DevKind.Reserved) {
                                    TextButton(onClick = {
                                        val host = dev.name?.substringBefore('.')?.replace(Regex("[^A-Za-z0-9_-]"), "-") ?: ""
                                        addTo = s to Lease(host, dev.mac, dev.ip)
                                    }) { Text("Réserver") }
                                }
                            }
                        }
                        if (devs.size > 15) {
                            TextButton(onClick = { expanded[s.name] = !showAll }) {
                                Text(if (showAll) "Réduire" else "Tout afficher (${devs.size})")
                            }
                        }
                    }
                }
            }
        }
        if (d?.devices != null) {
            item {
                InfoText(
                    "Les appareils actifs viennent de la table ARP du pare-feu : ce sont ceux qui ont communiqué récemment. " +
                        "Bail = adresse dans la plage dynamique, IP fixe = hors plage et sans réservation. " +
                        "Sophos n'expose pas la table des baux complète (durée, expiration) par l'API.",
                )
            }
        }
    }

    addTo?.let { (s, initial) ->
        val d = loader.data
        val used = buildSet {
            d?.arp?.forEach { e -> ipToLong(e.ip)?.let { add(it) } }
            s.leases.forEach { l -> ipToLong(l.ip)?.let { add(it) } }
            ipToLong(SophosClient.hostOnly(fw.host))?.let { add(it) }
        }
        LeaseDialog(
            server = s,
            initial = initial,
            devices = d?.devices?.get(s.name)?.filter { it.kind != DevKind.Reserved } ?: emptyList(),
            freeIps = s.freeIps(used),
            onDismiss = { addTo = null },
            onSave = { l ->
                addTo = null
                scope.runAction(snackbar, "Réservation ${l.ip} ajoutée", after = { loader.reload() }) { api.addLease(s, l) }
            },
        )
    }

    toRemove?.let { (s, l) ->
        ConfirmDialog(
            title = "Supprimer la réservation ${l.ip} ?",
            text = "${l.host} (${l.mac}) recevra ensuite une adresse dynamique.",
            confirm = "Supprimer",
            onConfirm = { scope.runAction(snackbar, "Réservation supprimée", after = { loader.reload() }) { api.removeLease(s, l) } },
            onDismiss = { toRemove = null },
        )
    }
}

@Composable
private fun LeaseDialog(
    server: DhcpServer,
    initial: Lease?,
    devices: List<ActiveDevice>,
    freeIps: List<String>,
    onDismiss: () -> Unit,
    onSave: (Lease) -> Unit,
) {
    val currentInRange = initial != null && server.inRange(initial.ip)
    var host by remember { mutableStateOf(initial?.host ?: "") }
    var mac by remember { mutableStateOf(initial?.mac ?: "") }
    var ip by remember { mutableStateOf(if (currentInRange) freeIps.firstOrNull() ?: initial!!.ip else initial?.ip ?: (freeIps.firstOrNull() ?: "")) }

    val macNorm = normalizeMac(mac)
    val ipOk = SophosApi.IPV4.matches(ip.trim())
    val ipInSubnet = ipOk && server.inSubnet(ip.trim())
    val ipInRange = ipOk && server.inRange(ip.trim())
    val ipTaken = ipOk && server.leases.any { it.ip == ip.trim() }
    val hostClean = host.trim().replace(' ', '-')
    val hostOk = hostClean.isNotEmpty() && hostClean.all { it.isLetterOrDigit() || it == '-' || it == '_' || it == '.' }
    val canSave = macNorm != null && ipOk && ipInSubnet && !ipInRange && !ipTaken && hostOk

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text(if (initial != null) "Réserver cet appareil" else "Nouvelle réservation") },
        text = {
            Column(Modifier.verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                if (initial == null && devices.isNotEmpty()) {
                    SelectField(
                        "Choisir un appareil actif (facultatif)",
                        "Saisie manuelle",
                        devices.map { it.mac },
                        display = { m -> devices.first { it.mac == m }.let { d -> listOfNotNull(d.ip, d.name, d.mac).joinToString(" · ") } },
                    ) { m ->
                        val d = devices.first { it.mac == m }
                        mac = d.mac
                        if (host.isBlank()) host = d.name?.substringBefore('.')?.replace(Regex("[^A-Za-z0-9_-]"), "-") ?: ""
                    }
                }
                OutlinedTextField(
                    host, { host = it }, label = { Text("Nom") }, singleLine = true,
                    isError = host.isNotEmpty() && !hostOk,
                    supportingText = { if (host.isNotEmpty() && !hostOk) Text("Lettres, chiffres, - et _ uniquement") },
                    modifier = Modifier.fillMaxWidth(),
                )
                OutlinedTextField(
                    mac, { mac = it }, label = { Text("Adresse MAC") }, singleLine = true,
                    placeholder = { Text("AA:BB:CC:DD:EE:FF") },
                    isError = mac.isNotBlank() && macNorm == null,
                    supportingText = {
                        when {
                            mac.isBlank() -> Text("Obligatoire : c'est elle qui identifie l'appareil")
                            macNorm == null -> Text("12 caractères hexadécimaux attendus")
                            macNorm != mac.trim().uppercase() -> Text("Sera enregistrée : $macNorm")
                        }
                    },
                    modifier = Modifier.fillMaxWidth(),
                )
                OutlinedTextField(
                    ip, { ip = it }, label = { Text("Adresse IP réservée") }, singleLine = true,
                    isError = ip.isNotBlank() && !(ipOk && ipInSubnet && !ipInRange && !ipTaken),
                    supportingText = {
                        when {
                            ip.isBlank() -> {}
                            !ipOk -> Text("Adresse IPv4 invalide")
                            !ipInSubnet -> Text("Hors du sous-réseau de ce serveur DHCP")
                            ipInRange -> Text("Dans la plage dynamique (${server.ranges.joinToString()}) : Sophos refuse")
                            ipTaken -> Text("Déjà réservée")
                        }
                    },
                    modifier = Modifier.fillMaxWidth(),
                )
                if (freeIps.isNotEmpty()) {
                    InfoText("Adresses libres hors plage :")
                    Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                        freeIps.forEach { f -> FilterChip(selected = ip == f, onClick = { ip = f }, label = { Text(f) }) }
                    }
                }
                if (currentInRange) {
                    InfoText(
                        "L'appareil utilise actuellement ${initial!!.ip}, une adresse de la plage dynamique. " +
                            "Sophos n'accepte pas de réservation dans la plage : l'appareil prendra l'adresse choisie " +
                            "au renouvellement de son bail, ou tout de suite s'il se reconnecte.",
                    )
                }
            }
        },
        confirmButton = {
            TextButton(enabled = canSave, onClick = { onSave(Lease(hostClean, macNorm!!, ip.trim())) }) { Text("Réserver") }
        },
        dismissButton = { TextButton(onClick = onDismiss) { Text("Annuler") } },
    )
}
