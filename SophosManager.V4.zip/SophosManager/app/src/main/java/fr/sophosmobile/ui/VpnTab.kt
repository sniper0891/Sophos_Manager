package fr.sophosmobile.ui

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.Card
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.SnackbarHostState
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import fr.sophosmobile.data.Firewall
import fr.sophosmobile.net.IpsecConn
import fr.sophosmobile.net.SfosSnmp
import fr.sophosmobile.net.SophosApi
import fr.sophosmobile.net.Tunnel
import fr.sophosmobile.net.friendly
import fr.sophosmobile.net.ipsecAction
import fr.sophosmobile.net.ipsecConnections
import kotlinx.coroutines.delay

private data class VpnData(
    val conns: List<IpsecConn>,
    val apiError: String?,
    /** État en direct par nom de connexion (SNMP). */
    val tunnels: Map<String, Tunnel>,
    val liveUsers: Long?,
    val sslPolicies: List<String>,
    val snmpError: String?,
)

@Composable
fun VpnTab(fw: Firewall, api: SophosApi, snackbar: SnackbarHostState) {
    val loader = rememberLoader(api) {
        var apiErr: String? = null
        val conns = try { api.ipsecConnections() } catch (e: Exception) { apiErr = e.friendly(); emptyList() }
        var snmpErr: String? = null
        var tunnels = emptyMap<String, Tunnel>()
        var users: Long? = null
        if (fw.snmpCommunity.isNotBlank()) {
            try {
                val s = SfosSnmp(fw.host, fw.snmpCommunity, fw.snmpPort)
                tunnels = s.tunnels().associateBy { it.name }
                users = runCatching { s.info().liveUsers }.getOrNull()
            } catch (e: Exception) {
                snmpErr = e.friendly()
            }
        }
        val ssl = api.names("SSLVPNPolicy")
        VpnData(conns, apiErr, tunnels, users, ssl, snmpErr)
    }
    // Actualisation automatique toutes les 30 s tant que l'onglet est affiché.
    LaunchedEffect(loader) {
        while (true) {
            delay(30_000)
            loader.reload()
        }
    }
    val scope = rememberCoroutineScope()
    var busy by remember { mutableStateOf<String?>(null) }

    fun act(name: String, action: String, msg: String) {
        busy = name
        scope.runAction(snackbar, msg, after = { busy = null; loader.reload() }) { api.ipsecAction(name, action) }
    }

    LazyColumn(
        Modifier.fillMaxSize(),
        contentPadding = PaddingValues(16.dp),
        verticalArrangement = Arrangement.spacedBy(10.dp),
    ) {
        val d = loader.data
        item { ListHeader("VPN", loader.loading) { loader.reload() } }
        loader.error?.let { item { ErrorBox(it) { loader.reload() } } }
        if (d == null && loader.loading) item { CenteredLoading() }
        if (d != null) {
            item {
                SectionCard("Accès à distance (SSL VPN / Sophos Connect)") {
                    KeyValue("Utilisateurs connectés au pare-feu", d.liveUsers?.toString() ?: "—")
                    KeyValue("Stratégies SSL VPN", if (d.sslPolicies.isEmpty()) "aucune" else d.sslPolicies.joinToString())
                    InfoText(
                        "Le compteur inclut tous les utilisateurs authentifiés (VPN et autres). " +
                            "La liste nominative des sessions VPN n'est pas exposée par l'API : console web, Activités en cours.",
                    )
                }
            }
            d.snmpError?.let { item { ErrorBox("État en direct indisponible (SNMP) : $it") } }
            d.apiError?.let { item { ErrorBox("Connexions IPsec illisibles : $it") } }

            item { Text("Connexions IPsec (${d.conns.size})", style = MaterialTheme.typography.titleMedium) }
            if (d.conns.isEmpty() && d.apiError == null) item { EmptyText("Aucune connexion IPsec configurée.") }
            items(d.conns, key = { it.name }) { c ->
                val t = d.tunnels[c.name]
                IpsecCard(c, t, enabled = busy == null, onAction = { action, msg -> act(c.name, action, msg) })
            }
            // Tunnels vus par SNMP mais absents de la configuration lue (ex. connexions d'accès distant)
            val extra = d.tunnels.values.filter { t -> d.conns.none { it.name == t.name } }
            if (extra.isNotEmpty()) {
                item { Text("Autres tunnels actifs", style = MaterialTheme.typography.titleSmall) }
                items(extra, key = { "x" + it.name }) { t ->
                    Card(Modifier.fillMaxWidth()) {
                        Row(Modifier.padding(12.dp), verticalAlignment = Alignment.CenterVertically) {
                            Dot(statusColor(t))
                            Spacer(Modifier.width(10.dp))
                            Column(Modifier.weight(1f)) {
                                Text(t.name)
                                InfoText(listOfNotNull(t.typeLabel.ifBlank { null }, t.description).joinToString(" · "))
                            }
                            Text(t.statusLabel, style = MaterialTheme.typography.bodySmall)
                        }
                    }
                }
            }
            item {
                InfoText(
                    "État en direct par SNMP, actualisé toutes les 30 s. Activer = rendre la connexion utilisable ; " +
                        "Connecter = établir le tunnel maintenant. Les alertes en arrière-plan signalent un tunnel coupé.",
                )
            }
        }
    }
}

private fun statusColor(t: Tunnel?) = when {
    t == null -> Grey
    t.status == 1 -> Green
    t.status == 2 -> Orange
    t.activated == 1 -> Red
    else -> Grey
}

@Composable
private fun IpsecCard(c: IpsecConn, t: Tunnel?, enabled: Boolean, onAction: (String, String) -> Unit) {
    Card(Modifier.fillMaxWidth()) {
        Column(Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Dot(statusColor(t), 14.dp)
                Spacer(Modifier.width(10.dp))
                Column(Modifier.weight(1f)) {
                    Text(c.name, style = MaterialTheme.typography.titleSmall)
                    InfoText(
                        listOfNotNull(
                            when (c.type) {
                                "SiteToSite" -> "Site à site"; "RemoteAccess" -> "Accès distant"
                                "HostToHost" -> "Hôte à hôte"; "TunnelInterface" -> "Interface tunnel"; else -> c.type
                            },
                            c.remote?.let { "pair $it" },
                            c.policy,
                        ).joinToString(" · "),
                    )
                }
                Text(
                    when {
                        t == null -> "état inconnu"
                        t.activated != 1 -> "désactivée"
                        else -> t.statusLabel
                    },
                    style = MaterialTheme.typography.bodySmall,
                )
            }
            if (c.localSubnets.isNotEmpty() || c.remoteNetworks.isNotEmpty()) {
                InfoText("${c.localSubnets.joinToString().ifEmpty { "?" }} ⇄ ${c.remoteNetworks.joinToString().ifEmpty { "?" }}")
            }
            c.description?.let { InfoText(it) }
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp), modifier = Modifier.padding(top = 4.dp)) {
                if (t?.activated == 1) {
                    if (t.status == 1) {
                        OutlinedButton(enabled = enabled, onClick = { onAction("DisConnection", "${c.name} déconnectée") }) { Text("Déconnecter") }
                    } else {
                        OutlinedButton(enabled = enabled, onClick = { onAction("Connection", "Connexion de ${c.name} demandée") }) { Text("Connecter") }
                    }
                    OutlinedButton(enabled = enabled, onClick = { onAction("DeActive", "${c.name} désactivée") }) { Text("Désactiver") }
                } else {
                    OutlinedButton(enabled = enabled, onClick = { onAction("Active", "${c.name} activée") }) { Text("Activer") }
                }
            }
        }
    }
}
