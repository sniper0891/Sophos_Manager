package fr.sophosmobile.ui

import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material3.FilterChip
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import fr.sophosmobile.data.Firewall
import fr.sophosmobile.net.ChartKind
import fr.sophosmobile.net.Dashboard
import fr.sophosmobile.net.DashboardWidget
import fr.sophosmobile.net.ReportData
import fr.sophosmobile.net.ReportPeriod
import fr.sophosmobile.net.ReportsApi

private data class Drill(val dbName: String, val value: String, val format: String, val label: String)

@Composable
fun ReportsTab(fw: Firewall, vm: AppViewModel) {
    if (!fw.consoleEnabled) {
        Column(Modifier.padding(16.dp)) {
            ErrorBox("Les rapports utilisent la console web. Active « Fonctions avancées (console web) » dans la fiche du pare-feu.")
        }
        return
    }
    val api = remember(fw) { vm.reportsFor(fw) }
    var period by remember { mutableStateOf("7") }
    var openDash by remember { mutableStateOf<Dashboard?>(null) }

    val dash = openDash
    if (dash == null) {
        DashboardList(api, onOpen = { openDash = it })
    } else {
        DashboardView(api, dash, period, onPeriod = { period = it }, onBack = { openDash = null })
    }
}

@Composable
private fun DashboardList(api: ReportsApi, onOpen: (Dashboard) -> Unit) {
    val loader = rememberLoader(api) { api.dashboards() }
    LazyColumn(
        Modifier.fillMaxSize(),
        contentPadding = PaddingValues(16.dp),
        verticalArrangement = Arrangement.spacedBy(10.dp),
    ) {
        item { ListHeader("Rapports", loader.loading) { loader.reload() } }
        loader.error?.let { item { ErrorBox(it) { loader.reload() } } }
        if (loader.data == null && loader.loading) item { CenteredLoading() }
        val list = loader.data
        if (list != null && list.isEmpty()) item { EmptyText("Aucun tableau de bord accessible.") }
        items(list ?: emptyList(), key = { it.groupId }) { d ->
            androidx.compose.material3.Card(
                onClick = { onOpen(d) },
                modifier = Modifier.fillMaxWidth(),
            ) {
                Column(Modifier.padding(16.dp)) {
                    Text(d.title, style = MaterialTheme.typography.titleMedium)
                    InfoText("${d.widgets.size} rapport(s)")
                }
            }
        }
        item { InfoText("Les rapports viennent du moteur de la console (données réelles du pare-feu). Touche un tableau de bord pour l'ouvrir.") }
    }
}

@Composable
private fun DashboardView(
    api: ReportsApi,
    dash: Dashboard,
    period: String,
    onPeriod: (String) -> Unit,
    onBack: () -> Unit,
) {
    var drill by remember(dash) { mutableStateOf<Drill?>(null) }
    val p = when (period) { "1" -> ReportPeriod.today(); "30" -> ReportPeriod.last30(); else -> ReportPeriod.last7() }

    LazyColumn(
        Modifier.fillMaxSize(),
        contentPadding = PaddingValues(16.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp),
    ) {
        item {
            Row(verticalAlignment = Alignment.CenterVertically) {
                TextButton(onClick = onBack) {
                    Icon(Icons.AutoMirrored.Filled.ArrowBack, null)
                    Spacer(Modifier.width(4.dp))
                    Text("Tableaux de bord")
                }
            }
        }
        item { Text(dash.title, style = MaterialTheme.typography.titleLarge) }
        drill?.let { d ->
            item {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Pill("Filtre : ${d.label}", BlueIn)
                    Spacer(Modifier.width(8.dp))
                    TextButton(onClick = { drill = null }) { Text("Retirer") }
                }
            }
        }
        item {
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                listOf("1" to "Aujourd'hui", "7" to "7 jours", "30" to "30 jours").forEach { (v, l) ->
                    FilterChip(selected = period == v, onClick = { onPeriod(v) }, label = { Text(l) })
                }
            }
        }
        items(dash.widgets, key = { it.id }) { w ->
            WidgetCard(api, dash.groupId, w, p, drill) { newDrill -> drill = newDrill }
        }
    }
}

@Composable
private fun WidgetCard(
    api: ReportsApi,
    groupId: String,
    w: DashboardWidget,
    period: ReportPeriod,
    drill: Drill?,
    onDrill: (Drill) -> Unit,
) {
    val loader = rememberLoader(w.id to period to (drill?.value ?: "")) {
        val criteria = drill?.let { listOf(Triple(it.dbName, it.value, it.format)) } ?: emptyList()
        api.widget(w.id, groupId, period, criteria)
    }
    SectionCard(w.title) {
        loader.error?.let { InfoText("Indisponible : $it") }
        if (loader.data == null && loader.loading) InfoText("Chargement…")
        loader.data?.let { r -> ReportContent(r, onDrill) }
    }
}

@Composable
private fun ReportContent(r: ReportData, onDrill: (Drill) -> Unit) {
    if (r.rows.isEmpty()) { InfoText("Aucune donnée sur la période."); return }
    val valueCol = r.valueColumn
    val labelCol = r.columns.firstOrNull()

    // Graphique : camembert ou barres selon le type, à partir de la colonne de valeur.
    if (valueCol != null && labelCol != null) {
        val slices = r.rows.mapNotNull { row ->
            val label = row.cells[labelCol] ?: return@mapNotNull null
            val num = parseAmount(row.cells[valueCol])
            if (num > 0) label to num else null
        }
        if (slices.isNotEmpty()) {
            when (r.chart) {
                ChartKind.Pie -> PieChart(slices)
                else -> BarList(slices) { formatAmount(it, r.isBytes) }
            }
            Spacer(Modifier.width(0.dp))
        }
    }

    // Tableau détaillé, avec drill-down sur la 1re colonne si disponible.
    r.rows.forEach { row ->
        val canDrill = row.drillKey != null && row.drillDbName != null
        Row(
            Modifier.fillMaxWidth().then(
                if (canDrill) Modifier.clickable {
                    onDrill(Drill(row.drillDbName!!, row.drillKey!!, row.drillFormat ?: "", row.cells[r.columns.first()] ?: row.drillKey!!))
                } else Modifier,
            ).padding(vertical = 3.dp),
            verticalAlignment = Alignment.CenterVertically,
        ) {
            Column(Modifier.weight(1f)) {
                Text(
                    row.cells[r.columns.first()] ?: "",
                    style = MaterialTheme.typography.bodyMedium,
                    color = if (canDrill) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.onSurface,
                )
            }
            r.valueColumn?.let { vc -> Text(row.cells[vc] ?: "", style = MaterialTheme.typography.bodySmall) }
        }
    }
    if (r.totalRecord > r.rows.size) InfoText("${r.rows.size} sur ${r.totalRecord} entrées. Touche une ligne soulignée pour le détail.")
}

/** Convertit "6.38 GB", "466 MB", "91 %", "1234" en nombre comparable (octets ou valeur brute). */
private fun parseAmount(s: String?): Double {
    val t = s?.trim() ?: return 0.0
    val m = Regex("""([\d.,]+)\s*([KMGT]?B)?""", RegexOption.IGNORE_CASE).find(t) ?: return 0.0
    val num = m.groupValues[1].replace(",", "").toDoubleOrNull() ?: return 0.0
    return when (m.groupValues[2].uppercase()) {
        "KB" -> num * 1024
        "MB" -> num * 1024 * 1024
        "GB" -> num * 1024 * 1024 * 1024
        "TB" -> num * 1024.0 * 1024 * 1024 * 1024
        else -> num
    }
}

private fun formatAmount(v: Double, isBytes: Boolean): String =
    if (isBytes) formatBytes(v) else "%,.0f".format(v)
