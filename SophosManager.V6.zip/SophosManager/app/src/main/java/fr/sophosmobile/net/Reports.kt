package fr.sophosmobile.net

/** Lecture du moteur de rapports de la console web (AjaxController). */

/** Type de graphique renvoyé par le pare-feu dans <charttype>. */
enum class ChartKind { Pie, Bar, StackedBar, Line, Other }

fun chartKindOf(code: Int?): ChartKind = when (code) {
    21 -> ChartKind.Pie
    41 -> ChartKind.Bar
    121 -> ChartKind.StackedBar
    3, 33, 152 -> ChartKind.Line
    else -> ChartKind.Other
}

/** Une ligne d'un rapport : valeurs par nom de colonne, plus l'éventuel critère de drill-down. */
data class ReportRow(
    val cells: Map<String, String>,
    /** orgvalue de la première colonne, pour le drill-down (ex. "FRA" pour France). */
    val drillKey: String?,
    val drillDbName: String?,
    val drillFormat: String?,
)

data class ReportData(
    val id: String,
    val title: String,
    val columns: List<String>,
    val rows: List<ReportRow>,
    val chart: ChartKind,
    val totalRecord: Int,
    /** Colonne numérique principale (Hits ou Bytes) pour les graphiques. */
    val valueColumn: String?,
    val isBytes: Boolean,
)

data class DashboardWidget(val id: String, val title: String, val chart: ChartKind)
data class Dashboard(val groupId: String, val title: String, val widgets: List<DashboardWidget>)

/** Période d'un rapport. */
data class ReportPeriod(val lastDays: Int, val startDate: String, val endDate: String) {
    companion object {
        private fun day(offset: Int): String {
            val ms = System.currentTimeMillis() - offset * 86_400_000L
            val d = java.text.SimpleDateFormat("yyyy-MM-dd", java.util.Locale.US).format(java.util.Date(ms))
            return d
        }
        fun today() = ReportPeriod(1, day(0) + " 00:00:00", day(0) + " 23:59:59")
        fun last7() = ReportPeriod(7, day(6) + " 00:00:00", day(0) + " 23:59:59")
        fun last30() = ReportPeriod(30, day(29) + " 00:00:00", day(0) + " 23:59:59")
    }
}

class ReportsApi(private val c: WebConsole) {

    /** Les tableaux de bord disponibles, découverts via action=1. */
    fun dashboards(): List<Dashboard> = DASHBOARD_GROUPS.mapNotNull { (gid, fallbackTitle) ->
        runCatching { dashboard(gid, fallbackTitle) }.getOrNull()?.takeIf { it.widgets.isNotEmpty() }
    }

    /** Définition d'un tableau de bord : liste des widgets avec titres et types. */
    fun dashboard(groupId: String, fallbackTitle: String): Dashboard {
        val body = c.post("/AjaxController", "action=1&json=" + WebConsole.enc("{reportgroupid:$groupId}") + "&empty=0,")
        val title = Regex("\"reportGroupTitle\"\\s*:\\s*\"([^\"]*)\"").find(body)?.groupValues?.getOrNull(1)
            ?.ifBlank { null } ?: fallbackTitle
        val ids = arrayFromJson(body, "reportList")
        val labels = arrayFromJson(body, "reportLabelList")
        val formats = formatList(body)
        val widgets = ids.mapIndexed { i, id ->
            DashboardWidget(
                id = id,
                title = labels.getOrNull(i)?.let(::cleanLabel) ?: "Rapport $id",
                chart = chartKindOf(formats[id]),
            )
        }
        return Dashboard(groupId, cleanLabel(title), widgets)
    }

    /** Données d'un widget via action=2, avec période et éventuel filtre de drill-down. */
    fun widget(
        id: String,
        groupId: String,
        period: ReportPeriod,
        drill: List<Triple<String, String, String>> = emptyList(), // (dbname, value, format)
        limit: Int = 10,
    ): ReportData {
        val criteria = drill.joinToString(",") { (key, value, fmt) ->
            "{\"key\":\"$key\",\"value\":${WebConsole.jsonStr(value)},\"condition\":\"=\",\"format\":\"$fmt\",\"innerFilter\":true,\"type\":\"-1\"}"
        }
        val json = buildString {
            append("{\"table\":\"on\",\"Graph\":\"on\",\"graphLimit\":10,\"viewAll\":true,")
            append("\"type\":\"G\",\"groupQuery\":false,")
            append("\"filter\":{\"lastday\":${period.lastDays},\"startDate\":\"${period.startDate}\",\"endDate\":\"${period.endDate}\",")
            append("\"recordPerPage\":$limit,\"currentPage\":1,\"criteria\":[],\"reportCriteria\":[$criteria],")
            append("\"limit\":$limit,\"offset\":0,\"sort\":{\"key\":\"Hits\",\"dir\":\"desc\"}},")
            append("\"id\":$id,\"reportGroupid\":$groupId}")
        }
        val xml = c.post("/AjaxController", "action=2&json=" + WebConsole.enc(json))
        return parseReportXml(xml, id)
    }

    companion object {
        /** Groupes de tableaux de bord (id -> titre de repli). Confirmés par les captures. */
        val DASHBOARD_GROUPS = linkedMapOf(
            "30" to "Trafic",
            "400000" to "Applications et Web",
            "900000" to "Sécurité",
            "1998000010" to "Réseau et menaces",
            "1999000010" to "Utilisateurs",
        )
    }
}

// ---------- Analyse XML des rapports ----------

/** Parse la réponse XML d'un widget (balise <root> avec <data>/<row>/<col>). */
fun parseReportXml(xml: String, fallbackId: String): ReportData {
    val root = runCatching { Xml.parse(xml) }.getOrNull()
        ?: return ReportData(fallbackId, "", emptyList(), emptyList(), ChartKind.Other, 0, null, false)
    // La réponse peut être <root> directement, ou l'englober.
    val r = if (root.nodeName == "root") root else root.find("root") ?: root
    val title = r.getAttribute("rtitle").ifBlank { r.getAttribute("title") }
    val total = r.getAttribute("totalRecord").toIntOrNull() ?: 0
    val chart = chartKindOf(r.find("charttype")?.textContent?.trim()?.toIntOrNull())

    val data = r.find("data")
    val rows = data?.children()?.filter { it.nodeName == "row" } ?: emptyList()
    if (rows.isEmpty()) {
        return ReportData(r.getAttribute("rid").ifBlank { fallbackId }, cleanLabel(title), emptyList(), emptyList(), chart, total, null, false)
    }

    // Première ligne = en-têtes (dbname + libellé).
    val header = rows.first().children().filter { it.nodeName == "col" }
    val columns = header.map { cleanLabel(it.textContent.trim()) }
    val dbNames = header.map { it.getAttribute("dbname") }
    val formats = header.map { it.getAttribute("dataformat") }

    val valueIdx = columns.indexOfFirst { it.equals("Hits", true) || it.equals("Octets", true) || it.equals("Bytes", true) || it.equals("Count", true) }
    val isBytes = valueIdx >= 0 && (columns[valueIdx].equals("Octets", true) || columns[valueIdx].equals("Bytes", true))

    val outRows = rows.drop(1).map { row ->
        val cols = row.children().filter { it.nodeName == "col" }
        val cells = LinkedHashMap<String, String>()
        cols.forEachIndexed { i, col ->
            val name = columns.getOrNull(i) ?: "c$i"
            cells[name] = decodeProto(col.textContent.trim())
        }
        val first = cols.firstOrNull()
        ReportRow(
            cells = cells,
            drillKey = first?.getAttribute("orgvalue")?.ifBlank { null },
            drillDbName = dbNames.firstOrNull()?.ifBlank { null },
            drillFormat = formats.firstOrNull()?.ifBlank { null },
        )
    }
    return ReportData(
        id = r.getAttribute("rid").ifBlank { fallbackId },
        title = cleanLabel(title),
        columns = columns,
        rows = outRows,
        chart = chart,
        totalRecord = total,
        valueColumn = valueIdx.takeIf { it >= 0 }?.let { columns[it] },
        isBytes = isBytes,
    )
}

/** Extrait un tableau JSON `"name":[a,b,c]` ou `[ "a","b" ]`. */
private fun arrayFromJson(json: String, name: String): List<String> {
    val at = json.indexOf("\"$name\"")
    if (at < 0) return emptyList()
    val start = json.indexOf('[', at)
    if (start < 0) return emptyList()
    var depth = 0; var i = start; var inStr = false; var esc = false
    while (i < json.length) {
        val ch = json[i]
        when {
            esc -> esc = false
            ch == '\\' -> esc = true
            ch == '"' -> inStr = !inStr
            !inStr && ch == '[' -> depth++
            !inStr && ch == ']' -> { depth--; if (depth == 0) break }
        }
        i++
    }
    val arr = json.substring(start + 1, i)
    return Regex(""""([^"]*)"|([0-9]+)""").findAll(arr).map {
        it.groupValues[1].ifEmpty { it.groupValues[2] }
    }.toList()
}

/** Extrait reportFormatList : map id -> chartType. */
private fun formatList(json: String): Map<String, Int> {
    val at = json.indexOf("\"reportFormatList\"")
    if (at < 0) return emptyMap()
    val start = json.indexOf('[', at)
    val end = json.indexOf(']', start)
    if (start < 0 || end < 0) return emptyMap()
    val block = json.substring(start, end + 1)
    val out = LinkedHashMap<String, Int>()
    Regex("""\{[^}]*"reportid"\s*:\s*(\d+)[^}]*"chartType"\s*:\s*(\d+)[^}]*\}""").findAll(block).forEach {
        out[it.groupValues[1]] = it.groupValues[2].toInt()
    }
    // ordre inverse possible des clés
    if (out.isEmpty()) {
        Regex("""\{[^}]*"chartType"\s*:\s*(\d+)[^}]*"reportid"\s*:\s*(\d+)[^}]*\}""").findAll(block).forEach {
            out[it.groupValues[2]] = it.groupValues[1].toInt()
        }
    }
    return out
}

/** Nettoie les libellés internes : enlève le préfixe reportlabels. et remplace _ par espace. */
fun cleanLabel(raw: String): String {
    var s = raw.trim()
    if (s.startsWith("reportlabels.")) s = s.removePrefix("reportlabels.")
    if (s.isNotEmpty() && !s.contains(' ') && s.contains('_')) s = s.replace('_', ' ')
    return s
}

/** Remplace les préfixes de protocole 6: et 17: par TCP:/UDP:, comme la console. */
fun decodeProto(v: String): String = when {
    v.startsWith("6:") -> "TCP:" + v.substring(2)
    v.startsWith("17:") -> "UDP:" + v.substring(2)
    else -> v
}
