package fr.sophosmobile.ui

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowDropDown
import androidx.compose.material.icons.filled.Close
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Card
import androidx.compose.material3.Checkbox
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedCard
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.RadioButton
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.TopAppBar
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.runtime.toMutableStateList
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties

/** Écran plein, utilisé pour les éditeurs (règles, redirections). */
@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun FullScreenDialog(
    title: String,
    onDismiss: () -> Unit,
    actions: @Composable () -> Unit = {},
    content: @Composable (Modifier) -> Unit,
) {
    Dialog(onDismissRequest = onDismiss, properties = DialogProperties(usePlatformDefaultWidth = false)) {
        AppTheme {
            Scaffold(
                topBar = {
                    TopAppBar(
                        title = { Text(title) },
                        navigationIcon = { IconButton(onClick = onDismiss) { Icon(Icons.Default.Close, contentDescription = "Fermer") } },
                        actions = { actions() },
                    )
                },
            ) { pad -> content(Modifier.padding(pad).fillMaxSize()) }
        }
    }
}

/** Champ qui ouvre une liste à choix unique. */
@Composable
fun SelectField(
    label: String,
    value: String,
    options: List<String>,
    modifier: Modifier = Modifier,
    loading: Boolean = false,
    display: (String) -> String = { it },
    onSelect: (String) -> Unit,
) {
    var open by remember { mutableStateOf(false) }
    OutlinedCard(modifier = modifier.fillMaxWidth().clickable { open = true }) {
        Row(Modifier.padding(horizontal = 16.dp, vertical = 10.dp), verticalAlignment = Alignment.CenterVertically) {
            Column(Modifier.weight(1f)) {
                Text(label, style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                Text(display(value), maxLines = 1, overflow = TextOverflow.Ellipsis)
            }
            Icon(Icons.Default.ArrowDropDown, null)
        }
    }
    if (open) {
        AlertDialog(
            onDismissRequest = { open = false },
            title = { Text(label) },
            text = {
                if (options.isEmpty()) LoadingOrEmpty(loading)
                LazyColumn(Modifier.heightIn(max = 420.dp)) {
                    items(options) { o ->
                        Row(
                            Modifier.fillMaxWidth().clickable { onSelect(o); open = false }.padding(vertical = 4.dp),
                            verticalAlignment = Alignment.CenterVertically,
                        ) {
                            RadioButton(selected = o == value, onClick = { onSelect(o); open = false })
                            Text(display(o))
                        }
                    }
                }
            },
            confirmButton = { TextButton(onClick = { open = false }) { Text("Fermer") } },
        )
    }
}

/** Champ qui ouvre une liste à choix multiples avec recherche. Liste vide = « Tous ». */
@Composable
fun MultiSelectField(
    label: String,
    values: List<String>,
    options: List<String>,
    emptyLabel: String = "Tous",
    loading: Boolean = false,
    onChange: (List<String>) -> Unit,
) {
    var open by remember { mutableStateOf(false) }
    OutlinedCard(modifier = Modifier.fillMaxWidth().clickable { open = true }) {
        Row(Modifier.padding(horizontal = 16.dp, vertical = 10.dp), verticalAlignment = Alignment.CenterVertically) {
            Column(Modifier.weight(1f)) {
                Text(label, style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                Text(if (values.isEmpty()) emptyLabel else values.joinToString(", "), maxLines = 2, overflow = TextOverflow.Ellipsis)
            }
            Icon(Icons.Default.ArrowDropDown, null)
        }
    }
    if (open) MultiPickerDialog(label, (options + values).distinct(), values, loading, onDismiss = { open = false }) { onChange(it); open = false }
}

@Composable
fun MultiPickerDialog(
    title: String,
    options: List<String>,
    selected: List<String>,
    loading: Boolean = false,
    onDismiss: () -> Unit,
    onDone: (List<String>) -> Unit,
) {
    val sel = remember { selected.toMutableStateList() }
    var query by remember { mutableStateOf("") }
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text(title) },
        text = {
            Column {
                OutlinedTextField(query, { query = it }, label = { Text("Rechercher") }, singleLine = true, modifier = Modifier.fillMaxWidth())
                Spacer(Modifier.height(8.dp))
                val shown = options.filter { query.isBlank() || it.contains(query, true) }
                if (options.isEmpty()) LoadingOrEmpty(loading)
                else if (shown.isEmpty()) InfoText("Aucun résultat pour « $query ».")
                LazyColumn(Modifier.heightIn(max = 380.dp)) {
                    items(shown) { o ->
                        Row(
                            Modifier.fillMaxWidth().clickable { if (o in sel) sel.remove(o) else sel.add(o) },
                            verticalAlignment = Alignment.CenterVertically,
                        ) {
                            Checkbox(checked = o in sel, onCheckedChange = { if (it) sel.add(o) else sel.remove(o) })
                            Text(o)
                        }
                    }
                }
            }
        },
        confirmButton = { TextButton(onClick = { onDone(sel.toList()) }) { Text("Valider (${sel.size})") } },
        dismissButton = {
            Row {
                TextButton(onClick = { sel.clear() }) { Text("Aucun") }
                TextButton(onClick = onDismiss) { Text("Annuler") }
            }
        },
    )
}

@Composable
fun SectionCard(title: String, modifier: Modifier = Modifier, content: @Composable () -> Unit) {
    Card(modifier.fillMaxWidth()) {
        Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
            Text(title, style = MaterialTheme.typography.titleMedium)
            content()
        }
    }
}

@Composable
fun KeyValue(key: String, value: String) {
    Row {
        Text(key, Modifier.weight(1f), color = MaterialTheme.colorScheme.onSurfaceVariant, style = MaterialTheme.typography.bodyMedium)
        Spacer(Modifier.width(8.dp))
        Text(value, style = MaterialTheme.typography.bodyMedium)
    }
}

data class ChartSeries(val label: String, val color: Color, val values: List<Float?>)

/** Courbes simples ; [maxY] fixe l'échelle (ex. 100 pour des pourcentages). */
@Composable
fun LineChart(series: List<ChartSeries>, maxY: Float? = null, height: Int = 120, format: (Float) -> String = { "%.0f".format(it) }) {
    val all = series.flatMap { it.values.filterNotNull() }
    if (all.isEmpty()) {
        InfoText("Pas encore de données.")
        return
    }
    val top = maxY ?: (all.max() * 1.1f).coerceAtLeast(1f)
    val grid = MaterialTheme.colorScheme.outlineVariant
    Column {
        Row {
            Text(format(top), style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
        }
        Canvas(Modifier.fillMaxWidth().height(height.dp)) {
            listOf(0f, 0.5f, 1f).forEach { y ->
                drawLine(grid, Offset(0f, size.height * y), Offset(size.width, size.height * y), strokeWidth = 1f)
            }
            series.forEach { s ->
                val n = s.values.size
                if (n < 2) return@forEach
                val stepX = size.width / (n - 1)
                val path = Path()
                var started = false
                s.values.forEachIndexed { i, v ->
                    if (v == null) { started = false; return@forEachIndexed }
                    val p = Offset(i * stepX, size.height * (1 - (v / top).coerceIn(0f, 1f)))
                    if (!started) { path.moveTo(p.x, p.y); started = true } else path.lineTo(p.x, p.y)
                }
                drawPath(path, s.color, style = Stroke(width = 2.dp.toPx()))
            }
        }
        Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
            series.forEach { s ->
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Dot(s.color, 8.dp)
                    Spacer(Modifier.width(4.dp))
                    Text(s.label, style = MaterialTheme.typography.labelSmall)
                }
            }
        }
    }
}

/** Histogramme horizontal simple : libellé, barre, valeur. */
@Composable
fun BarList(items: List<Pair<String, Double>>, format: (Double) -> String) {
    val max = items.maxOfOrNull { it.second }?.takeIf { it > 0 } ?: 1.0
    val color = MaterialTheme.colorScheme.primary
    val track = MaterialTheme.colorScheme.surfaceVariant
    Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
        items.forEach { (label, v) ->
            Column {
                Row {
                    Text(label, Modifier.weight(1f), style = MaterialTheme.typography.bodySmall)
                    Text(format(v), style = MaterialTheme.typography.bodySmall)
                }
                Box(Modifier.fillMaxWidth().height(8.dp)) {
                    Canvas(Modifier.fillMaxSize()) {
                        drawRect(track)
                        drawRect(color, size = size.copy(width = (size.width * (v / max)).toFloat()))
                    }
                }
            }
        }
    }
}

fun formatBytes(b: Double): String = when {
    b >= 1e12 -> "%.2f To".format(b / 1e12)
    b >= 1e9 -> "%.2f Go".format(b / 1e9)
    b >= 1e6 -> "%.1f Mo".format(b / 1e6)
    b >= 1e3 -> "%.0f ko".format(b / 1e3)
    else -> "%.0f o".format(b)
}

@Composable
fun LoadingOrEmpty(loading: Boolean) {
    if (loading) {
        Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.padding(vertical = 8.dp)) {
            androidx.compose.material3.CircularProgressIndicator(Modifier.size(20.dp), strokeWidth = 2.dp)
            Spacer(Modifier.width(12.dp))
            Text("Chargement des objets du pare-feu…")
        }
    } else {
        InfoText("Aucun élément. Si la liste devrait être remplie, ferme et rouvre l'éditeur pour réessayer.")
    }
}

/** Camembert simple à partir de parts (libellé, valeur). */
@Composable
fun PieChart(slices: List<Pair<String, Double>>, height: Int = 180) {
    val total = slices.sumOf { it.second }
    if (total <= 0) { InfoText("Pas de données."); return }
    val palette = listOf(
        Color(0xFF5C6BC0), Color(0xFF66BB6A), Color(0xFFFFA726), Color(0xFFEF5350),
        Color(0xFF26A69A), Color(0xFFAB47BC), Color(0xFF8D6E63), Color(0xFF42A5F5),
        Color(0xFFD4E157), Color(0xFFFF7043),
    )
    androidx.compose.foundation.layout.Row(verticalAlignment = Alignment.CenterVertically) {
        Canvas(Modifier.size(height.dp).padding(4.dp)) {
            var start = -90f
            slices.forEachIndexed { i, (_, v) ->
                val sweep = (v / total * 360f).toFloat()
                drawArc(
                    color = palette[i % palette.size],
                    startAngle = start,
                    sweepAngle = sweep,
                    useCenter = true,
                )
                start += sweep
            }
        }
        Spacer(Modifier.width(12.dp))
        Column(Modifier.weight(1f)) {
            slices.forEachIndexed { i, (label, v) ->
                Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.padding(vertical = 1.dp)) {
                    Dot(palette[i % palette.size], 10.dp)
                    Spacer(Modifier.width(6.dp))
                    Text(label, Modifier.weight(1f), style = MaterialTheme.typography.bodySmall, maxLines = 1, overflow = TextOverflow.Ellipsis)
                    Spacer(Modifier.width(6.dp))
                    Text("%.0f%%".format(v / total * 100), style = MaterialTheme.typography.bodySmall)
                }
            }
        }
    }
}
